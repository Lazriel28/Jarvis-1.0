"""Config loading expands local paths and preserves model identifiers."""

import json
from pathlib import Path, PureWindowsPath

import pytest

import jarvis.config as config_module
from jarvis.config import load_settings

pytestmark = [pytest.mark.unit, pytest.mark.usefixtures("no_network")]


def _write_config(tmp_path, monkeypatch, values):
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps(values))
    monkeypatch.setenv("JARVIS_CONFIG_PATH", str(cfg_path))


def test_tilde_db_path_is_expanded(tmp_path, monkeypatch):
    """The example-config db_path value must never produce a literal '~' path."""
    _write_config(tmp_path, monkeypatch, {"db_path": "~/.local/share/jarvis/jarvis.db"})

    cfg = load_settings()

    assert "~" not in cfg.db_path
    assert cfg.db_path == str(Path("~/.local/share/jarvis/jarvis.db").expanduser())


def test_other_path_settings_are_expanded(tmp_path, monkeypatch):
    """All path-like settings honour tilde notation."""
    _write_config(
        tmp_path,
        monkeypatch,
        {
            "sqlite_vss_path": "~/vss/vss0.dylib",
            "tts_piper_model_path": "~/models/voice.onnx",
            "tts_chatterbox_audio_prompt": "~/prompts/me.wav",
        },
    )

    cfg = load_settings()

    assert cfg.sqlite_vss_path == str(Path("~/vss/vss0.dylib").expanduser())
    assert cfg.tts_piper_model_path == str(Path("~/models/voice.onnx").expanduser())
    assert cfg.tts_chatterbox_audio_prompt == str(Path("~/prompts/me.wav").expanduser())


def test_null_db_path_falls_back_to_default(tmp_path, monkeypatch):
    """A 'null' db_path uses the default location instead of a literal path."""
    _write_config(tmp_path, monkeypatch, {"db_path": "null"})

    cfg = load_settings()

    assert "null" not in cfg.db_path
    assert cfg.db_path.endswith("jarvis.db")


def test_tilde_whisper_model_path_is_expanded(tmp_path, monkeypatch):
    """whisper_model accepts a local model directory; tilde must expand, names pass through."""
    _write_config(tmp_path, monkeypatch, {"whisper_model": "~/models/faster-whisper-medium"})
    assert load_settings().whisper_model == str(Path("~/models/faster-whisper-medium").expanduser())

    _write_config(tmp_path, monkeypatch, {"whisper_model": "medium"})
    assert load_settings().whisper_model == "medium"


def test_hugging_face_model_id_survives_config_loading(tmp_path, monkeypatch):
    """A repo ID is an identifier, not a path: its separator must stay a slash.

    Path normalisation turns "owner/model" into "owner\\model" on Windows and
    the download then fails with an invalid model size.
    """
    _write_config(tmp_path, monkeypatch, {
        "whisper_model": "deepdml/faster-whisper-large-v3-turbo-ct2",
    })

    assert load_settings().whisper_model == "deepdml/faster-whisper-large-v3-turbo-ct2"


def test_hugging_face_model_id_survives_windows_path_semantics(tmp_path, monkeypatch):
    """A repo ID keeps its forward slash when path expansion uses Windows rules."""
    model_id = "deepdml/faster-whisper-large-v3-turbo-ct2"
    _write_config(tmp_path, monkeypatch, {"whisper_model": model_id})

    def windows_path_expansion(value):
        if value in (None, "", "null"):
            return None
        return str(PureWindowsPath(str(value)))

    monkeypatch.setattr(config_module, "_expand_path", windows_path_expansion)

    assert load_settings().whisper_model == model_id


def test_a_local_whisper_model_directory_is_still_a_path(tmp_path, monkeypatch):
    """Directories that exist keep being normalised for the loader."""
    model_dir = tmp_path / "models" / "faster-whisper-medium"
    model_dir.mkdir(parents=True)
    _write_config(tmp_path, monkeypatch, {"whisper_model": str(model_dir)})

    assert load_settings().whisper_model == str(model_dir)


def test_absolute_and_unset_paths_are_untouched(tmp_path, monkeypatch):
    """Absolute paths pass through unchanged; unset optional paths stay None."""
    db = tmp_path / "jarvis.db"
    _write_config(tmp_path, monkeypatch, {"db_path": str(db)})

    cfg = load_settings()

    assert cfg.db_path == str(db)
    assert cfg.sqlite_vss_path is None
    assert cfg.tts_piper_model_path is None
    assert cfg.tts_chatterbox_audio_prompt is None
