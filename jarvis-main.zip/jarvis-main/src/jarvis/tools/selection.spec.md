## Tool Selection Spec

Selects a subset of available tools relevant to a given user query, so the LLM receives only tools it is likely to need. Reduces noise for smaller models and lowers token cost.

### ToolSelectionStrategy Enum

```python
class ToolSelectionStrategy(Enum):
    ALL = "all"
    KEYWORD = "keyword"
    EMBEDDING = "embedding"
    LLM = "llm"
```

### Strategies

Controlled by `tool_selection_strategy` in config:

| Value         | Behaviour                                                           | LLM call? | Extra dependency |
|---------------|---------------------------------------------------------------------|-----------|------------------|
| `"all"`       | Pass every registered tool.                                         | No        | None             |
| `"keyword"`   | Score tools by keyword overlap with the query; return top matches.  | No        | None             |
| `"embedding"` | Rank tools by cosine similarity of embeddings via nomic-embed-text. | No        | numpy            |
| `"llm"`       | Ask a lightweight LLM call to pick the top 3–5 relevant tool names (default). | Yes | None |

### Always-included Tools

Regardless of strategy, these tools are **always** included:
- `stop` — needed so the user can dismiss the assistant at any time.

### Keyword Strategy

1. Build a keyword index per tool from its `name` (camelCase split) and `description` (lowercased, stop-words removed).
2. Tokenise the user query (lowercase, split on whitespace/punctuation).
3. Score each tool: count of query tokens that appear in the tool's keyword set.
4. Return tools with score > 0, plus always-included tools.
5. If no tools score > 0, fall back to returning all tools (query is too vague to filter).

### Embedding Strategy

1. Embed the user query through the supplied `embedding_backend`, resolved by `get_embedding_backend(cfg)`, with the configured embedding model.
2. For each tool (excluding always-included), build a summary string from the tool name (camelCase split) and description, then embed it.
3. Compute cosine similarity between the query embedding and each tool embedding.
4. Select tools using a **relative threshold**: keep tools whose similarity >= `top_score * _RELATIVE_THRESHOLD` (0.97 — nomic-embed-text has a high baseline similarity, so a loose threshold lets the entire catalogue through).
5. If fewer than `_MIN_SELECTED` (3) tools pass the threshold, return the top 3 by similarity.
6. Append always-included tools.
7. If the query embedding fails, fall back to returning all tools.

Note: embedding is **not** the default strategy because nomic-embed-text produces tightly clustered similarities across all tools — the filter struggles to separate "good match" from "generic cluster" when a realistic MCP catalogue (20–40 tools) is in play. The `llm` strategy is cheaper in prompt size and more discriminative on small chat models.

### LLM Strategy (default)

1. Build a catalogue of `- name: description` lines (descriptions truncated to 120 chars) for every registered tool except always-included ones, including required input names from its schema.
2. Send through the supplied `llm_backend.direct()` with a system prompt asking for a JSON object containing `requested_operation` (a non-empty English translation of the user's requested action, preserving its verb and target) and `tools` (an array of exact tool names). The router identifies the operation before selecting up to five capabilities that perform it, prefers 1–3 tools for narrow queries, and returns an empty array for greetings/small talk or facts already visible in context.
3. Validate the JSON object and field types, then match names from `tools` literally against the registered catalogue, preserving rank and removing duplicates. Operation prose cannot contribute tool names. Unknown names are dropped.
4. Apply a hard `_LLM_MAX_SELECTED` (5) cap regardless of what the router returned, to guard against chatty routers that echo the whole catalogue.
5. Append always-included tools.
6. If the router's `tools` array is empty, return only the always-included tools.
7. On timeout, empty response, invalid JSON/field shape, or a non-empty selection containing no known tool names, fall back to the **keyword strategy** rather than to the full catalogue. Reasoning: the catalogue can grow to 30–40 tools once an MCP server like `chrome-devtools` is enabled, and exposing all of them to a small chat model (gemma4:e2b class) overwhelms tool selection, producing empty replies. Keyword scoring narrows on query/name overlap deterministically, and the engine's `toolSearchTool` escape hatch still lets the chat model widen mid-loop if the keyword pick missed.

Routing uses temperature zero. The completion budget is `_ROUTER_TOKEN_BUDGET` (1024 tokens), including reasoning and the tool-name answer. It applies to every backend. The request timeout and selected-tool cap remain independent bounds.

The router prefers capabilities whose required inputs can be supplied from the
request or context. Operations that depend on unknown record identifiers include
a retrieval capability rather than relying on invented identifiers.

#### Context-aware routing

When the reply engine passes a `context_hint`, it is split into two labelled semantic slots in the router system prompt:

- **KNOWN FACTS** — things the assistant can already see (current time, detected location). If the query is answerable purely from these, the router should return an empty `tools` array.
- **RECENT DIALOGUE** — recent user/assistant turns. The router is instructed to read the current query as a continuation of this exchange, so short follow-ups (e.g. "I'm in London" after "which city?") route to the tool that answers the combined intent across turns rather than being treated as idle chatter.

The split is the exact marker `"Recent dialogue (short-term memory):"` — any content before it is known facts, content after it is recent dialogue. If no dialogue marker is present, the whole hint is treated as known facts.

Voice routing receives a separate `transcript_context` after the catalogue and live hint. It is redacted, fenced reference data; the current request takes priority over earlier instructions, unrelated threads and TTS echo. The reply engine includes its fingerprint in the router cache key. A topic, named subject or prior question is not treated as an answer. Routing first resolves the subject, then chooses tools for the requested information or action still needed. Keyword and embedding strategies use the current request.

### Interface

```python
def select_tools(
    query: str,
    builtin_tools: Dict[str, Tool],
    mcp_tools: Dict[str, ToolSpec],
    strategy: ToolSelectionStrategy = ToolSelectionStrategy.ALL,
    *,
    llm_backend: Optional[LLMBackend] = None,
    llm_model: str = "",
    llm_timeout_sec: float = 8.0,
    embedding_backend: Optional[LLMBackend] = None,
    embed_model: str = "",
    embed_timeout_sec: float = 10.0,
    context_hint: Optional[str] = None,
    transcript_context: str = "",
) -> List[str]:
    """Return list of tool names relevant to the query."""
```

Missing embedding backends return all tools. Missing chat backends use keyword selection. Backend factories honour provider and embedding overrides.

### Integration

Called from the reply engine (Step 6) before `generate_tools_json_schema()` and `generate_tools_description()`. The returned list replaces the current `allowed_tools = list(BUILTIN_TOOLS.keys())`.

### Configuration

- Key: `tool_selection_strategy`
- Type: `str` (validated against `ToolSelectionStrategy` enum values)
- Default: `"llm"`
- Valid values: `"all"`, `"keyword"`, `"embedding"`, `"llm"`

- Key: `fast_model` (the shared fast tier)
- Type: `str`
- Default: `""` (empty string — automatic: the small Ollama default on the Ollama chat path, the chat model on an OpenAI-compatible provider)
- Effect: when `tool_selection_strategy == "llm"`, routing runs on the fast tier (`resolve_model(cfg, Tier.FAST)`): small, fast, already warm for wake-word paths, and structurally the same classification job as intent judging. Set `fast_model` to pin every fast-tier context (routing included) to a specific model.
