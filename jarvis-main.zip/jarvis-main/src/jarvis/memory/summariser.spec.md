# Diary Summariser Specification

## Overview

The diary summariser (`conversation.py::generate_conversation_summary`) condenses raw conversation chunks into a daily `conversation_summaries` row. That row feeds every downstream memory consumer — direct diary retrieval for enrichment, vector search, FTS, and knowledge-graph extraction. A corrupted summary therefore poisons every consumer, often silently: downstream code has no way to tell that a summary misrepresents what actually happened.

The summariser prompt enforces a fixed set of hygiene rules. Each rule exists because a specific field incident produced corrupted diary entries that misled later sessions. Rules are cumulative — none supersedes another.

The summariser prompt is the only write-time defence. There is no post-process scrub — the prompt is single-source-of-truth, language-agnostic, and improves automatically as the underlying chat model improves. Historical entries written before the prompt was tightened can be cleaned via a user-triggered LLM rewrite (see [LLM Rewrite Sweep](#llm-rewrite-sweep)).

## Core Behaviour

- Input per generation pass: up to 10 conversation chunks plus the previous summary.
  A diary flush processes the complete pending snapshot in chronological batches,
  feeding each intermediate summary into the next pass. Intermediate results stay
  in memory; only the completed snapshot is written. Passes in each flush attempt
  share the caller's generation deadline. A failed/incomplete pass or exhausted deadline preserves
  the existing diary and leaves the snapshot pending. Messages arriving during
  generation remain pending beyond the captured save watermark.
  Completed passes remain in private dialogue memory so a later flush can resume
  the same frozen snapshot at the same timeout. A changed starting diary row,
  day, source, model, endpoint or thinking mode restarts generation. Switching
  between background direct generation and a streaming shutdown retains completed
  passes so the shorter shutdown budget can finish the remaining work.
  Clearing, restoring, rewinding or explicitly marking dialogue saved discards
  resumable work; an in-flight superseded snapshot cannot commit. Flushes on the
  same dialogue memory do not overlap. The final write and watermark advance
  share the session mutation lock, without holding it during inference.
  Dialogue save callers capture chunks and their timestamp together with
  `get_pending_chunks_with_snapshot()` and advance the save watermark through
  `mark_saved_up_to()`. Later messages remain pending even within the same
  system-clock tick.
  Earlier user-stated facts, preferences, plans and attributed claims remain
  relevant even when absent from the current batch; correction chains are retained.
  Live diary tokens show only the final pass, keeping intermediate drafts private.
  A completed final pass retained after deadline exhaustion supplies its cached
  text to the live display on a later retry.
- Output: a free-form summary (≤ 200 words) and 3–5 comma-separated topic keywords.
- Direct generation reserves a bounded 1,024-token allowance, including reasoning,
  the summary and topics, within the caller's timeout. Streaming retains its
  uncapped generation within that timeout.
- Storage: one row per `(date_utc, source_app)` in `conversation_summaries`, upserted on each update.
- Embedding: when a local vector index and an embedding model are configured, the concatenation
  of summary + topics is embedded and stored for vector retrieval through
  sqlite-vss, FAISS or Python after the diary
  text commits. Refresh is best-effort: a backend or index failure preserves
  successful save confirmation, keyword retrieval and graph extraction. Pending
  messages advance only through the committed snapshot. Index errors log the
  exception class without its message or diary text.
- LLM failure is non-fatal — the summariser returns `(None, None)` and the update is skipped entirely. Pending messages remain queued for the next cycle.

## Hygiene Rules

### 1. No deflection narration
The summariser must not record the assistant's own failures, uncertainty, or offers to search. Those events are transient. If preserved, they are retrieved by future sessions as "conversation history" and prime the model to repeat the same deflection pattern.

- If the assistant eventually answered (e.g. after a tool call), record only the final answer.
- If the topic was raised but never resolved, record only the topic and the user's intent — strip every phrase describing the assistant's inability, uncertainty, or offer to help.

### 2. Attribution preservation
Claims the assistant made about third-party entities (films, books, products, people, places, scientific facts) must be attributed in the summary — "the assistant said X" rather than bare "X". The attribution lets downstream readers treat the claim with appropriate scepticism.

- Never paraphrase an attributed claim into an unattributed assertion. Unattributed claims poison enrichment by reading as established fact.
- If the user later corrects the assistant, record both the original claim and the correction. Do not silently replace.
- Tool-grounded data (weather, time, calculator results) and user-stated facts about the user themselves are safe without attribution caveats.

### 3. Topic separation
Unrelated topics must never be welded into one grammatical clause. No shared "and", shared appositive, or shared relative clause across distinct referents. Each topic gets its own sentence.

- A welded clause like "the film X and the character Y, identified as Z" is read by downstream retrievers as a single claim about both referents and silently corrupts future enrichment.
- A dangling appositive attaching to multiple antecedents is the exact failure mode — small models produce it frequently when two topics are raised in one conversation.

### 4. Preserve declarations embedded in requests

Explicit user-stated facts remain separate from the task or question that contains
them. Identity, residence, preferences, constraints, plans and circumstances are
preserved as standalone statements with their subject, relationship and temporal
status. They take priority over incidental assistant wording within the summary
budget. These relationships remain intact when combining later conversation with
an earlier summary.

A task parameter or requested option does not imply a personal fact. A requested
city is not a residence, and a requested meal type is not a dietary identity.
Quoted, hypothetical and third-party assertions retain their original attribution.
Text supplied for translation, explanation, editing or role-play remains task
content even when it contains first-person statements. The summariser identifies
that speech act before extracting personal declarations and does not duplicate
the supplied sentence as a separate user fact.
Current visits and future plans do not become home residence. Correction chains
keep former and current facts in separate, explicitly scoped sentences.

## Applicability

All four rules apply in any language, not only English. The prompt states this explicitly because small models otherwise assume the rule is keyed to the English phrases it names.

## LLM Rewrite Sweep

`rewrite_all_diary_summaries(db, cfg, ...)` is a user-triggered bulk operation that walks every row in `conversation_summaries` and asks the chat model to remove deflection narration. New writes use the summariser prompt; the sweep cleans existing entries on request.

**Why an LLM rather than regex:** the leak shows up in any language the user speaks, in any phrasing the model invents. A regex set is English-first by definition (you can only enumerate the patterns you can think of) and grows into a whack-a-mole. A small instruction-following model handles the semantic check in one shot, in any language, and improves automatically as the user's chat model upgrades. Mirrors `optimise_diary_topics` in shape and privacy guarantees.

**Prompt contract (`_REWRITE_DEFLECTION_SYSTEM_PROMPT`):**
- Return the entry with EVERY sentence removed whose subject is the assistant and whose verb describes inability, deflection, hesitation, or non-knowledge.
- Keep every other sentence verbatim — no paraphrasing, reordering, translating, or "improving".
- Keep attributed assistant claims ("the assistant said Possessor is a 2020 film") — those carry information.
- Keep user-stated facts and tool-grounded data — those are not assistant failures.
- Output the cleaned text only. Empty string if the entire summary is deflection. Verbatim input if nothing needs removing.
- Applies in every language; do NOT translate the output.

**Untrusted-input fence:** the diary text is wrapped in `<<<BEGIN UNTRUSTED WEB EXTRACT>>>` / `<<<END UNTRUSTED WEB EXTRACT>>>` markers (the same fence used for web-search content) before being passed to the model, so a row containing what looks like instructions is treated as data, not as a directive to follow. The fence markers, if echoed back, are stripped from the response.

**Empty-rewrite guard:** if the model returns an empty string (a row that was *entirely* deflection), the original is kept and a `would_empty: true` flag is surfaced. An empty diary entry is worse than a slightly-leaky one — downstream retrieval treats absence as "no record" and the user loses the topic entirely.

**Privacy:** the sweep streams per-row events as `{date_utc, chars_before, chars_after, rewritten, would_empty, embedding_refreshed, error?}` — counts and booleans only, never raw summary text. The `error` value is the exception class name only (e.g. `"RuntimeError"`), never the stringified exception message, because Python exception messages can echo offending input back to the caller. The progress-event key set is locked behind a whitelist test so any future field addition forces deliberate review (`tests/test_memory_viewer_diary_scrub_api.py::test_progress_event_keys_are_a_known_whitelist`). The diary clean button must not become a data-exfiltration channel through the streaming progress UI.

**Audit trail:** preserves each row's ID and original `ts_utc` on rewrite. Existing vector references remain attached when the optional embedding refresh is unavailable. The timestamp identifies when each diary entry was authored.

**Vector embedding:** when a row is rewritten, the embedding stored alongside the summary is regenerated inline from the cleaned text when `cfg.embedding_model` is configured and `db.has_vector_store` reports an available sqlite-vss, FAISS or Python index. Without an embed model the rewrite still happens (FTS stays consistent via SQLite triggers); the vector embedding stays anchored to the pre-rewrite text until the next user-driven write to that date. Per-row embedding refresh is best-effort: an embedding-service failure is logged but does not roll back the summary write.

The embedding source is captured from the live row before inference. A refresh
whose source text is superseded during inference is rejected atomically with
the vector write and reports `embedding_refreshed: false`. Diary save, rewrite
and topic optimisation share this guard, including across independent owners.

**Fail-open at every layer:**
- LLM call failure on a row → row is left untouched and reported with `error` set to the exception class name.
- Empty rewrite → row is left untouched, `would_empty: true` surfaced.
- Per-row write failure → row is reported with `error`, the sweep continues.

**Cache invariant:** diary retrieval reads the durable row live on each enrichment-bearing turn. Private write-side progress is scoped to its captured pending snapshot and starting diary row, so a rewrite invalidates that progress before a later flush resumes. The reply engine's hot cache holds the warm-profile block (graph-derived, not diary), the per-query router decision, and the per-query memory-extractor parameters. None are derived from diary text, so the rewrite sweep does not need a listener-style invalidation hook. The actual diary search hits SQLite live on every enrichment-bearing turn. Concurrency between the sweep and an in-flight reply is handled by SQLite WAL. There is one inherent limitation: the previous turn's already-spoken assistant reply lives in `DialogueMemory._messages`. If a follow-up lands on the recall-gate fast path, the user is answered from rolling dialogue rather than a fresh enrichment. The rewrite does not retroactively rewrite spoken history; the next turn that triggers fresh enrichment sees the cleaned diary.

**Read paths:** none. The rewrite only touches the bulk sweep. Read-time diary retrieval is untouched.

## Bulk Sweep UI

The memory viewer's diary tab carries a Maintenance section in the sidebar with two operations:

**"🧹 Clean up deflection narration"** — asks the chat model to rewrite each old diary entry, removing only sentences that narrate assistant failures. The rest of each entry is preserved verbatim, no diary entries are deleted, and a summary that is *entirely* deflection narration is kept rather than emptied. Requires the chat model to be running. Backed by `POST /api/diary/scrub-deflections` (NDJSON-streaming) which calls `rewrite_all_diary_summaries`. The endpoint URL still says "scrub" for backwards compatibility; the implementation is now LLM-driven.

**"🏷️ Optimise tags"** — normalises topic tags across all diary entries using the configured chat model. Because each diary write generates topics independently, the same concept may accumulate multiple surface forms over time ("cook", "cooking", "meal prep"). The optimiser collects all unique tags, makes a single LLM call to propose a normalised taxonomy (merging synonyms, splitting compound tags), then applies the mapping to every row whose tags change. Backed by `POST /api/diary/optimise-topics` (NDJSON-streaming) which calls `optimise_diary_topics`. Requires the chat model to be running. Diary text is untouched; only the `topics` column is rewritten. Preserves `ts_utc` on every rewrite. Re-embeds updated rows best-effort. Fail-open: LLM failure or bad JSON leaves all rows unchanged.

## Tag Optimisation

`optimise_diary_topics(db, ollama_base_url, ollama_chat_model, ...)` in `conversation.py` implements the bulk tag normalisation sweep:

1. Collect all unique topic strings from every `conversation_summaries` row (one pass, in memory).
2. One `call_llm_direct` call to `ollama_chat_model` with `_TOPIC_OPTIMISE_SYSTEM_PROMPT` — returns a JSON object mapping each input tag to its normalised form (string for merge, list for split).
3. Apply the mapping via `_apply_topic_mapping()` to each row's comma-separated topics string. Deduplicates the result while preserving order so a merge that produces two identical tags (e.g. "cook, cooking" → "cooking, cooking") collapses cleanly.
4. Write back only rows whose topics changed, preserving `ts_utc` (same contract as the deflection rewrite).
5. Re-embed updated rows if an embed model is configured.

Yields one event per row: `{date_utc, topics_changed, old_topic_count, new_topic_count, error?}`. No raw tag values in events — counts only.

Idempotent once the mapping has been applied: a second run finds no tags to change.

## Evals and Regression Guards

| Test | Location | Guards |
|------|----------|--------|
| Pending snapshot cases | `tests/test_diary_pending_batches.py` | Complete input coverage, atomic failure, shared deadline, retry, concurrent arrivals and final-pass streaming |
| Embedded user declarations | `evals/test_embedded_user_fact_capture.py` | English/Turkish residence, streaming/direct generation, later-turn retention, persisted graph recall, preferences, temporal status and attribution |
| English and Turkish pending conversations | `evals/test_diary_pending_snapshot.py` | Early, middle and late facts retained through real direct and streaming generation |
| `test_omits_deflection_narration_for_unknown_entity` | `evals/test_diary_summariser_hygiene.py` | Rule 1, resolved case |
| `test_omits_deflection_when_topic_never_resolved` | `evals/test_diary_summariser_hygiene.py` | Rule 1, unresolved case |
| `test_unrelated_topics_are_not_welded_into_one_clause` | `evals/test_diary_summariser_hygiene.py` | Rule 3 |
| `test_preserves_legitimate_user_preferences` | `evals/test_diary_summariser_hygiene.py` | Cross-rule: hygiene must not strip real content |
| `TestSummariserForbidsDeflectionNarration` | `tests/test_diary_poisoning_defence.py` | Prompt-content regression (rules 1–3) |
| `TestRewriteSweepBehaviour` | `tests/test_diary_rewrite_sweep.py` | LLM-rewrite bulk sweep DB integration, fail-open, audit trail |
| `TestDiaryScrubEndpoint` | `tests/test_memory_viewer_diary_scrub_api.py` | Endpoint streaming + privacy contract |
| `TestOptimiseContract` / `TestOptimiseMerge` / `TestOptimiseSplit` / `TestOptimiseDeduplicate` / `TestOptimiseAuditTrail` / `TestOptimiseFailOpen` / `TestOptimiseIdempotence` | `tests/test_diary_topic_optimise.py` | Tag optimisation — generator contract, merge/split semantics, dedup, audit trail, fail-open, idempotence |

Live evals target the smallest supported model (gemma4:e2b) and `xfail` softly on weaker models rather than hard-failing, documenting residual risk instead of masking it.

## Relationship to Other Systems

- **Diary retrieval** (`engine.py`): injects retrieved summaries under a "reference only" framing, not as authoritative instructions. This partially mitigates corrupted summaries, but the primary defence is the summariser itself — see `reply.spec.md`.
- **Knowledge graph** (`graph.spec.md`): ingests summaries via `update_graph_from_dialogue()`. Graph extraction inherits whatever corruption the summary contains; hygiene at the summariser is the only place to fix this at source.
