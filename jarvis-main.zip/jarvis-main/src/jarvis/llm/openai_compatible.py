"""OpenAI-compatible implementation of :class:`LLMBackend`.

Targets any local server that exposes the OpenAI Chat Completions
shape: LM Studio, oMLX, llama.cpp's ``llama-server``, vLLM, LocalAI,
and similar. The wire shape differs from Ollama in three important
ways, all hidden inside this module so callers see one response
shape:

1. **Endpoints** are ``/chat/completions`` and ``/embeddings`` rather
   than ``/api/chat`` and ``/api/embeddings``. Model listing is at
   ``/models`` rather than ``/api/tags``.
2. **Streaming uses Server-Sent Events** (``data: {...}\\n\\n`` with a
   ``data: [DONE]`` terminator) instead of Ollama's JSON-lines.
3. **Tool-call arguments arrive as a JSON-encoded string**
   (``"{\\"x\\": 1}"``) rather than a dict; the reply engine expects
   a dict, so :meth:`chat` decodes them. The same method also lifts
   ``choices[0].message`` to top-level ``message`` so the engine's
   existing parsing path works without branching on provider.

The error handling and ``ToolsNotSupportedError`` semantics mirror
:class:`OllamaBackend` so callers get a single contract regardless of
which backend is active.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

import json
import time
import requests

from ..debug import debug_log
from . import http
from .errors import is_timeout_error
from .streaming import check_stream_deadline, iter_stream_lines
from .backend import (
    LLMBackend, ToolsNotSupportedError, response_is_incomplete,
    strip_nonstandard_message_fields,
)


@dataclass
class ServerCapabilities:
    """What an OpenAI-compatible server can actually do, probed with real
    requests. ``reachable`` is False when the server did not respond at all
    (wrong URL, server down); the per-feature flags are only meaningful when
    ``reachable`` is True. ``models`` is the advertised model list."""

    reachable: bool = False
    chat: bool = False
    tools: bool = False
    embeddings: bool = False
    models: List[str] = field(default_factory=list)


def _normalise_response(data: Dict[str, Any]) -> Dict[str, Any]:
    """Lift OpenAI's ``choices[0].message`` to top-level ``message``
    (matching Ollama's shape) and JSON-decode any tool-call arguments.

    If the server already returns Ollama's shape (some hybrid servers
    expose both endpoints), the response is passed through unchanged.

    Response normalisation stays inside the provider backend.
    """
    if "message" in data and isinstance(data["message"], dict):
        return data

    choices = data.get("choices")
    if isinstance(choices, list) and choices and isinstance(choices[0], dict):
        msg = choices[0].get("message")
        if isinstance(msg, dict):
            normalised = dict(data)
            decoded_msg = dict(msg)
            tool_calls = decoded_msg.get("tool_calls")
            if isinstance(tool_calls, list):
                decoded_calls: List[Dict[str, Any]] = []
                for tc in tool_calls:
                    if not isinstance(tc, dict):
                        decoded_calls.append(tc)
                        continue
                    decoded_tc = dict(tc)
                    func = decoded_tc.get("function")
                    if isinstance(func, dict):
                        decoded_func = dict(func)
                        args = decoded_func.get("arguments")
                        if isinstance(args, str):
                            try:
                                decoded_func["arguments"] = json.loads(args)
                            except (json.JSONDecodeError, ValueError):
                                # Retain malformed data for the reply
                                # engine to reject without execution.
                                pass
                        decoded_tc["function"] = decoded_func
                    decoded_calls.append(decoded_tc)
                decoded_msg["tool_calls"] = decoded_calls
            normalised["message"] = decoded_msg
            return normalised

    return data


class OpenAICompatibleBackend(LLMBackend):
    """:class:`LLMBackend` implementation for OpenAI-compatible servers."""

    def __init__(self, base_url: str, api_key: Optional[str] = None) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key or None

    @property
    def base_url(self) -> str:
        return self._base_url

    def _headers(self) -> Dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        return headers

    # ── chat ───────────────────────────────────────────────────────────

    def direct(
        self,
        chat_model: str,
        system_prompt: str,
        user_content: str,
        timeout_sec: float = 10.0,
        thinking: bool = False,
        num_ctx: int = 4096,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> Optional[str]:
        # ``num_ctx`` and ``thinking`` have no equivalent in the OpenAI
        # shape; servers that need a fixed context window configure it
        # at load time, and reasoning is a model attribute rather than
        # a request flag. Both are accepted for signature parity with
        # OllamaBackend and silently ignored here.
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]
        payload: Dict[str, Any] = {
            "model": chat_model,
            "messages": messages,
            "stream": False,
        }
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        try:
            with http.post(
                f"{self._base_url}/chat/completions",
                json=payload,
                headers=self._headers(),
                timeout=timeout_sec,
            ) as resp:
                resp.raise_for_status()
                data = resp.json()

            normalised = _normalise_response(data) if isinstance(data, dict) else None
            if normalised:
                if response_is_incomplete(normalised):
                    debug_log("OpenAICompatibleBackend.direct: incomplete generation", "llm")
                    return None
                msg = normalised.get("message")
                if isinstance(msg, dict):
                    content = msg.get("content")
                    if isinstance(content, str) and content.strip():
                        return content
                debug_log(
                    f"OpenAICompatibleBackend.direct: empty content from response keys={list(data.keys())}",
                    "llm",
                )
        except requests.exceptions.Timeout:
            debug_log(f"OpenAICompatibleBackend.direct: timeout after {timeout_sec}s", "llm")
            return None
        except Exception as e:
            # The exception string can embed the full URL (and any query-string
            # credentials); log only the class so nothing sensitive leaks.
            debug_log(f"OpenAICompatibleBackend.direct: request failed ({type(e).__name__})", "llm")
            return None

        return None

    def streaming(
        self,
        chat_model: str,
        system_prompt: str,
        user_content: str,
        on_token: Optional[Callable[[str], None]] = None,
        timeout_sec: float = 30.0,
        thinking: bool = False,
    ) -> Optional[str]:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]
        payload: Dict[str, Any] = {
            "model": chat_model,
            "messages": messages,
            "stream": True,
        }

        deadline = time.monotonic() + timeout_sec
        try:
            with http.post(
                f"{self._base_url}/chat/completions",
                json=payload,
                headers=self._headers(),
                timeout=timeout_sec,
                stream=True,
            ) as resp:
                resp.raise_for_status()

                full_response: List[str] = []
                for raw in iter_stream_lines(resp, deadline):
                    if not raw:
                        continue
                    line = raw.decode("utf-8", errors="ignore") if isinstance(raw, bytes) else raw
                    if not line.startswith("data:"):
                        # SSE comments (``: ping``) and unrelated lines.
                        continue
                    payload_str = line[len("data:"):].strip()
                    if payload_str == "[DONE]":
                        break
                    try:
                        chunk = json.loads(payload_str)
                    except json.JSONDecodeError:
                        continue
                    choices = chunk.get("choices") if isinstance(chunk, dict) else None
                    if not isinstance(choices, list) or not choices:
                        continue
                    delta = choices[0].get("delta") if isinstance(choices[0], dict) else None
                    if not isinstance(delta, dict):
                        continue
                    content = delta.get("content")
                    if isinstance(content, str) and content:
                        full_response.append(content)
                        if on_token:
                            on_token(content)

                check_stream_deadline(deadline)
                result = "".join(full_response)
                return result if result.strip() else None
        except requests.exceptions.Timeout:
            debug_log(f"openai_compatible streaming: timeout after {timeout_sec}s", "llm")
            return None
        except Exception:
            return None

    @staticmethod
    def _encode_tool_call_arguments(
        messages: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Return copied messages with tool-call arguments encoded for the wire.

        The provider requires ``arguments`` to be a JSON string. Response
        normalisation decodes JSON values for the reply engine, so outbound
        history re-encodes every non-string value. Invalid object shapes
        retain their values in failed-call history rather than breaking the
        provider's wire format. Caller-owned messages and decoded responses
        retain their original tool-call values, including when a request fails.
        """
        encoded_messages = []
        for msg in messages:
            encoded_msg = dict(msg)
            encoded_messages.append(encoded_msg)
            if msg.get("role") != "assistant":
                continue
            tc_list = msg.get("tool_calls")
            if not isinstance(tc_list, list):
                continue
            encoded_calls = []
            for tc in tc_list:
                func = tc.get("function")
                encoded_call = dict(tc)
                encoded_calls.append(encoded_call)
                if not isinstance(func, dict):
                    continue
                encoded_func = dict(func)
                args = func.get("arguments", {})
                if not isinstance(args, str):
                    encoded_func["arguments"] = json.dumps(args)
                encoded_call["function"] = encoded_func
            encoded_msg["tool_calls"] = encoded_calls
        return encoded_messages

    def chat(
        self,
        chat_model: str,
        messages: List[Dict[str, Any]],
        timeout_sec: float = 30.0,
        extra_options: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        thinking: bool = False,
    ) -> Optional[Dict[str, Any]]:
        sanitised = strip_nonstandard_message_fields(messages)
        sanitised = self._encode_tool_call_arguments(sanitised)
        payload: Dict[str, Any] = {
            "model": chat_model,
            "messages": sanitised,
            "stream": False,
        }
        if extra_options and isinstance(extra_options, dict):
            # ``temperature``, ``max_tokens``, ``top_p`` etc. live at the
            # payload root in the OpenAI shape, not under an ``options``
            # nest. Ollama-only knobs (``keep_alive``, ``num_ctx``,
            # ``num_predict``, ``think``) are silently dropped — they have
            # no equivalent in the OpenAI shape and would 400 against most
            # servers. Sampling fields nested under ``options`` are lifted
            # to the payload root.
            for key, value in extra_options.items():
                if key in {"keep_alive", "num_ctx", "num_predict", "think"}:
                    continue
                if key == "options" and isinstance(value, dict):
                    for inner_key, inner_value in value.items():
                        if inner_key in {"num_ctx", "num_predict"}:
                            continue
                        payload[inner_key] = inner_value
                else:
                    payload[key] = value
        if tools and isinstance(tools, list) and len(tools) > 0:
            payload["tools"] = tools

        try:
            with http.post(
                f"{self._base_url}/chat/completions",
                json=payload,
                headers=self._headers(),
                timeout=timeout_sec,
            ) as resp:
                resp.raise_for_status()
                data = resp.json()
            if isinstance(data, dict):
                return _normalise_response(data)
        except requests.exceptions.Timeout:
            print(f"  ⏱️ LLM request timed out (configured timeout: {timeout_sec:g}s)", flush=True)
            return None
        except requests.exceptions.ConnectionError as exc:
            if is_timeout_error(exc):
                debug_log("chat response read timed out (wrapped transport timeout)", "llm")
                print(f"  ⏱️ LLM request timed out (configured timeout: {timeout_sec:g}s)", flush=True)
                return None
            # ConnectionError messages embed the configured URL via the
            # underlying urllib3 exception, which can leak account-bearing
            # query strings to stdout. Print only the failure mode and
            # bubble the exception so callers (e.g. the intent judge) can
            # distinguish "server unreachable" from a transient HTTP error.
            print("  ❌ LLM connection error", flush=True)
            raise
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 400 and tools:
                raise ToolsNotSupportedError(
                    f"Model {chat_model!r} returned HTTP 400 — native tools API not supported"
                )
            # ``str(e)`` includes "for url: <full URL>" — keep the status code
            # for diagnosis and drop the URL.
            status = e.response.status_code if e.response is not None else "?"
            print(f"  ❌ LLM HTTP error (status {status})", flush=True)
            return None
        except Exception as e:
            # Generic exception messages can carry whatever the caller embedded
            # (URLs, tokens). Print only the exception class so the user knows
            # *something* failed without leaking what.
            print(f"  ❌ LLM error ({type(e).__name__})", flush=True)
            return None

        return None

    # ── embeddings & discovery ────────────────────────────────────────

    def embed(
        self,
        text: str,
        model: str,
        timeout_sec: float = 15.0,
    ) -> Optional[List[float]]:
        try:
            with http.post(
                f"{self._base_url}/embeddings",
                json={"model": model, "input": text},
                headers=self._headers(),
                timeout=timeout_sec,
            ) as resp:
                resp.raise_for_status()
                data = resp.json()
                arr = data.get("data") if isinstance(data, dict) else None
                if isinstance(arr, list) and arr and isinstance(arr[0], dict):
                    vec = arr[0].get("embedding")
                    if isinstance(vec, list):
                        return [float(x) for x in vec]
        except Exception:
            return None
        return None

    def list_models(self, timeout_sec: float = 5.0) -> List[str]:
        try:
            with http.get(
                f"{self._base_url}/models",
                headers=self._headers(),
                timeout=timeout_sec,
            ) as resp:
                resp.raise_for_status()
                data = resp.json()
                arr = data.get("data", []) if isinstance(data, dict) else []
                names: List[str] = []
                for m in arr:
                    if isinstance(m, dict):
                        name = m.get("id")
                        if isinstance(name, str) and name:
                            names.append(name)
                return names
        except Exception:
            return []

    def warm_up(
        self,
        model: str,
        timeout_sec: float = 60.0,
        keep_alive: str = "30m",
    ) -> bool:
        """Warm up the model by sending a minimal inference request.

        Phase 1 (reachability check): calls ``GET /models`` to confirm
        the server is up and has models loaded. Fast (capped at 25 % of
        the budget, max 5 s).

        Phase 2 (model loading): sends a single-token chat completion
        (``max_tokens=1``) so the runtime actually loads the model into
        memory. Without this, an OpenAI-compatible server may leave the
        model cold until the first real request, incurring latency on the
        user's first query. This mirrors what ``OllamaBackend.warm_up()``
        does.

        ``keep_alive`` is accepted for signature parity with
        ``OllamaBackend.warm_up`` but ignored: OpenAI-compatible servers
        manage model residency at server load time and have no per-call
        keep-alive knob.

        Best-effort: errors are swallowed; ``False`` is returned when the
        server is unreachable, the model name is missing, or the inference
        request fails, so the listener can warn the user early."""
        if not self._base_url or not model:
            return False

        # Phase 1: reachability probe (fast).
        list_to = min(max(timeout_sec * 0.25, 1.0), 5.0)
        if not self.list_models(timeout_sec=list_to):
            return False

        # Phase 2: minimal inference to force model loading.
        remaining = max(0.1, timeout_sec - list_to)
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": "ping"}],
            "max_tokens": 1,
            "stream": False,
        }
        try:
            with http.post(
                f"{self._base_url}/chat/completions",
                json=payload,
                headers=self._headers(),
                timeout=remaining,
            ) as resp:
                return resp.ok
        except Exception:
            return False

    def check_capabilities(
        self,
        chat_model: str,
        embed_model: Optional[str] = None,
        timeout_sec: float = 8.0,
    ) -> ServerCapabilities:
        """Probe what the server can actually do with real requests: list its
        models, send a tiny chat completion, try a trivial tool call, and ask
        for an embedding. Returns raw booleans (formatting is the caller's
        job). Never raises — every failure mode collapses to a False flag so
        the setup wizard and startup check can report honestly.

        ``chat`` covers both a plain reply and a tool-call-only reply (an empty
        ``content`` with ``tool_calls`` still proves the chat endpoint works)."""
        caps = ServerCapabilities(models=self.list_models(timeout_sec=timeout_sec))
        if caps.models:
            caps.reachable = True

        # Cap generation: we only need to know the endpoint answers, so a short
        # reply keeps the probe fast on large models and avoids a long
        # generation tripping the timeout and reporting a false "chat broken".
        probe = [{"role": "user", "content": "ping"}]
        probe_opts = {"max_tokens": 16}
        try:
            resp = self.chat(chat_model, probe, timeout_sec=timeout_sec, extra_options=probe_opts)
            if isinstance(resp, dict):
                caps.reachable = True
                msg = resp.get("message")
                msg = msg if isinstance(msg, dict) else {}
                caps.chat = bool((msg.get("content") or "").strip()) or bool(msg.get("tool_calls"))
        except requests.exceptions.ConnectionError:
            # Server unreachable — nothing else can succeed either.
            caps.reachable = False
            return caps
        except Exception:
            pass

        if caps.chat:
            trivial_tool = [{
                "type": "function",
                "function": {
                    "name": "ping",
                    "description": "A no-op used to probe tool support.",
                    "parameters": {"type": "object", "properties": {}},
                },
            }]
            try:
                tool_resp = self.chat(chat_model, probe, tools=trivial_tool,
                                       timeout_sec=timeout_sec, extra_options=probe_opts)
                caps.tools = isinstance(tool_resp, dict)
            except ToolsNotSupportedError:
                caps.tools = False
            except Exception:
                caps.tools = False

        em = (embed_model or "").strip() or chat_model
        if self.embed("ping", em, timeout_sec=timeout_sec):
            caps.embeddings = True
            caps.reachable = True

        return caps
