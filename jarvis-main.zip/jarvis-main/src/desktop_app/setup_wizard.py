"""
Jarvis Setup Wizard

A setup wizard that checks for Ollama installation, running server, and required models.
Guides users through the setup process with automated actions where possible.
"""

from __future__ import annotations
import subprocess
import shutil
import sys
import os
import platform
import ipaddress
import webbrowser
import json
from pathlib import Path
from typing import Optional, List, Tuple, Dict
from dataclasses import dataclass
from enum import Enum, auto
from urllib.parse import urlsplit

import requests

from desktop_app.whisper_models import get_whisper_vram_mb, wizard_model_options
from jarvis.llm.model_names import missing_ollama_models
from jarvis.listening import whisper_capabilities
from jarvis.debug import debug_log
from jarvis.config import SUPPORTED_CHAT_MODELS, DEFAULT_CHAT_MODEL, DEFAULT_FAST_MODEL, SUPPORTED_FAST_MODEL_IDS, DEFAULT_EMBEDDING_MODEL
from jarvis.utils.vram import (
    detect_total_vram_mb,
    get_recommended_model_id,
    get_recommended_model_pair,
    required_vram_mb,
)


def is_apple_silicon() -> bool:
    """Check if running on Apple Silicon Mac."""
    return sys.platform == "darwin" and platform.machine() == "arm64"


def check_ffmpeg_installed() -> Tuple[bool, Optional[str]]:
    """Check if FFmpeg is installed (required for MLX Whisper)."""
    ffmpeg_path = shutil.which("ffmpeg")
    if ffmpeg_path:
        return True, ffmpeg_path

    # Check common macOS paths
    macos_paths = [
        "/usr/local/bin/ffmpeg",
        "/opt/homebrew/bin/ffmpeg",
    ]
    for path in macos_paths:
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return True, path

    return False, None


def check_mlx_whisper_installed() -> bool:
    """Check if mlx-whisper is installed."""
    try:
        import mlx_whisper
        return True
    except Exception:
        return False


@dataclass
class MLXWhisperStatus:
    """Status of MLX Whisper setup."""
    is_apple_silicon: bool = False
    is_ffmpeg_installed: bool = False
    ffmpeg_path: Optional[str] = None
    is_mlx_whisper_installed: bool = False

    @property
    def is_fully_setup(self) -> bool:
        """Check if MLX Whisper is fully set up."""
        if not self.is_apple_silicon:
            return True  # Not applicable on non-Apple Silicon
        return self.is_ffmpeg_installed and self.is_mlx_whisper_installed


def check_mlx_whisper_status() -> MLXWhisperStatus:
    """Check MLX Whisper setup status."""
    status = MLXWhisperStatus()
    status.is_apple_silicon = is_apple_silicon()

    if status.is_apple_silicon:
        status.is_ffmpeg_installed, status.ffmpeg_path = check_ffmpeg_installed()
        status.is_mlx_whisper_installed = check_mlx_whisper_installed()

    return status


# Import config early (no PyQt6 dependency) - needed for detection functions
from jarvis.config import load_settings, get_default_config, get_config_path


class SetupStatus(Enum):
    """Status of a setup check."""
    PENDING = auto()
    CHECKING = auto()
    SUCCESS = auto()
    FAILED = auto()
    INSTALLING = auto()


@dataclass
class OllamaStatus:
    """Current status of Ollama setup."""
    is_cli_installed: bool = False
    cli_path: Optional[str] = None
    is_server_running: bool = False
    server_version: Optional[str] = None
    installed_models: List[str] = None
    missing_models: List[str] = None

    def __post_init__(self):
        if self.installed_models is None:
            self.installed_models = []
        if self.missing_models is None:
            self.missing_models = []

    @property
    def is_fully_setup(self) -> bool:
        """Check if Ollama is fully set up and ready."""
        return (
            self.is_cli_installed
            and self.is_server_running
            and len(self.missing_models) == 0
        )


def check_ollama_cli() -> Tuple[bool, Optional[str]]:
    """
    Check if Ollama CLI is installed.
    Returns (is_installed, path_to_ollama).
    """
    # Check common installation paths
    ollama_path = shutil.which("ollama")
    if ollama_path:
        return True, ollama_path

    # Check macOS-specific paths
    macos_paths = [
        "/usr/local/bin/ollama",
        "/opt/homebrew/bin/ollama",
        os.path.expanduser("~/bin/ollama"),
    ]

    for path in macos_paths:
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return True, path

    # Check Windows paths
    if sys.platform == "win32":
        windows_paths = [
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Ollama", "ollama.exe"),
            os.path.join(os.environ.get("PROGRAMFILES", ""), "Ollama", "ollama.exe"),
        ]
        for path in windows_paths:
            if os.path.isfile(path):
                return True, path

    return False, None


def check_ollama_server() -> Tuple[bool, Optional[str]]:
    """
    Check if Ollama server is running.
    Returns (is_running, version).
    """
    try:
        cfg = load_settings()
        base_url = cfg.ollama_base_url
    except Exception:
        base_url = "http://127.0.0.1:11434"

    from jarvis.llm import check_version
    return check_version(base_url, timeout=5.0)


def get_required_models() -> List[str]:
    """Get the Ollama models that must be present locally, given the active
    providers.

    Only models that actually run on Ollama are required:
    - Chat model + intent-judge model — when the chat provider is Ollama
      (both run through the chat backend). Skipped for an OpenAI-compatible
      chat provider, where those are remote model names, not Ollama pulls.
    - Embedding model — when the effective embedding provider is Ollama
      (covers the advanced split where chat is remote but embeddings are
      local). Skipped when embeddings are remote.

    A pure OpenAI-compatible setup therefore requires nothing locally.
    """
    try:
        cfg = load_settings()
        llm_provider = getattr(cfg, "llm_provider", "ollama") or "ollama"
        embed_provider = getattr(cfg, "embedding_provider", "") or llm_provider
        models = []

        # Chat model runs on the chat provider's backend.
        if llm_provider != "openai_compatible":
            if cfg.ollama_chat_model:
                models.append(cfg.ollama_chat_model)

        # Embedding model runs on the embedding provider's backend.
        if embed_provider != "openai_compatible":
            if cfg.ollama_embed_model and cfg.ollama_embed_model not in models:
                models.append(cfg.ollama_embed_model)

        # The fast model powers voice intent classification and the other
        # real-time passes, but is only an Ollama pull when the chat
        # provider is Ollama (config load resolves it per provider).
        if llm_provider != "openai_compatible":
            fast_model = getattr(cfg, "fast_model", DEFAULT_FAST_MODEL)
            if fast_model and fast_model not in models:
                models.append(fast_model)

        return models
    except Exception:
        # Default models if config can't be loaded
        defaults = [DEFAULT_CHAT_MODEL, DEFAULT_EMBEDDING_MODEL]
        if DEFAULT_FAST_MODEL not in defaults:
            defaults.append(DEFAULT_FAST_MODEL)
        return defaults


def resolve_ollama_path() -> str:
    """Resolve the ollama CLI path for subprocess invocation.

    PATH first, then platform-specific install locations via check_ollama_cli,
    then a literal "ollama" as last resort. Frozen .app launches on macOS get
    a sanitised PATH that excludes /usr/local/bin and /opt/homebrew/bin, so
    shutil.which alone is not enough.
    """
    path = shutil.which("ollama")
    if path:
        return path
    _, resolved = check_ollama_cli()
    return resolved or "ollama"


def check_installed_models(ollama_path: Optional[str] = None) -> List[str]:
    """
    Get list of installed Ollama models.
    Returns list of model names.
    """
    if ollama_path is None:
        ollama_path = resolve_ollama_path()

    try:
        # Hide console window on Windows
        creationflags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0

        result = subprocess.run(
            [ollama_path, "list"],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            timeout=30,
            creationflags=creationflags
        )

        if result.returncode != 0:
            return []

        # Parse output - format is "NAME ID SIZE MODIFIED"
        lines = result.stdout.strip().split("\n")
        models = []

        for line in lines[1:]:  # Skip header
            if line.strip():
                parts = line.split()
                if parts:
                    # Model name is the first column, may include :tag
                    model_name = parts[0]
                    models.append(model_name)

        return models
    except Exception:
        return []


def check_ollama_status() -> OllamaStatus:
    """Perform a complete check of Ollama status."""
    status = OllamaStatus()

    # Check CLI
    is_installed, cli_path = check_ollama_cli()
    status.is_cli_installed = is_installed
    status.cli_path = cli_path

    # Check server
    is_running, version = check_ollama_server()
    status.is_server_running = is_running
    status.server_version = version

    # Check models (only if CLI is installed AND server is running)
    # Running 'ollama list' when server isn't running causes it to hang
    if is_installed and is_running:
        required = get_required_models()
        installed = check_installed_models(cli_path)

        status.installed_models = installed
        status.missing_models = missing_ollama_models(required, installed)

    else:
        status.missing_models = get_required_models()

    return status


def should_show_setup_wizard(force_server_check: bool = False) -> bool:
    """
    Check if the setup wizard should be shown.

    Returns True only if user intervention is needed:
    - CLI not installed (user must install Ollama)
    - Models missing (user must download models)
    - Server unreachable after auto-start already failed (force_server_check)

    Does NOT return True just because server isn't running,
    since the app can auto-start the server if CLI is installed.
    Pass ``force_server_check=True`` after auto-start has already been
    attempted and failed to re-evaluate the unreachable-server case.
    """
    # An OpenAI-compatible user has opted out of the local Ollama stack,
    # so the Ollama-centric prerequisites don't apply — never auto-show.
    # (The wizard can still be opened manually from the tray to switch back.)
    try:
        cfg = load_settings()
        if getattr(cfg, "llm_provider", "ollama") == "openai_compatible":
            return False
    except Exception:
        pass

    status = check_ollama_status()

    # If CLI not installed, user needs to install Ollama
    if not status.is_cli_installed:
        return True

    # If server is running and models are missing, user needs to download them
    if status.is_server_running and len(status.missing_models) > 0:
        return True

    # If auto-start already failed and server is still unreachable,
    # the user needs to intervene to diagnose the problem.
    if force_server_check and not status.is_server_running:
        return True

    # If CLI is installed but server not running, we can start it ourselves
    # No need for wizard in this case
    return False


# --- PyQt6 UI components below ---
# These imports are wrapped to avoid import errors when only detection functions are needed
# (e.g., on headless CI systems where system Qt libraries may be missing)

import sys as _sys

try:
    from PyQt6.QtWidgets import (
        QApplication, QWizard, QWizardPage, QVBoxLayout, QHBoxLayout,
        QLabel, QPushButton, QProgressBar, QTextEdit, QWidget, QFrame,
        QSizePolicy, QScrollArea, QLineEdit, QSlider, QComboBox, QCheckBox,
        QDoubleSpinBox,
        QRadioButton, QButtonGroup, QStackedWidget, QLayout, QBoxLayout
    )
    from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QThread, QObject
    from PyQt6.QtGui import QFont, QColor, QPalette, QPixmap, QPainter

    from desktop_app.qt_worker import KeepAliveWorker
    from desktop_app.themes import JARVIS_THEME_STYLESHEET, WIZARD_STYLESHEET, COLORS, _ensure_icons, _ICON_STYLESHEET_TEMPLATE
    from desktop_app.mcp_catalogue import get_wizard_entries, MCPEntry

    # Import location utilities with crash protection for Windows native modules
    try:
        from jarvis.utils.location import (
            get_location_info,
            get_location_context,
            is_location_available,
            _get_database_path,
            _is_private_ip,
            _is_cgnat_ip,
            GEOIP2_AVAILABLE,
        )
    except Exception as e:
        if _sys.platform == 'win32':
            print(f"  ⚠️  Location utilities import failed: {e}", flush=True)
        # Provide stubs so the wizard can still run without location features
        get_location_info = lambda *a, **k: {}
        get_location_context = lambda *a, **k: "Location: Unknown"
        is_location_available = lambda: False
        _get_database_path = lambda: None
        _is_private_ip = lambda ip: True
        _is_cgnat_ip = lambda ip: False
        GEOIP2_AVAILABLE = False

    _PYQT6_AVAILABLE = True
except ImportError:
    _PYQT6_AVAILABLE = False
    # Define stubs so module can be imported for detection functions only
    # These stubs allow the class definitions to parse without errors
    QThread = object
    QWizard = object
    QWizardPage = object
    QWidget = object
    QFrame = object
    Qt = None
    QTimer = None
    QObject = None
    KeepAliveWorker = object

    def pyqtSignal(*args, **kwargs):
        """Stub for pyqtSignal when PyQt6 is not available."""
        return None

    # Stub location utilities that depend on themes
    JARVIS_THEME_STYLESHEET = ""
    COLORS = {}
    get_location_info = lambda *a, **k: {}
    get_location_context = lambda *a, **k: "Location: Unknown"
    is_location_available = lambda: False
    _get_database_path = lambda: None
    _is_private_ip = lambda ip: True
    _is_cgnat_ip = lambda ip: False
    GEOIP2_AVAILABLE = False


class StatusCheckWorker(KeepAliveWorker):
    """Worker thread for checking Ollama status."""
    status_ready = pyqtSignal(OllamaStatus)

    def run(self):
        status = check_ollama_status()
        self.status_ready.emit(status)


class CommandWorker(KeepAliveWorker):
    """Worker thread for running commands."""
    output = pyqtSignal(str)
    completed = pyqtSignal(bool, str)

    def __init__(self, command: List[str], parent=None):
        super().__init__(parent)
        self.command = command

    def run(self):
        try:
            # Use UTF-8 encoding with error replacement for cross-platform compatibility
            # Windows defaults to cp1252 which can't handle Ollama's UTF-8 output
            # Hide console window on Windows
            creationflags = 0
            if sys.platform == 'win32':
                creationflags = subprocess.CREATE_NO_WINDOW

            process = subprocess.Popen(
                self.command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding='utf-8',
                errors='replace',
                bufsize=1,
                creationflags=creationflags
            )

            for line in iter(process.stdout.readline, ""):
                if line:
                    self.output.emit(line.rstrip())

            process.wait()

            if process.returncode == 0:
                self.completed.emit(True, "✅ Command completed successfully")
            else:
                self.completed.emit(False, f"❌ Command failed with exit code {process.returncode}")
        except Exception as e:
            self.completed.emit(False, f"❌ Error: {str(e)}")


class ScrollableWizardPage(QWizardPage):
    """Keep page content at its minimum usable size inside a scroll viewport."""

    def resizeEvent(self, event):
        super().resizeEvent(event)
        columns = getattr(self, "_responsive_columns", None)
        if columns is not None:
            columns.setDirection(
                QBoxLayout.Direction.LeftToRight if self.width() >= 820
                else QBoxLayout.Direction.TopToBottom
            )

    def setLayout(self, layout):
        has_scroll = any(isinstance(layout.itemAt(i).widget(), QScrollArea)
                         for i in range(layout.count()))
        stage = {
            "WhisperSetupPage": 0, "ProviderChoicePage": 1,
            "WelcomePage": 1, "OpenAICompatiblePage": 1,
            "OllamaInstallPage": 1, "OllamaServerPage": 1, "ModelsPage": 1,
            "DictationPage": 2, "MCPPage": 2, "SearchProvidersPage": 2,
            "LocationPage": 2, "CompletePage": 3,
        }[type(self).__name__]
        header = QHBoxLayout()
        if has_scroll and layout.contentsMargins().left() == 0:
            header.setContentsMargins(28, 20, 28, 0)
        brand = QLabel("J A R V I S   /   SETUP")
        brand.setObjectName("setupBrand")
        header.addWidget(brand)
        header.addStretch()
        for index, name in enumerate(("Voice", "Intelligence", "Capabilities", "Ready")):
            label = QLabel(f"{index + 1:02}  {name}")
            label.setObjectName("setupStage")
            label.setProperty("active", index == stage)
            header.addWidget(label)
        layout.insertLayout(0, header)
        # Pages with a dedicated scroll area already provide overflow handling.
        if has_scroll:
            super().setLayout(layout)
            return
        content = QWidget()
        layout.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
        content.setLayout(layout)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(content)
        outer = QVBoxLayout()
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)
        super().setLayout(outer)


class SetupWizard(QWizard):
    """Main setup wizard window."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🚀 Jarvis Setup Wizard")
        self.setWizardStyle(QWizard.WizardStyle.ModernStyle)
        available = self.screen().availableGeometry()
        self.setMinimumSize(min(700, available.width() - 40),
                            min(500, available.height() - 80))
        self.resize(min(960, available.width() - 40),
                    min(780, available.height() - 80))

        # Apply dark theme
        self._apply_theme()

        # Add pages and store their IDs
        self.welcome_page = WelcomePage(self)
        self.provider_choice_page = ProviderChoicePage(self)
        self.openai_compat_page = OpenAICompatiblePage(self)
        self.ollama_install_page = OllamaInstallPage(self)
        self.ollama_server_page = OllamaServerPage(self)
        self.models_page = ModelsPage(self)
        self.mlx_whisper_page = WhisperSetupPage(self)
        self.dictation_page = DictationPage(self)
        self.mcp_page = MCPPage(self)
        self.search_providers_page = SearchProvidersPage(self)
        self.location_page = LocationPage(self)
        self.complete_page = CompletePage(self)

        self.welcome_page_id = self.addPage(self.welcome_page)
        self.mlx_whisper_page_id = self.addPage(self.mlx_whisper_page)
        self.provider_choice_page_id = self.addPage(self.provider_choice_page)
        self.openai_compat_page_id = self.addPage(self.openai_compat_page)
        self.ollama_install_page_id = self.addPage(self.ollama_install_page)
        self.ollama_server_page_id = self.addPage(self.ollama_server_page)
        self.models_page_id = self.addPage(self.models_page)
        self.dictation_page_id = self.addPage(self.dictation_page)
        self.mcp_page_id = self.addPage(self.mcp_page)
        self.search_providers_page_id = self.addPage(self.search_providers_page)
        self.location_page_id = self.addPage(self.location_page)
        self.complete_page_id = self.addPage(self.complete_page)

        # Speech recognition comes first; the provider choice then branches
        # to Ollama readiness or OpenAI-compatible connection settings.
        self.setStartId(self.mlx_whisper_page_id)

        # Custom button labels
        self.setButtonText(QWizard.WizardButton.NextButton, "Next →")
        self.setButtonText(QWizard.WizardButton.BackButton, "← Back")
        self.setButtonText(QWizard.WizardButton.FinishButton, "🎉 Start Jarvis")
        self.setButtonText(QWizard.WizardButton.CancelButton, "Exit")
        self.setButtonLayout([
            QWizard.WizardButton.CancelButton, QWizard.WizardButton.Stretch,
            QWizard.WizardButton.BackButton, QWizard.WizardButton.NextButton,
            QWizard.WizardButton.FinishButton,
        ])
        self.button(QWizard.WizardButton.NextButton).setObjectName("setupNext")
        self.button(QWizard.WizardButton.FinishButton).setObjectName("setupNext")

        # Store status for sharing between pages
        self.ollama_status: Optional[OllamaStatus] = None
        self.mlx_whisper_status: Optional[MLXWhisperStatus] = None
        self._location_working: Optional[bool] = None
        self._apply_theme()

    def ollama_entry_page_id(self) -> int:
        """First Ollama-flow page to show, based on detection status:
        install (CLI missing) → server (not running) → models. Shared by the
        provider-choice page so the Ollama branch lands on the right step."""
        status = self.ollama_status
        if status is None or not status.is_cli_installed:
            return self.ollama_install_page_id
        if not status.is_server_running:
            return self.ollama_server_page_id
        return self.models_page_id

    def is_location_working(self) -> bool:
        """Check if location detection is working (cached)."""
        if self._location_working is None:
            try:
                cfg = load_settings()
                # If location is disabled, treat as "working" so we skip the page
                if not getattr(cfg, 'location_enabled', True):
                    self._location_working = True
                else:
                    context = get_location_context(
                        config_ip=cfg.location_ip_address,
                        auto_detect=cfg.location_auto_detect,
                        resolve_cgnat_public_ip=cfg.location_cgnat_resolve_public_ip,
                    )
                    self._location_working = context != "Location: Unknown"
            except Exception:
                self._location_working = False
        return self._location_working

    def _apply_theme(self):
        """Apply the shared Jarvis theme with SVG indicator icons."""
        icons = _ensure_icons()
        icon_css = _ICON_STYLESHEET_TEMPLATE.format(**icons)
        self.setStyleSheet(JARVIS_THEME_STYLESHEET + icon_css + """
            /* Additional wizard-specific overrides */
            QLabel#title {
                color: #fbbf24;
                font-size: 24px;
                font-weight: bold;
            }
            QLabel#subtitle {
                color: #a1a1aa;
                font-size: 16px;
            }
            QLabel#status-success {
                color: #4ade80;
                font-size: 14px;
            }
            QLabel#status-warning {
                color: #fbbf24;
                font-size: 14px;
            }
            QLabel#status-error {
                color: #f87171;
                font-size: 14px;
            }
            QPushButton#secondary {
                background-color: #1a1d26;
                color: #f4f4f5;
            }
            QPushButton#secondary:hover {
                background-color: #1e222c;
                border-color: #f59e0b;
                color: #fbbf24;
            }
            QPushButton#success {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #22c55e, stop:1 #16a34a);
                color: #0a0b0f;
                border: none;
            }
            QPushButton#success:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #4ade80, stop:1 #22c55e);
            }
        """ + WIZARD_STYLESHEET)


class WelcomePage(ScrollableWizardPage):
    """Welcome page with status overview."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("")

        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setContentsMargins(28, 20, 28, 20)

        # Header
        header_layout = QVBoxLayout()

        title = QLabel("Welcome to your Jarvis")
        title.setObjectName("title")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(title)

        subtitle = QLabel("Your AI-powered voice assistant")
        subtitle.setObjectName("subtitle")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(subtitle)

        layout.addLayout(header_layout)
        layout.addSpacing(20)

        # Status card
        self.status_card = QFrame()
        self.status_card.setObjectName("card")
        status_layout = QVBoxLayout(self.status_card)
        status_layout.setContentsMargins(18, 16, 18, 16)
        status_layout.setSpacing(12)

        status_title = QLabel("📋 System Status")
        status_title.setObjectName("section_title")
        status_layout.addWidget(status_title)
        status_layout.addSpacing(8)

        # Status items
        self.cli_status = self._create_status_row("💻 Ollama CLI", "Checking...")
        self.server_status = self._create_status_row("🌐 Ollama Server", "Checking...")
        self.models_status = self._create_status_row("🧠 AI Models", "Checking...")
        self.location_status = self._create_status_row("📍 Location", "Checking...")

        # MLX Whisper status (only shown on Apple Silicon)
        self.mlx_whisper_status = self._create_status_row("🎤 MLX Whisper", "Checking...")
        self._is_apple_silicon = is_apple_silicon()

        status_layout.addWidget(self.cli_status)
        status_layout.addWidget(self.server_status)
        status_layout.addWidget(self.models_status)

        if self._is_apple_silicon:
            status_layout.addWidget(self.mlx_whisper_status)
        else:
            self.mlx_whisper_status.setVisible(False)

        status_layout.addWidget(self.location_status)

        layout.addWidget(self.status_card)

        # Refresh button
        self.refresh_btn = QPushButton("🔄 Refresh Status")
        self.refresh_btn.setObjectName("secondary")
        self.refresh_btn.clicked.connect(self._refresh_status)

        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(self.refresh_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        layout.addStretch()

        # Info label
        info = QLabel("Click 'Next' to continue with the setup process.")
        info.setWordWrap(True)
        info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info.setStyleSheet("color: #a1a1aa;")
        layout.addWidget(info)

        self.setLayout(layout)

        # Worker for background status check
        self.worker: Optional[StatusCheckWorker] = None

    def _create_status_row(self, label_text: str, status_text: str) -> QWidget:
        """Create a status row widget."""
        row = QWidget()
        row.setStyleSheet("background: transparent;")
        layout = QHBoxLayout(row)
        layout.setContentsMargins(0, 8, 0, 8)

        label = QLabel(label_text)
        label.setStyleSheet("font-size: 14px; background: transparent;")
        layout.addWidget(label)

        layout.addStretch()

        status = QLabel(status_text)
        status.setStyleSheet("font-size: 14px; color: #a1a1aa; background: transparent;")
        status.setObjectName("status_label")
        layout.addWidget(status)

        return row

    def _update_status_row(self, row: QWidget, status_text: str, is_success: bool):
        """Update a status row with new status."""
        status_label = row.findChild(QLabel, "status_label")
        if status_label:
            status_label.setText(status_text)
            if is_success:
                status_label.setStyleSheet("font-size: 14px; color: #4ade80; background: transparent;")
            else:
                status_label.setStyleSheet("font-size: 14px; color: #fbbf24; background: transparent;")

    def initializePage(self):
        """Called when page is shown."""
        self._refresh_status()

    def _refresh_status(self):
        """Refresh Ollama status."""
        self.refresh_btn.setEnabled(False)
        self.refresh_btn.setText("⏳ Checking...")

        # Reset status labels
        for row in [self.cli_status, self.server_status, self.models_status]:
            status_label = row.findChild(QLabel, "status_label")
            if status_label:
                status_label.setText("Checking...")
                status_label.setStyleSheet("font-size: 14px; color: #a1a1aa; background: transparent;")

        # Start background check
        self.worker = StatusCheckWorker()
        self.worker.status_ready.connect(self._on_status_checked)
        self.worker.start()

    def _on_status_checked(self, status: OllamaStatus):
        """Handle status check completion."""
        self.refresh_btn.setEnabled(True)
        self.refresh_btn.setText("🔄 Refresh Status")

        # Store status in wizard
        wizard = self.wizard()
        if isinstance(wizard, SetupWizard):
            wizard.ollama_status = status

        # Update CLI status
        if status.is_cli_installed:
            self._update_status_row(self.cli_status, f"✅ Installed ({status.cli_path})", True)
        else:
            self._update_status_row(self.cli_status, "❌ Not installed", False)

        # Update server status
        if status.is_server_running:
            self._update_status_row(self.server_status, f"✅ Running (v{status.server_version})", True)
        else:
            self._update_status_row(self.server_status, "❌ Not running", False)

        # Update models status
        if not status.missing_models:
            self._update_status_row(self.models_status, f"✅ All models ready ({len(status.installed_models)} installed)", True)
        else:
            self._update_status_row(self.models_status, f"⚠️ Missing: {', '.join(status.missing_models)}", False)

        # Update location status
        if not is_location_available():
            self._update_status_row(self.location_status, "⚠️ Database not installed", False)
        else:
            try:
                cfg = load_settings()
                location_context = get_location_context(
                    config_ip=cfg.location_ip_address,
                    auto_detect=cfg.location_auto_detect,
                    resolve_cgnat_public_ip=cfg.location_cgnat_resolve_public_ip,
                )
            except Exception:
                location_context = get_location_context(auto_detect=True, resolve_cgnat_public_ip=True)
            if location_context == "Location: Unknown":
                self._update_status_row(self.location_status, "⚠️ Not configured", False)
            else:
                # Extract just the location part after "Location: "
                loc_text = location_context.replace("Location: ", "")
                self._update_status_row(self.location_status, f"✅ {loc_text}", True)

        # Update MLX Whisper status (Apple Silicon only)
        if self._is_apple_silicon:
            mlx_status = check_mlx_whisper_status()
            if isinstance(wizard, SetupWizard):
                wizard.mlx_whisper_status = mlx_status

            if mlx_status.is_fully_setup:
                self._update_status_row(self.mlx_whisper_status, "✅ Ready (GPU acceleration)", True)
            elif not mlx_status.is_ffmpeg_installed:
                self._update_status_row(self.mlx_whisper_status, "⚠️ FFmpeg not installed", False)
            elif not mlx_status.is_mlx_whisper_installed:
                self._update_status_row(self.mlx_whisper_status, "⚠️ Not installed", False)
            else:
                self._update_status_row(self.mlx_whisper_status, "⚠️ Setup incomplete", False)

        # Enable/disable navigation based on status
        self.completeChanged.emit()

    def isComplete(self) -> bool:
        """Page is always complete - user can proceed."""
        return True

    def nextId(self) -> int:
        """The Welcome/status page is reached only on the Ollama branch (after
        the provider choice), so it leads into the Ollama install/server/models
        flow based on the detected status."""
        wizard = self.wizard()
        if not isinstance(wizard, SetupWizard):
            return super().nextId()
        return wizard.ollama_entry_page_id()


class ProviderChoicePage(ScrollableWizardPage):
    """Choose which local runtime serves the LLM: Ollama (the bundled
    default) or an OpenAI-compatible server (LM Studio, oMLX, llama.cpp's
    ``llama-server``, vLLM, LocalAI). The choice branches the rest of the
    wizard — Ollama continues to the install/server/models flow, while
    OpenAI-compatible jumps to a connection-config page and skips the
    Ollama-specific pages entirely."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("")
        self._selected = "ollama"

        layout = QVBoxLayout()
        layout.setSpacing(16)
        layout.setContentsMargins(28, 20, 28, 20)

        title = QLabel("Choose your local intelligence")
        title.setObjectName("title")
        layout.addWidget(title)

        subtitle = QLabel(
            "Two ways to run Jarvis. Your models stay on hardware you control."
        )
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        layout.addSpacing(4)

        # A QButtonGroup makes the radios mutually exclusive even though each
        # lives in its own card (Qt's auto-exclusivity only applies to radios
        # sharing a direct parent, which these do not).
        self._button_group = QButtonGroup(self)
        choices = QHBoxLayout()
        self._responsive_columns = choices
        choices.setSpacing(20)

        self._ollama_radio = QRadioButton("  🦙  Ollama (recommended)")
        self._ollama_radio.setChecked(True)
        self._button_group.addButton(self._ollama_radio)
        ollama_card = self._provider_card(
            self._ollama_radio,
            "Runs open models locally on this machine. The wizard installs "
            "Ollama and downloads the models for you. Best if you have no "
            "model server already.",
        )
        choices.addWidget(ollama_card, 1)

        self._openai_radio = QRadioButton("  🔗  OpenAI-compatible server")
        self._button_group.addButton(self._openai_radio)
        openai_card = self._provider_card(
            self._openai_radio,
            "Point Jarvis at a server that speaks the OpenAI API. This is "
            "usually another local app (LM Studio, oMLX, llama.cpp, vLLM, "
            "LocalAI) running on your own machine or network. You provide its "
            "URL and model name on the next step.",
        )
        choices.addWidget(openai_card, 1)
        layout.addLayout(choices)

        self._ollama_radio.toggled.connect(self._on_toggle)
        self._openai_radio.toggled.connect(self._on_toggle)

        layout.addStretch()
        self.setLayout(layout)

        self._preselect_from_config()

    def _provider_card(self, radio, desc_text):
        card = QFrame()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(16, 14, 16, 14)
        card_layout.setSpacing(6)
        radio.setStyleSheet("font-size: 15px; font-weight: bold;")
        card_layout.addWidget(radio)
        desc = QLabel(desc_text)
        desc.setWordWrap(True)
        desc.setStyleSheet("color: #a1a1aa; font-size: 13px;")
        card_layout.addWidget(desc)
        card_layout.addStretch()
        def update_selection():
            card.setProperty("selected", radio.isChecked())
            card.style().unpolish(card)
            card.style().polish(card)
            card.update()
        radio.toggled.connect(update_selection)
        update_selection()
        return card

    def _preselect_from_config(self):
        try:
            from jarvis.config import get_config_path, _load_json
            config = _load_json(get_config_path()) or {}
            provider = str(config.get("llm_provider", "ollama") or "ollama")
        except Exception:
            provider = "ollama"
        if provider == "openai_compatible":
            self._openai_radio.setChecked(True)
            self._selected = "openai_compatible"
        else:
            self._ollama_radio.setChecked(True)
            self._selected = "ollama"

    def _on_toggle(self):
        self._selected = (
            "openai_compatible" if self._openai_radio.isChecked() else "ollama"
        )

    def validatePage(self) -> bool:
        """Persist the provider choice. Selecting Ollama clears any
        OpenAI-compatible overrides so the Ollama settings become
        authoritative again — no stale base URL / key / model is left
        pointing at a former remote server."""
        try:
            from jarvis.config import get_config_path, _load_json, _save_json
            config_path = get_config_path()
            config = _load_json(config_path) or {}

            if self._selected == "openai_compatible":
                config["llm_provider"] = "openai_compatible"
            else:
                # Ollama is the default; omit the key and drop the
                # OpenAI-compatible connection overrides.
                config.pop("llm_provider", None)
                for stale in (
                    "llm_base_url", "llm_api_key", "llm_chat_model",
                    "embedding_provider", "embedding_base_url",
                    "embedding_api_key", "embedding_model",
                ):
                    config.pop(stale, None)

            config_path.parent.mkdir(parents=True, exist_ok=True)
            _save_json(config_path, config)
        except Exception:
            pass
        return True

    def isComplete(self) -> bool:
        return True

    def nextId(self) -> int:
        wizard = self.wizard()
        if not isinstance(wizard, SetupWizard):
            return super().nextId()
        if self._selected == "openai_compatible":
            return wizard.openai_compat_page_id
        return wizard.welcome_page_id


class _ModelFetchWorker(KeepAliveWorker):
    """Fetches the model list from an OpenAI-compatible server off the UI
    thread so the wizard never freezes while connecting."""

    done = pyqtSignal(bool, list)  # (reached, model_ids)

    def __init__(self, base_url: str, api_key: str):
        super().__init__()
        self._base_url = base_url
        self._api_key = api_key

    def run(self):
        models = OpenAICompatiblePage._fetch_models(self._base_url, self._api_key)
        self.done.emit(bool(models), models)


class _DiscoveryWorker(KeepAliveWorker):
    """Probes well-known local ports for a running OpenAI-compatible server so
    the wizard can offer a one-click pick instead of asking for a URL."""

    done = pyqtSignal(list)  # list of (label, url)

    def __init__(self, candidates: list):
        super().__init__()
        self._candidates = candidates

    def run(self):
        self.done.emit(OpenAICompatiblePage._discover_servers(self._candidates))


class _CapabilityWorker(KeepAliveWorker):
    """Probes what the chosen server+model can actually do (chat, tools,
    embeddings) off the UI thread, so the wizard catches a dud model or a
    missing embeddings endpoint before setup finishes rather than at runtime."""

    done = pyqtSignal(object)  # ServerCapabilities

    def __init__(self, base_url: str, api_key: str, chat_model: str, embed_model: str):
        super().__init__()
        self._base_url = base_url
        self._api_key = api_key
        self._chat_model = chat_model
        self._embed_model = embed_model

    def run(self):
        try:
            from jarvis.llm import OpenAICompatibleBackend, ServerCapabilities
            backend = OpenAICompatibleBackend(self._base_url, api_key=self._api_key or None)
            caps = backend.check_capabilities(self._chat_model, self._embed_model or None)
        except Exception:
            from jarvis.llm import ServerCapabilities
            caps = ServerCapabilities()
        self.done.emit(caps)


class OpenAICompatiblePage(ScrollableWizardPage):
    """Collect the OpenAI-compatible server's connection and model details.

    Guided rather than freeform: the page auto-discovers running local
    servers, offers a one-click app preset, and (after Connect) fetches the
    server's actual model list into editable dropdowns with sensible defaults.
    A single Connect then probes the chosen model so the user learns up front
    whether chat, tool calling, and embeddings work, and is offered the
    Ollama-embeddings fallback when the server can't embed. Power users can
    still type any base URL or model id by hand.
    """

    _DEFAULT_BASE_URL = "http://localhost:1234/v1"  # LM Studio default

    # Well-known local OpenAI-compatible servers, used both for the app preset
    # picker and for auto-discovery. All loopback, so probing never leaves the
    # machine.
    _KNOWN_SERVERS = [
        ("LM Studio", "http://localhost:1234/v1"),
        ("Ollama (OpenAI API)", "http://localhost:11434/v1"),
        ("Jan", "http://localhost:1337/v1"),
        ("llama.cpp / LocalAI", "http://localhost:8080/v1"),
        ("vLLM", "http://localhost:8000/v1"),
        ("oMLX (ol.mlx)", "http://localhost:9876/v1"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("")
        self._fetch_worker = None
        self._discovery_worker = None
        self._cap_worker = None

        layout = QVBoxLayout()
        layout.setSpacing(14)
        layout.setContentsMargins(28, 20, 28, 20)

        title = QLabel("Connect your model server")
        title.setObjectName("title")
        layout.addWidget(title)

        subtitle = QLabel(
            "Choose your local server, then select the models Jarvis will use."
        )
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        layout.addSpacing(4)

        columns = QHBoxLayout()
        self._responsive_columns = columns
        columns.setSpacing(20)
        form_card = QFrame()
        form_card.setObjectName("card")
        form = QVBoxLayout(form_card)
        form.setContentsMargins(16, 14, 16, 14)
        form.setSpacing(10)
        connection_title = QLabel("01  Connection")
        connection_title.setObjectName("section_title")
        form.addWidget(connection_title)

        # App preset: prefills the base URL for a known server so the user
        # never has to remember a port.
        preset_label = QLabel("Your app")
        preset_label.setStyleSheet("font-size: 13px; font-weight: bold;")
        form.addWidget(preset_label)
        self._preset_combo = QComboBox()
        self._preset_combo.addItem("Select your app (optional)…")
        for label, _url in self._KNOWN_SERVERS:
            self._preset_combo.addItem(label)
        self._preset_combo.addItem("Other / custom")
        self._preset_combo.currentIndexChanged.connect(self._on_preset_changed)
        form.addWidget(self._preset_combo)

        self._base_url_input = self._labelled_edit(
            form, "Base URL",
            "http://localhost:1234/v1")
        self._api_key_input = self._labelled_edit(
            form, "API key (optional)", "leave empty if your server needs none",
            password=True)

        # Connect button + status: fetch the model list, then probe the model.
        self._connect_btn = QPushButton("Connect && load models")
        self._connect_btn.setObjectName("secondary")
        self._connect_btn.clicked.connect(self._on_connect)
        form.addWidget(self._connect_btn)
        self._connect_status = QLabel("")
        self._connect_status.setWordWrap(True)
        self._connect_status.setStyleSheet(
            f"font-size: 12px; color: {COLORS['text_secondary']};")
        form.addWidget(self._connect_status)
        form.addStretch()
        columns.addWidget(form_card, 1)

        model_card = QFrame()
        model_card.setObjectName("card")
        form = QVBoxLayout(model_card)
        form.setContentsMargins(20, 20, 20, 20)
        form.setSpacing(10)
        models_title = QLabel("02  Models")
        models_title.setObjectName("section_title")
        form.addWidget(models_title)

        self._chat_model_combo = self._labelled_combo(
            form, "Chat model", "Select or enter a model")
        self._embed_model_combo = self._labelled_combo(
            form, "Embedding model (optional)",
            "Optional, for memory search")

        # Fast model link toggle + selector
        self._openai_linked = False
        self._openai_link_cb = QCheckBox(
            "Use chat model for fast tasks")
        self._openai_link_cb.setChecked(False)
        self._openai_link_cb.setStyleSheet("font-size: 13px; color: #e4e4e7; padding: 4px 0;")
        self._openai_link_cb.toggled.connect(self._on_openai_link_toggled)
        form.addWidget(self._openai_link_cb)

        # Fast model selector: label + combo stored for visibility toggling
        self._fast_label = QLabel("Fast model · voice & tools")
        self._fast_label.setStyleSheet("font-size: 13px; font-weight: bold;")
        form.addWidget(self._fast_label)
        self._fast_model_combo = QComboBox()
        self._fast_model_combo.setEditable(True)
        self._fast_model_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self._fast_model_combo.setMinimumContentsLength(16)
        self._fast_model_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._fast_model_combo.lineEdit().setPlaceholderText(
            "leave empty to use the chat model")
        self._fast_model_combo.currentTextChanged.connect(
            lambda *_: self.completeChanged.emit())
        form.addWidget(self._fast_model_combo)
        self._fast_label.setVisible(True)
        self._fast_model_combo.setVisible(True)

        # Shown only when the probe finds the server can't embed: a one-click
        # way to keep full semantic memory by routing embeddings to Ollama.
        self._use_ollama_embed = QCheckBox(
            "Use Ollama for memory embeddings")
        self._use_ollama_embed.setVisible(False)
        self._use_ollama_embed.toggled.connect(lambda *_: self.completeChanged.emit())
        form.addWidget(self._use_ollama_embed)

        form.addStretch()
        columns.addWidget(model_card, 1)
        layout.addLayout(columns)

        memory_card = QFrame()
        memory_card.setObjectName("card")
        memory_layout = QVBoxLayout(memory_card)
        memory_layout.setContentsMargins(20, 10, 20, 10)
        memory_layout.setSpacing(4)
        memory_header = QHBoxLayout()
        memory_title = QLabel("03  Memory budget")
        memory_title.setObjectName("section_title")
        memory_header.addWidget(memory_title)
        memory_header.addStretch()
        self._memory_toggle = QPushButton("Edit estimates ↓")
        self._memory_toggle.setObjectName("secondary")
        self._memory_toggle.clicked.connect(self._toggle_memory_details)
        memory_header.addWidget(self._memory_toggle)
        memory_layout.addLayout(memory_header)
        self._memory_summary = QLabel()
        self._memory_summary.setObjectName("memory_summary")
        self._memory_summary.setWordWrap(True)
        self._memory_summary.setStyleSheet(
            f"font-size: 13px; color: {COLORS['text_secondary']};")
        memory_layout.addWidget(self._memory_summary)

        self._memory_details = QWidget()
        self._memory_details.setObjectName("memoryDetails")
        self._memory_details.setStyleSheet(
            "QWidget#memoryDetails { background: transparent; }")
        detail_layout = QVBoxLayout(self._memory_details)
        detail_layout.setContentsMargins(0, 8, 0, 0)
        detail_layout.setSpacing(8)
        memory_hint = QLabel(
            "Model lists do not report memory needs. Adjust these estimates "
            "for your model, quantisation and context length."
        )
        memory_hint.setWordWrap(True)
        memory_hint.setStyleSheet(f"font-size: 12px; color: {COLORS['text_secondary']};")
        detail_layout.addWidget(memory_hint)
        self._memory_estimates = {}
        self._memory_model_ids = {}
        self._manual_memory_estimates = {}
        for role, label_text in (
            ("chat", "Chat model"),
            ("fast", "Fast model"),
            ("embed", "Embeddings"),
        ):
            row = QHBoxLayout()
            row.setSpacing(12)
            label = QLabel(label_text)
            row.addWidget(label, 1)
            estimate = QDoubleSpinBox()
            estimate.setObjectName(f"memory_{role}")
            estimate.setAccessibleName(f"{label_text} memory estimate in GB")
            estimate.setRange(0, 1024)
            estimate.setDecimals(1)
            estimate.setSingleStep(0.5)
            estimate.setSuffix(" GB")
            estimate.setSpecialValueText("Unknown")
            estimate.setKeyboardTracking(False)
            estimate.setMinimumWidth(116)
            estimate.valueChanged.connect(
                lambda value, role=role: self._on_memory_estimate_changed(role, value))
            row.addWidget(estimate)
            self._memory_estimates[role] = estimate
            detail_layout.addLayout(row)
        memory_layout.addWidget(self._memory_details)
        self._memory_details.setVisible(False)
        layout.addWidget(memory_card)
        self._detected_vram_mb = detect_total_vram_mb()
        self._refresh_memory_runtime()

        self._chat_model_combo.currentTextChanged.connect(self._refresh_memory_display)
        self._fast_model_combo.currentTextChanged.connect(self._refresh_memory_display)
        self._embed_model_combo.currentTextChanged.connect(self._refresh_memory_display)
        self._base_url_input.textChanged.connect(self._refresh_memory_display)
        self._use_ollama_embed.toggled.connect(self._refresh_memory_display)
        self._openai_link_cb.toggled.connect(self._refresh_memory_display)

        tip = QLabel(
            "Only a server URL and chat model are required. "
            "Without embeddings, memory uses keyword search."
        )
        tip.setWordWrap(True)
        tip.setStyleSheet(
            "background: rgba(245, 158, 11, 0.10);"
            "border: 1px solid rgba(245, 158, 11, 0.25);"
            "border-radius: 8px; padding: 12px 16px; color: #fbbf24; font-size: 13px;"
        )
        layout.addWidget(tip)

        layout.addStretch()
        self.setLayout(layout)
        self._refresh_memory_display()

    def _toggle_memory_details(self):
        expanded = self._memory_details.isHidden()
        self._memory_details.setVisible(expanded)
        self._memory_toggle.setText("Hide estimates ↑" if expanded else "Edit estimates ↓")

    @staticmethod
    def _server_is_loopback(base_url: str) -> bool:
        """Only compare a model server with the local GPU on loopback URLs."""
        try:
            host = urlsplit(base_url).hostname
            if host == "localhost":
                return True
            return bool(host and ipaddress.ip_address(host).is_loopback)
        except ValueError:
            return False

    @staticmethod
    def _known_memory_mb(model_id: str) -> Optional[int]:
        """Known local model estimates; unknown server ids stay editable."""
        if model_id == DEFAULT_EMBEDDING_MODEL:
            return 1024
        return required_vram_mb(model_id)

    def _refresh_memory_runtime(self):
        """Read the local Whisper and Ollama setup for the current wizard visit."""
        try:
            settings = load_settings()
        except Exception:
            settings = None
        whisper_id = getattr(settings, "whisper_model", "small") or "small"
        self._whisper_memory_mb = get_whisper_vram_mb(whisper_id)
        self._ollama_embed_model_id = (
            getattr(settings, "ollama_embed_model", DEFAULT_EMBEDDING_MODEL)
            or DEFAULT_EMBEDDING_MODEL
        )
        self._ollama_embed_base_url = (
            getattr(settings, "ollama_base_url", "http://localhost:11434")
            or "http://localhost:11434"
        )

    def _on_memory_estimate_changed(self, role: str, value: float):
        model_id = self._memory_model_ids.get(role)
        if model_id:
            self._manual_memory_estimates[model_id] = value
        self._refresh_memory_display()

    def _refresh_memory_display(self, *_):
        if not hasattr(self, "_memory_estimates"):
            return
        chat_id = self._chat_model_combo.currentText().strip()
        fast_id = self._fast_model_combo.currentText().strip()
        embed_on_ollama = self._use_ollama_embed.isChecked()
        embed_id = (
            self._ollama_embed_model_id if embed_on_ollama
            else self._embed_model_combo.currentText().strip()
        )
        ids = {"chat": chat_id, "fast": fast_id, "embed": embed_id}
        for role, model_id in ids.items():
            field = self._memory_estimates[role]
            estimate = self._manual_memory_estimates.get(
                model_id, (self._known_memory_mb(model_id) or 0) / 1024)
            if (self._memory_model_ids.get(role) == model_id
                    and field.value() == estimate):
                continue
            field.blockSignals(True)
            field.setValue(estimate)
            field.blockSignals(False)
            self._memory_model_ids[role] = model_id

        distinct_fast = bool(fast_id and not self._openai_linked and fast_id != chat_id)
        self._memory_estimates["fast"].setEnabled(distinct_fast)
        self._memory_estimates["embed"].setEnabled(bool(embed_id))
        if not chat_id:
            self._memory_summary.setText("Choose a chat model to see its memory budget.")
            return

        needed = ["chat"]
        if distinct_fast:
            needed.append("fast")
        if embed_id:
            needed.append("embed")
        unknown = [role for role in needed if self._memory_estimates[role].value() == 0]
        if unknown:
            names = {"chat": "chat", "fast": "fast", "embed": "embeddings"}
            missing = ", ".join(names[role] for role in unknown)
            self._memory_summary.setText(
                f"Add a GB estimate for {missing} to see a total. "
                "The server does not provide memory requirements."
            )
            return

        chat_gb = self._memory_estimates["chat"].value()
        fast_gb = self._memory_estimates["fast"].value() if distinct_fast else 0
        embed_gb = self._memory_estimates["embed"].value() if embed_id else 0
        whisper_gb = self._whisper_memory_mb / 1024
        local_server = self._server_is_loopback(self._base_url_input.text().strip())
        local_ollama = embed_on_ollama and self._server_is_loopback(self._ollama_embed_base_url)
        server_gb = chat_gb + fast_gb + (0 if embed_on_ollama else embed_gb)
        local_gb = whisper_gb + (server_gb if local_server else 0)
        if local_ollama:
            local_gb += embed_gb
        if local_server:
            detail = (
                f"Estimated model memory: {server_gb:.1f} GB. "
                f"Whisper ~{whisper_gb:.1f} GB locally. "
            )
            if local_ollama:
                detail += f"Ollama embeddings: {embed_gb:.1f} GB locally. "
            detail += f"Combined ~{local_gb:.1f} GB if they share a GPU."
            if self._detected_vram_mb is not None:
                gpu_gb = self._detected_vram_mb / 1024
                if local_gb > gpu_gb:
                    detail += f" ⚠️ About {local_gb - gpu_gb:.1f} GB over the detected {gpu_gb:.1f} GB GPU."
                else:
                    detail += f" Detected GPU: {gpu_gb:.1f} GB."
            if embed_on_ollama and not local_ollama:
                detail += f" Ollama embeddings: {embed_gb:.1f} GB on its server."
        else:
            detail = f"Server model estimate: {server_gb:.1f} GB. "
            if embed_on_ollama:
                location = "locally" if local_ollama else "on its server"
                detail += f"Ollama embeddings: {embed_gb:.1f} GB {location}. "
            detail += f"Whisper ~{whisper_gb:.1f} GB locally. Check which servers share a GPU."
        self._memory_summary.setText(detail)

    def _labelled_edit(self, form, label_text, placeholder, password=False):
        label = QLabel(label_text)
        label.setStyleSheet("font-size: 13px; font-weight: bold;")
        form.addWidget(label)
        field = QLineEdit()
        field.setPlaceholderText(placeholder)
        if password:
            field.setEchoMode(QLineEdit.EchoMode.Password)
        # Re-evaluate Next: the base URL is half of isComplete, so editing it
        # must refresh the button (the chat-model combo does the same).
        field.textChanged.connect(lambda *_: self.completeChanged.emit())
        form.addWidget(field)
        return field

    def _labelled_combo(self, form, label_text, placeholder):
        label = QLabel(label_text)
        label.setStyleSheet("font-size: 13px; font-weight: bold;")
        form.addWidget(label)
        combo = QComboBox()
        combo.setEditable(True)  # power users can type a model the listing omits
        combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        combo.setMinimumContentsLength(16)
        combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        combo.lineEdit().setPlaceholderText(placeholder)
        combo.currentTextChanged.connect(lambda *_: self.completeChanged.emit())
        form.addWidget(combo)
        return combo

    @staticmethod
    def _fetch_models(base_url: str, api_key: str, timeout: float = 6.0) -> list:
        """Return the model ids the server advertises at ``/v1/models``, or
        an empty list if it is unreachable. Fail-soft: never raises, so the
        user can still type a model id by hand."""
        base_url = (base_url or "").strip()
        if not base_url:
            return []
        try:
            from jarvis.llm import OpenAICompatibleBackend
            backend = OpenAICompatibleBackend(base_url, api_key=(api_key or "").strip() or None)
            return list(backend.list_models(timeout_sec=timeout))
        except Exception:
            return []

    @staticmethod
    def _discover_servers(candidates: list, timeout: float = 1.5) -> list:
        """Probe well-known local ports for a running OpenAI-compatible server.
        Only loopback addresses are probed, so discovery never touches the
        network. Returns the reachable ``(label, url)`` pairs."""
        found = []
        for label, url in candidates:
            if OpenAICompatiblePage._fetch_models(url, "", timeout=timeout):
                found.append((label, url))
        return found

    @staticmethod
    def _classify_models(models: list) -> tuple:
        """Split advertised ids into ``(chat, embed)`` by an id heuristic.
        Model ids are vendor tokens rather than natural language, so matching
        ``embed`` in the id stays language-agnostic."""
        embed = [m for m in models if "embed" in m.lower()]
        chat = [m for m in models if "embed" not in m.lower()]
        return chat, embed

    @staticmethod
    def _preferred_fast_default(models: list) -> str:
        """Return ``gemma4:e2b`` when it appears in the model list, otherwise
        empty string (user picks or types)."""
        for m in models:
            if m == "gemma4:e2b":
                return m
        return ""

    def _on_preset_changed(self, idx: int):
        # idx 0 is the placeholder and the last item is "Other / custom"; the
        # ones in between map to _KNOWN_SERVERS and prefill the base URL.
        if 1 <= idx <= len(self._KNOWN_SERVERS):
            _label, url = self._KNOWN_SERVERS[idx - 1]
            self._base_url_input.setText(url)

    def _on_openai_link_toggled(self, linked: bool):
        """Show/hide the fast model selector when toggling the link checkbox."""
        self._openai_linked = linked
        self._fast_label.setVisible(not linked)
        self._fast_model_combo.setVisible(not linked)
        if linked:
            self._fast_model_combo.setCurrentText("")
        self.completeChanged.emit()

    def _on_connect(self):
        base_url = (self._base_url_input.text() or "").strip()
        if not base_url:
            self._connect_status.setText("⚠️ Enter a base URL first.")
            return
        self._connect_btn.setEnabled(False)
        self._connect_status.setText("⏳ Connecting…")
        worker = _ModelFetchWorker(base_url, (self._api_key_input.text() or "").strip())
        worker.done.connect(self._on_models_fetched)
        self._fetch_worker = worker  # keep a reference so it isn't GC'd
        worker.start()

    def _on_models_fetched(self, reached: bool, models: list):
        self._populate_models(models)
        if not (reached and models):
            self._connect_btn.setEnabled(True)
            self._connect_status.setText(
                "⚠️ Couldn't load models. Check the URL/key and that the server "
                "is running, or type the model id manually below.")
            self.completeChanged.emit()
            return
        # Models loaded and a sensible chat default is selected — probe the
        # model so the user learns up front what works.
        chat = (self._chat_model_combo.currentText() or "").strip()
        base = (self._base_url_input.text() or "").strip()
        if base and chat:
            self._connect_status.setText(
                f"✅ Connected — {len(models)} model(s). Checking {chat}…")
            self._start_capability_probe()
        else:
            self._connect_btn.setEnabled(True)
            self._connect_status.setText(f"✅ Connected — {len(models)} model(s) found.")
        self.completeChanged.emit()

    def _start_capability_probe(self):
        base = (self._base_url_input.text() or "").strip()
        chat = (self._chat_model_combo.currentText() or "").strip()
        if not (base and chat):
            self._connect_btn.setEnabled(True)
            return
        self._connect_btn.setEnabled(False)
        worker = _CapabilityWorker(
            base, (self._api_key_input.text() or "").strip(),
            chat, (self._embed_model_combo.currentText() or "").strip())
        worker.done.connect(self._on_capabilities)
        self._cap_worker = worker  # keep a reference so it isn't GC'd
        worker.start()

    def _on_capabilities(self, caps):
        self._connect_btn.setEnabled(True)
        self._connect_status.setText(self._capability_summary(caps))
        # Offer the Ollama-embeddings split only when the server clearly works
        # for chat but cannot embed.
        needs_split = bool(getattr(caps, "reachable", False)
                           and getattr(caps, "chat", False)
                           and not getattr(caps, "embeddings", False))
        self._use_ollama_embed.setVisible(needs_split)
        if not needs_split:
            self._use_ollama_embed.setChecked(False)
        self.completeChanged.emit()

    @staticmethod
    def _capability_summary(caps) -> str:
        """Honest one-line verdict on what the chosen server+model can do."""
        if not getattr(caps, "reachable", False):
            return ("⚠️ Couldn't get a response with that model. Check the URL, "
                    "key, and that the model id is loaded on the server.")
        mark = lambda ok: "✅" if ok else "⚠️"
        parts = [f"{mark(caps.chat)} Chat", f"{mark(caps.tools)} Tool calling"]
        parts.append("✅ Embeddings" if caps.embeddings
                     else "⚠️ No embeddings (memory uses keyword search)")
        return "   ".join(parts)

    def _populate_models(self, models: list):
        """Fill the dropdowns with fetched model ids. Embedding-named ids go to
        the embedding box and the rest to chat; if the heuristic finds none of
        a kind, both boxes get the full list. A value the user already
        typed/selected is preserved, otherwise a sensible default is applied so
        the common case is just Connect then Next."""
        chat_models, embed_models = self._classify_models(models)
        # The chat box lists chat models (or the full list if the heuristic
        # found none), but only auto-selects a real chat model — never an
        # embedding model, which would be a wrong default.
        self._fill_combo(self._chat_model_combo, chat_models or models, blank=False,
                         default=(chat_models[0] if chat_models else ""))
        self._fill_combo(self._embed_model_combo, embed_models or models, blank=True,
                         default=(embed_models[0] if embed_models else ""))
        self._fill_combo(self._fast_model_combo, models, blank=True,
                         default=self._preferred_fast_default(models))
        self._refresh_memory_display()

    def _fill_combo(self, combo, items, *, blank: bool, default: str):
        current = (combo.currentText() or "").strip()
        combo.blockSignals(True)
        combo.clear()
        if blank:
            combo.addItem("")  # "(none)" — embeddings optional
        for it in items:
            combo.addItem(it)
        combo.setCurrentText(current or default)
        combo.blockSignals(False)

    def initializePage(self):
        """Pre-fill from any existing config so re-running the wizard keeps the
        user's values. With no saved URL, default to the common LM Studio
        address and kick off auto-discovery of running local servers."""
        try:
            from jarvis.config import get_config_path, _load_json
            config = _load_json(get_config_path()) or {}
        except Exception:
            config = {}
        saved_url = str(config.get("llm_base_url", "") or "")
        self._base_url_input.setText(saved_url or self._DEFAULT_BASE_URL)
        self._api_key_input.setText(str(config.get("llm_api_key", "") or ""))
        self._chat_model_combo.setCurrentText(str(config.get("llm_chat_model", "") or ""))
        self._embed_model_combo.setCurrentText(str(config.get("embedding_model", "") or ""))
        saved_fast = str(config.get("fast_model", "") or "")
        self._fast_model_combo.setCurrentText(saved_fast)
        if saved_fast:
            self._openai_linked = False
            self._openai_link_cb.setChecked(False)
            self._fast_label.setVisible(True)
            self._fast_model_combo.setVisible(True)
        self._use_ollama_embed.setVisible(False)
        self._connect_status.setText("")
        self._refresh_memory_runtime()
        self._refresh_memory_display()
        # Only auto-discover when the user hasn't already saved a custom URL.
        if not saved_url:
            self._start_discovery()

    def _start_discovery(self):
        self._connect_status.setText("🔍 Looking for local servers…")
        worker = _DiscoveryWorker(list(self._KNOWN_SERVERS))
        worker.done.connect(self._on_discovered)
        self._discovery_worker = worker  # keep a reference so it isn't GC'd
        worker.start()

    def _on_discovered(self, found: list):
        if not found:
            self._connect_status.setText("")  # nothing running; user enters details
            return
        label, url = found[0]
        # Prefill the first hit unless the user already changed the default.
        if (self._base_url_input.text() or "").strip() in ("", self._DEFAULT_BASE_URL):
            self._base_url_input.setText(url)
        if len(found) == 1:
            self._connect_status.setText(
                f"🔍 Found {label} at {url} — click Connect to load its models.")
        else:
            names = ", ".join(l for l, _ in found)
            self._connect_status.setText(
                f"🔍 Found {len(found)} servers ({names}). Pick one above, then Connect.")

    @staticmethod
    def _is_ready(base_url: str, chat_model: str) -> bool:
        return bool((base_url or "").strip()) and bool((chat_model or "").strip())

    def _read_inputs(self):
        return (
            (self._base_url_input.text() or "").strip(),
            (self._api_key_input.text() or "").strip(),
            (self._chat_model_combo.currentText() or "").strip(),
            (self._embed_model_combo.currentText() or "").strip(),
            (self._fast_model_combo.currentText() or "").strip(),
        )

    def isComplete(self) -> bool:
        base_url, _, chat_model, _, _ = self._read_inputs()
        return self._is_ready(base_url, chat_model)

    def validatePage(self) -> bool:
        """Persist the connection details. Required fields are always
        written; optional ones (API key, embedding model) are omitted when
        empty to keep config.json minimal."""
        base_url, api_key, chat_model, embed_model, fast_model = self._read_inputs()
        if not self._is_ready(base_url, chat_model):
            return False
        try:
            from jarvis.config import get_config_path, _load_json, _save_json
            config_path = get_config_path()
            config = _load_json(config_path) or {}

            config["llm_provider"] = "openai_compatible"
            config["llm_base_url"] = base_url
            config["llm_chat_model"] = chat_model
            if api_key:
                config["llm_api_key"] = api_key
            else:
                config.pop("llm_api_key", None)

            # Embeddings: when the server can't embed and the user opted for the
            # Ollama fallback, route embeddings to Ollama and drop the remote
            # embedding model (Ollama's default applies). Otherwise keep
            # embeddings on this provider, writing the model only when set.
            if self._use_ollama_embed.isVisible() and self._use_ollama_embed.isChecked():
                config["embedding_provider"] = "ollama"
                config.pop("embedding_model", None)
            else:
                config.pop("embedding_provider", None)
                if embed_model:
                    config["embedding_model"] = embed_model
                else:
                    config.pop("embedding_model", None)

            # Save fast model: when linked it's left empty (defaults to chat)
            # Save fast model: write only when unlinked and non-empty
            is_linked = True  # safe default (backward compat for __new__-constructed pages)
            try:
                is_linked = self._openai_linked
            except Exception:
                pass
            config["fast_model"] = fast_model if (not is_linked and fast_model) else ""

            config_path.parent.mkdir(parents=True, exist_ok=True)
            _save_json(config_path, config)
        except Exception:
            pass
        return True

    def nextId(self) -> int:
        wizard = self.wizard()
        if isinstance(wizard, SetupWizard):
            return wizard.dictation_page_id
        return super().nextId()


class OllamaInstallPage(ScrollableWizardPage):
    """Page for installing Ollama CLI."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("")

        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setContentsMargins(28, 20, 28, 20)

        # Header
        title = QLabel("Bring your models home")
        title.setObjectName("title")
        layout.addWidget(title)

        subtitle = QLabel("Ollama is required to run local AI models for Jarvis.")
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        layout.addSpacing(20)

        # Instructions card
        card = QFrame()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(18, 16, 18, 16)
        card_layout.setSpacing(12)

        instructions_title = QLabel("📥 Installation Instructions")
        instructions_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #fbbf24;")
        card_layout.addWidget(instructions_title)
        card_layout.addSpacing(8)

        if sys.platform == "darwin":
            instructions = QLabel(
                "1. Click the button below to open the Ollama download page\n"
                "2. Download and install Ollama for macOS\n"
                "3. After installation, click 'Verify Installation' to continue"
            )
        elif sys.platform == "win32":
            instructions = QLabel(
                "1. Click the button below to open the Ollama download page\n"
                "2. Download and run the Windows installer\n"
                "3. After installation, click 'Verify Installation' to continue"
            )
        else:
            instructions = QLabel(
                "1. Open a terminal and run: curl -fsSL https://ollama.ai/install.sh | sh\n"
                "2. Or click the button below to open the download page\n"
                "3. After installation, click 'Verify Installation' to continue"
            )

        instructions.setWordWrap(True)
        instructions.setStyleSheet("line-height: 1.8;")
        card_layout.addWidget(instructions)

        layout.addWidget(card)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(12)

        self.download_btn = QPushButton("🌐 Open Download Page")
        self.download_btn.clicked.connect(self._open_download_page)
        btn_layout.addWidget(self.download_btn)

        self.verify_btn = QPushButton("✅ Verify Installation")
        self.verify_btn.setObjectName("success")
        self.verify_btn.clicked.connect(self._verify_installation)
        btn_layout.addWidget(self.verify_btn)

        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        # Status label
        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        layout.addStretch()

        self.setLayout(layout)
        self._is_installed = False

    def _open_download_page(self):
        """Open Ollama download page in browser."""
        webbrowser.open("https://ollama.ai/download")
        self.status_label.setText("📝 Download page opened. Please install Ollama and then click 'Verify Installation'.")
        self.status_label.setStyleSheet("color: #a1a1aa;")

    def _verify_installation(self):
        """Verify Ollama installation."""
        self.verify_btn.setEnabled(False)
        self.verify_btn.setText("⏳ Checking...")

        is_installed, path = check_ollama_cli()

        if is_installed:
            self._is_installed = True
            self.status_label.setText(f"✅ Ollama is installed at: {path}")
            self.status_label.setStyleSheet("color: #4ade80;")

            # Update wizard status
            wizard = self.wizard()
            if isinstance(wizard, SetupWizard) and wizard.ollama_status:
                wizard.ollama_status.is_cli_installed = True
                wizard.ollama_status.cli_path = path
        else:
            self._is_installed = False
            self.status_label.setText("❌ Ollama not found. Please install it and try again.")
            self.status_label.setStyleSheet("color: #f87171;")

        self.verify_btn.setEnabled(True)
        self.verify_btn.setText("✅ Verify Installation")
        self.completeChanged.emit()

    def isComplete(self) -> bool:
        """Page is complete when Ollama is installed."""
        return self._is_installed

    def initializePage(self):
        """Check installation status when page is shown."""
        is_installed, path = check_ollama_cli()
        self._is_installed = is_installed

        if is_installed:
            self.status_label.setText(f"✅ Ollama is already installed at: {path}")
            self.status_label.setStyleSheet("color: #4ade80;")
        else:
            self.status_label.setText("")

        self.completeChanged.emit()

    def nextId(self) -> int:
        """Go to server page next."""
        wizard = self.wizard()
        if isinstance(wizard, SetupWizard):
            return wizard.ollama_server_page_id
        return super().nextId()


class OllamaServerPage(ScrollableWizardPage):
    """Page for starting Ollama server."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("")

        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setContentsMargins(28, 20, 28, 20)

        # Header
        title = QLabel("Wake up your model server")
        title.setObjectName("title")
        layout.addWidget(title)

        subtitle = QLabel("The Ollama server needs to be running for Jarvis to use AI models.")
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        layout.addSpacing(20)

        # Instructions card
        card = QFrame()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(18, 16, 18, 16)
        card_layout.setSpacing(12)

        instructions_title = QLabel("🚀 Starting the Server")
        instructions_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #fbbf24;")
        card_layout.addWidget(instructions_title)
        card_layout.addSpacing(8)

        if sys.platform == "darwin":
            instructions = QLabel(
                "The Ollama server should start automatically when you use it.\n\n"
                "If it's not running, you can:\n"
                "• Open the Ollama app from your Applications folder\n"
                "• Or run 'ollama serve' in a terminal\n"
                "• Or click the button below to start it automatically"
            )
        else:
            instructions = QLabel(
                "The Ollama server should start automatically when you use it.\n\n"
                "If it's not running, you can:\n"
                "• Run 'ollama serve' in a terminal\n"
                "• Or click the button below to start it automatically"
            )

        instructions.setWordWrap(True)
        instructions.setStyleSheet("line-height: 1.8;")
        card_layout.addWidget(instructions)

        layout.addWidget(card)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(12)

        self.start_btn = QPushButton("🚀 Start Server")
        self.start_btn.clicked.connect(self._start_server)
        btn_layout.addWidget(self.start_btn)

        self.verify_btn = QPushButton("✅ Verify Server")
        self.verify_btn.setObjectName("success")
        self.verify_btn.clicked.connect(self._verify_server)
        btn_layout.addWidget(self.verify_btn)

        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        # Status label
        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        layout.addStretch()

        self.setLayout(layout)
        self._is_running = False

    def _start_server(self):
        """Start the Ollama server."""
        self.start_btn.setEnabled(False)
        self.start_btn.setText("⏳ Starting...")
        self.status_label.setText("Starting Ollama server...")
        self.status_label.setStyleSheet("color: #a1a1aa;")

        try:
            # Get ollama path
            wizard = self.wizard()
            ollama_path = "ollama"
            if isinstance(wizard, SetupWizard) and wizard.ollama_status and wizard.ollama_status.cli_path:
                ollama_path = wizard.ollama_status.cli_path

            # Note: We intentionally detach the Ollama server process so it keeps
            # running after Jarvis exits. Ollama is a system service that should
            # persist. The serve command is idempotent - it won't spawn duplicates.
            if sys.platform == "darwin":
                # On macOS, try to open the Ollama app first
                try:
                    subprocess.Popen(
                        ["open", "-a", "Ollama"],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    )
                except Exception:
                    # Fall back to running serve command
                    subprocess.Popen(
                        [ollama_path, "serve"],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        start_new_session=True
                    )
            elif sys.platform == "win32":
                # On Windows, hide the console window
                subprocess.Popen(
                    [ollama_path, "serve"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=subprocess.CREATE_NO_WINDOW,
                )
            else:
                # On Linux and other platforms, run serve command
                subprocess.Popen(
                    [ollama_path, "serve"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True
                )

            # Wait a bit and then verify
            QTimer.singleShot(3000, self._verify_server)

        except Exception as e:
            self.status_label.setText(f"❌ Failed to start server: {str(e)}")
            self.status_label.setStyleSheet("color: #f87171;")
            self.start_btn.setEnabled(True)
            self.start_btn.setText("🚀 Start Server")

    def _verify_server(self):
        """Verify the server is running."""
        self.verify_btn.setEnabled(False)
        self.verify_btn.setText("⏳ Checking...")
        self.start_btn.setEnabled(False)

        is_running, version = check_ollama_server()

        if is_running:
            self._is_running = True
            self.status_label.setText(f"✅ Ollama server is running (version {version})")
            self.status_label.setStyleSheet("color: #4ade80;")

            # Update wizard status
            wizard = self.wizard()
            if isinstance(wizard, SetupWizard) and wizard.ollama_status:
                wizard.ollama_status.is_server_running = True
                wizard.ollama_status.server_version = version
        else:
            self._is_running = False
            self.status_label.setText("❌ Server not responding. Please try starting it again.")
            self.status_label.setStyleSheet("color: #f87171;")

        self.verify_btn.setEnabled(True)
        self.verify_btn.setText("✅ Verify Server")
        self.start_btn.setEnabled(True)
        self.start_btn.setText("🚀 Start Server")
        self.completeChanged.emit()

    def isComplete(self) -> bool:
        """Page is complete when server is running."""
        return self._is_running

    def initializePage(self):
        """Check server status when page is shown."""
        is_running, version = check_ollama_server()
        self._is_running = is_running

        if is_running:
            self.status_label.setText(f"✅ Ollama server is already running (version {version})")
            self.status_label.setStyleSheet("color: #4ade80;")
        else:
            self.status_label.setText("")

        self.completeChanged.emit()

    def nextId(self) -> int:
        """Go to models page next."""
        wizard = self.wizard()
        if isinstance(wizard, SetupWizard):
            return wizard.models_page_id
        return super().nextId()


class ModelsPage(ScrollableWizardPage):
    """Page for installing required AI models — dual-category (fast + chat)."""

    MODEL_OPTIONS = SUPPORTED_CHAT_MODELS
    _ALL_MODELS = MODEL_OPTIONS
    _FAST_MODEL_IDS = SUPPORTED_FAST_MODEL_IDS

    # VRAM overhead for always-running companion models (MB).
    # nomic-embed-text: ~1 GB for ~1.5K dim semantic search.
    _EMBED_VRAM_MB = 1024

    def _whisper_vram_mb(self) -> int:
        """VRAM in MB for the currently-configured whisper model.

        Reads the saved Whisper model from config and falls back to the
        catalogue's small-model estimate when settings are unavailable.
        """
        try:
            cfg = load_settings()
            model_id = getattr(cfg, "whisper_model", None)
            if model_id:
                return get_whisper_vram_mb(model_id)
        except Exception:
            pass
        return get_whisper_vram_mb("small")

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("")
        self._linked = False
        self._chat_model = DEFAULT_CHAT_MODEL
        self._fast_model = DEFAULT_FAST_MODEL
        self._detected_vram_mb = None

        layout = QVBoxLayout()
        layout.setSpacing(16)
        layout.setContentsMargins(28, 20, 28, 20)

        title = QLabel("Choose your AI models")
        title.setObjectName("title")
        layout.addWidget(title)

        subtitle = QLabel(
            "Jarvis needs a chat model (conversations) and a fast model "
            "(voice intent, tool routing). Pick them separately for "
            "best VRAM usage."
        )
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)
        layout.addSpacing(8)

        # Link toggle (off by default — separate models recommended)
        self._link_cb = QCheckBox("\u2699\ufe0f Use same model for both roles")
        self._link_cb.setChecked(False)
        self._link_cb.setStyleSheet("font-size: 14px; color: #e4e4e7; padding: 4px 0;")
        self._link_cb.toggled.connect(self._on_link_toggled)
        layout.addWidget(self._link_cb)

        hint = QLabel(
            "When linked, one model handles both chat and fast tasks "
            "(shares VRAM). Separate models let you pick a lightweight "
            "fast model."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("font-size: 11px; color: #71717a; padding: 0 0 0 24px;")
        layout.addWidget(hint)
        layout.addSpacing(8)

        # Model selection card with dropdowns
        selection_card = QFrame()
        selection_card.setObjectName("card")
        model_columns = QHBoxLayout(selection_card)
        self._responsive_columns = model_columns
        model_columns.setContentsMargins(20, 20, 20, 20)
        model_columns.setSpacing(24)
        card_layout = QVBoxLayout()
        model_columns.addLayout(card_layout, 1)
        card_layout.setSpacing(10)

        # Chat model dropdown
        chat_label = QLabel("🎯 Chat Model (conversations)")
        chat_label.setStyleSheet("font-size: 15px; font-weight: bold; color: #fbbf24;")
        card_layout.addWidget(chat_label)

        self._chat_combo = QComboBox()
        self._chat_combo.setMinimumHeight(36)
        self._chat_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        for mid in self._ALL_MODELS:
            info = self._ALL_MODELS[mid]
            self._chat_combo.addItem(f"{info['name']}  •  VRAM: {info['vram']}", mid)
        self._chat_combo.setCurrentIndex(self._chat_combo.findData(self._chat_model))
        self._chat_combo.currentIndexChanged.connect(self._on_chat_combo_changed)
        card_layout.addWidget(self._chat_combo)

        card_layout = QVBoxLayout()
        card_layout.setSpacing(10)
        model_columns.addLayout(card_layout, 1)

        # Fast model dropdown
        fast_label = QLabel("⚡ Fast Model (voice intent, tool routing)")
        fast_label.setStyleSheet("font-size: 15px; font-weight: bold; color: #a78bfa;")
        card_layout.addWidget(fast_label)

        self._fast_combo = QComboBox()
        self._fast_combo.setMinimumHeight(36)
        self._fast_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        for mid in self._FAST_MODEL_IDS:
            info = self._ALL_MODELS[mid]
            self._fast_combo.addItem(f"{info['name']}  •  VRAM: {info['vram']}", mid)
        self._fast_combo.setCurrentIndex(self._fast_combo.findData(self._fast_model))
        self._fast_combo.currentIndexChanged.connect(self._on_fast_combo_changed)
        card_layout.addWidget(self._fast_combo)

        layout.addWidget(selection_card)

        # VRAM bar
        self._detected_vram_mb = detect_total_vram_mb()
        self._vram_bar = QFrame()
        self._vram_bar.setObjectName("card")
        vl = QVBoxLayout(self._vram_bar)
        vl.setContentsMargins(24, 16, 24, 16)
        vl.setSpacing(4)
        self._vram_label = QLabel("")
        self._vram_label.setStyleSheet("font-size: 14px; font-weight: bold; color: #e4e4e7;")
        vl.addWidget(self._vram_label)
        self._vram_detail = QLabel("")
        self._vram_detail.setWordWrap(True)
        self._vram_detail.setStyleSheet("font-size: 12px; color: #71717a;")
        vl.addWidget(self._vram_detail)
        layout.addWidget(self._vram_bar)

        # Required models card
        card = QFrame()
        card.setObjectName("card")
        cl = QVBoxLayout(card)
        cl.setContentsMargins(18, 16, 18, 16)
        cl.setSpacing(12)
        mt = QLabel("📦 Required Models")
        mt.setStyleSheet("font-size: 16px; font-weight: bold; color: #fbbf24;")
        cl.addWidget(mt)
        cl.addSpacing(8)
        self.models_label = QLabel("Loading...")
        self.models_label.setWordWrap(True)
        self.models_label.setStyleSheet("line-height: 1.6;")
        cl.addWidget(self.models_label)
        layout.addWidget(card)

        # Progress + log
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setVisible(False)
        self.log_output.setMaximumHeight(150)
        layout.addWidget(self.log_output)

        # Buttons
        bl = QHBoxLayout()
        bl.setSpacing(12)
        self.install_btn = QPushButton("📥 Install Missing Models")
        self.install_btn.clicked.connect(self._install_models)
        bl.addWidget(self.install_btn)
        self.skip_btn = QPushButton("⏭️ Skip")
        self.skip_btn.setObjectName("secondary")
        self.skip_btn.clicked.connect(self._skip_models)
        bl.addWidget(self.skip_btn)
        bl.addStretch()
        layout.addLayout(bl)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)
        layout.addStretch()
        self.setLayout(layout)

        self._is_complete = False
        self._missing_models = []
        self._current_model_index = 0
        self._worker = None

        if self._detected_vram_mb is not None:
            # Account for companion-model overhead so the recommendation
            # leaves room for embeddings + whisper alongside the chat model.
            overhead = self._EMBED_VRAM_MB + self._whisper_vram_mb()
            usable_mb = self._detected_vram_mb - overhead
            rec, fast = get_recommended_model_pair(max(usable_mb, 0))
            debug_log(f"Chat model memory recommendation: {rec} (available {usable_mb} MB)", "setup")
            if rec in self._ALL_MODELS:
                self._chat_model = rec
                self._fast_model = fast
                self._constrain_fast_model()
                self._sync_combo_states()
        self._refresh_vram_display()
        self._update_models_display()

    def _build_linked_view(self):
        """No-op — kept for backward compat. Selection uses dropdowns."""
        pass

    def _build_unlinked_view(self):
        """No-op — kept for backward compat. Selection uses dropdowns."""
        pass

    def _make_button(self, info, compact=False):
        """No-op — kept for backward compat. Selection uses dropdowns."""
        pass

    def _on_link_toggled(self, linked):
        self._linked = linked
        if linked:
            self._fast_model = self._chat_model
        self._sync_combo_states()
        self._refresh_vram_display()
        self._update_models_display()

    def _on_linked_selected(self, mid):
        """No-op — selection uses dropdowns."""
        pass

    def _on_fast_combo_changed(self, idx):
        """Handle fast model combo change."""
        mid = self._fast_combo.itemData(idx)
        if mid:
            self._fast_model = mid
            if self._linked:
                self._chat_model = mid
                self._chat_combo.setCurrentIndex(self._chat_combo.findData(mid))
            self._refresh_vram_display()
            self._update_models_display()

    def _on_chat_combo_changed(self, idx):
        """Handle chat model combo change with auto-downgrade for fast model."""
        mid = self._chat_combo.itemData(idx)
        if not mid:
            return
        self._chat_model = mid
        if self._linked:
            self._fast_model = mid
            self._fast_combo.setCurrentIndex(self._fast_combo.findData(mid))
        else:
            self._constrain_fast_model()
            self._fast_combo.setCurrentIndex(self._fast_combo.findData(self._fast_model))
        self._refresh_vram_display()
        self._update_models_display()

    def _constrain_fast_model(self):
        """Keep a fitting choice, or select a replacement with the smallest fallback."""
        overhead = self._EMBED_VRAM_MB + self._whisper_vram_mb()
        chat_mb = required_vram_mb(self._chat_model) or 0

        def fits(model):
            fast_mb = required_vram_mb(model) or 0
            total = chat_mb + overhead
            if model != self._chat_model:
                total += fast_mb
            return (fast_mb <= chat_mb
                    and (self._detected_vram_mb is None or total <= self._detected_vram_mb))

        if fits(self._fast_model):
            return
        candidates = sorted(self._FAST_MODEL_IDS,
                            key=lambda model: required_vram_mb(model) or 0,
                            reverse=True)
        self._fast_model = next((model for model in candidates if fits(model)), candidates[-1])
        debug_log(f"Fast model memory recommendation: {self._fast_model}", "setup")

    def _sync_combo_states(self):
        """Sync combo selections to reflect current model choices."""
        ci = self._chat_combo.findData(self._chat_model)
        if ci >= 0:
            self._chat_combo.setCurrentIndex(ci)
        fi = self._fast_combo.findData(self._fast_model)
        if fi >= 0:
            self._fast_combo.setCurrentIndex(fi)
        self._refresh_vram_display()
        self._update_models_display()

    def _refresh_vram_display(self):
        overhead = self._EMBED_VRAM_MB + self._whisper_vram_mb()
        fv = required_vram_mb(self._fast_model) or 0
        cv = required_vram_mb(self._chat_model) or 0
        if self._linked or self._fast_model == self._chat_model:
            total = cv + overhead
            detail = f"(chat {cv // 1024} GB + embed+whisper {overhead // 1024} GB — shared VRAM)"
        else:
            total = fv + cv + overhead
            detail = (f"(fast {fv // 1024} GB + chat {cv // 1024} GB "
                      f"+ embed+whisper {overhead // 1024} GB)")
        tg = total / 1024
        if self._detected_vram_mb is not None:
            dg = self._detected_vram_mb / 1024
            self._vram_label.setText(
                f"Total VRAM Required: {tg:.1f} GB    "
                f"Available budget: {dg:.1f} GB"
            )
            if total > self._detected_vram_mb:
                sg = (total - self._detected_vram_mb) / 1024
                self._vram_detail.setText(
                    f"The available model budget is {dg:.1f} GB but the selected "
                    f"models need {tg:.1f} GB ({sg:.1f} GB over). "
                    "Switch to smaller models or use CPU fallback."
                )
                self._vram_detail.setStyleSheet(
                    "font-size: 12px; color: #f87171; padding-top: 2px;"
                )
            else:
                self._vram_detail.setText(detail)
                self._vram_detail.setStyleSheet("font-size: 12px; color: #71717a; padding-top: 2px;")
        else:
            self._vram_label.setText(f"Total VRAM Required: {tg:.1f} GB")
            self._vram_detail.setText(detail)

    def _update_models_display(self):
        wiz = self.wizard()
        em = DEFAULT_EMBEDDING_MODEL
        try:
            em = load_settings().ollama_embed_model
        except Exception:
            pass
        req = [self._chat_model]
        if self._fast_model not in req:
            req.append(self._fast_model)
        if em not in req:
            req.append(em)
        installed = []
        if isinstance(wiz, SetupWizard) and wiz.ollama_status:
            installed = wiz.ollama_status.installed_models
        self._missing_models = missing_ollama_models(req, installed)
        rinst = [m for m in req if m not in self._missing_models]
        if self._missing_models:
            self.models_label.setText(
                f"Missing: {', '.join('X ' + m for m in self._missing_models)}"
            )
            self._is_complete = False
            self.install_btn.setVisible(True)
            self.install_btn.setEnabled(True)
            self.skip_btn.setVisible(True)
        else:
            self.models_label.setText(f"All required models are installed: {', '.join(rinst)}")
            self._is_complete = True
            self.install_btn.setVisible(False)
            self.skip_btn.setVisible(False)
        self.completeChanged.emit()

    def _save_model_to_config(self):
        try:
            from jarvis.config import _load_json, _save_json
            cp = get_config_path()
            cp.parent.mkdir(parents=True, exist_ok=True)
            cfg = _load_json(cp) or {}
            cfg["ollama_chat_model"] = self._chat_model
            cfg["fast_model"] = self._fast_model
            return _save_json(cp, cfg)
        except Exception:
            return False

    def initializePage(self):
        cc = DEFAULT_CHAT_MODEL
        fc = DEFAULT_FAST_MODEL
        try:
            c = load_settings()
            cc = c.ollama_chat_model
            fc = getattr(c, "fast_model", DEFAULT_FAST_MODEL)
        except Exception:
            pass
        self._chat_model = cc if cc in self._ALL_MODELS else DEFAULT_CHAT_MODEL
        self._fast_model = fc if fc in self._ALL_MODELS else DEFAULT_FAST_MODEL
        from jarvis.config import _load_json, get_config_path
        saved = _load_json(get_config_path())
        if self._detected_vram_mb is not None and cc == DEFAULT_CHAT_MODEL and "ollama_chat_model" not in saved:
            usable_mb = self._detected_vram_mb - self._EMBED_VRAM_MB - self._whisper_vram_mb()
            self._chat_model, recommended_fast = get_recommended_model_pair(max(usable_mb, 0))
            if "fast_model" not in saved:
                self._fast_model = recommended_fast
            debug_log(f"Default chat memory recommendation: {self._chat_model}", "setup")
        self._constrain_fast_model()
        # Default to unlinked — separate fast model is the recommended layout
        # even when both happen to be the same model ID.
        self._linked = False
        self._link_cb.setChecked(False)
        self._sync_combo_states()
        self._refresh_vram_display()
        self._update_models_display()

    def _install_models(self):
        if not self._save_model_to_config():
            self.status_label.setText("Could not save model selection. Continuing...")
            self.status_label.setStyleSheet("color: #fbbf24;")
        if not self._missing_models:
            self._is_complete = True
            self.completeChanged.emit()
            return
        self._current_model_index = 0
        self._install_next_model()

    def _install_next_model(self):
        if self._current_model_index >= len(self._missing_models):
            self.progress.setVisible(False)
            self.log_output.setVisible(False)
            self.log_output.clear()
            self._update_models_display()
            self.status_label.setText("All models installed!")
            self.status_label.setStyleSheet("color: #4ade80;")
            return
        m = self._missing_models[self._current_model_index]
        self.install_btn.setEnabled(False)
        self.skip_btn.setEnabled(False)
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self.log_output.setVisible(True)
        self.status_label.setText(f"Installing {m}... ({self._current_model_index + 1}/{len(self._missing_models)})")
        self.status_label.setStyleSheet("color: #a1a1aa;")
        op = "ollama"
        w = self.wizard()
        if isinstance(w, SetupWizard) and w.ollama_status and w.ollama_status.cli_path:
            op = w.ollama_status.cli_path
        self._worker = CommandWorker([op, "pull", m])
        self._worker.output.connect(self._on_install_output)
        self._worker.completed.connect(self._on_install_finished)
        self._worker.start()

    def _on_install_output(self, text):
        self.log_output.append(text)
        self.log_output.verticalScrollBar().setValue(self.log_output.verticalScrollBar().maximum())

    def _on_install_finished(self, success, message):
        if success:
            m = self._missing_models[self._current_model_index]
            w = self.wizard()
            if isinstance(w, SetupWizard) and w.ollama_status:
                if m not in w.ollama_status.installed_models:
                    w.ollama_status.installed_models.append(m)
            self._current_model_index += 1
            self._install_next_model()
        else:
            self.progress.setVisible(False)
            self.status_label.setText(f"Failed to install model. {message}")
            self.status_label.setStyleSheet("color: #f87171;")
            self.install_btn.setEnabled(True)
            self.skip_btn.setEnabled(True)

    def _skip_models(self):
        self._is_complete = True
        self.status_label.setText("Skipped model installation. Jarvis may not work correctly.")
        self.status_label.setStyleSheet("color: #fbbf24;")
        self.completeChanged.emit()

    def isComplete(self):
        return self._is_complete

    def validatePage(self):
        self._save_model_to_config()
        return True

    def nextId(self):
        w = self.wizard()
        if isinstance(w, SetupWizard):
            return w.dictation_page_id
        return super().nextId()


def _get_effective_whisper_backend(
    apple_silicon: bool,
    backend_preference: Optional[str] = None,
) -> str:
    """Resolve the Whisper backend the listener will use.

    MLX is only usable on Apple Silicon when its import succeeds.  An
    explicit faster-whisper preference disables MLX, while an explicit MLX
    preference falls back to faster-whisper when MLX is unavailable.  Keep
    this resolution in sync with ``VoiceListener._determine_whisper_backend``
    so the wizard never offers a model the listener cannot load.
    """
    if backend_preference is None:
        try:
            cfg = load_settings()
            backend_preference = getattr(cfg, "whisper_backend", "auto")
        except Exception:
            backend_preference = "auto"

    backend_preference = str(backend_preference or "auto").lower()
    if backend_preference not in ("auto", "mlx", "faster-whisper"):
        backend_preference = "auto"

    if backend_preference == "faster-whisper":
        return "faster-whisper"

    mlx_available = apple_silicon and check_mlx_whisper_installed()
    return "mlx" if mlx_available else "faster-whisper"


class WhisperSetupPage(ScrollableWizardPage):
    """Page for setting up Whisper speech recognition (all platforms)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("")
        self._is_apple_silicon = is_apple_silicon()
        self._is_bundled = getattr(sys, 'frozen', False)
        self._is_english_only = False  # Default to multilingual for broader language support

        # Main layout with scroll area for overflow
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")

        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setSpacing(10)
        layout.setContentsMargins(30, 20, 30, 20)

        # Header - different text based on platform
        if self._is_apple_silicon:
            title = QLabel("Let Jarvis hear you")
            subtitle_text = (
                "GPU-accelerated speech recognition. Choose language and model size."
            )
        else:
            title = QLabel("Let Jarvis hear you")
            subtitle_text = "Choose language mode and model size for speech recognition."

        title.setObjectName("title")
        layout.addWidget(title)

        subtitle = QLabel(subtitle_text)
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        # Language selection card
        lang_card = QFrame()
        lang_card.setObjectName("card")
        lang_layout = QVBoxLayout(lang_card)
        lang_layout.setContentsMargins(16, 12, 16, 12)
        lang_layout.setSpacing(8)

        lang_title = QLabel("01  Language")
        lang_title.setObjectName("section_title")
        lang_layout.addWidget(lang_title)

        # Language toggle buttons
        lang_btn_layout = QHBoxLayout()
        lang_btn_layout.setSpacing(8)

        self._english_btn = QPushButton("🇬🇧 English Only")
        self._english_btn.setCheckable(True)
        self._english_btn.setChecked(True)
        self._english_btn.setFixedHeight(36)
        self._english_btn.clicked.connect(lambda: self._on_language_changed(True))

        self._multilingual_btn = QPushButton("🌐 Multilingual (99 langs)")
        self._multilingual_btn.setCheckable(True)
        self._multilingual_btn.setFixedHeight(36)
        self._multilingual_btn.clicked.connect(lambda: self._on_language_changed(False))

        lang_btn_style = """
            QPushButton {
                text-align: center;
                padding: 6px 12px;
                border: 2px solid #27272a;
                border-radius: 6px;
                background: #1a1d26;
                color: #e4e4e7;
                font-size: 12px;
            }
            QPushButton:hover {
                border-color: #f59e0b;
                background: #1e222c;
            }
            QPushButton:checked {
                border-color: #f59e0b;
                background: rgba(245, 158, 11, 0.15);
                color: #fbbf24;
            }
        """
        self._english_btn.setStyleSheet(lang_btn_style)
        self._multilingual_btn.setStyleSheet(lang_btn_style)

        lang_btn_layout.addWidget(self._english_btn)
        lang_btn_layout.addWidget(self._multilingual_btn)
        lang_layout.addLayout(lang_btn_layout)

        # Language info label
        self._lang_info_label = QLabel()
        self._lang_info_label.setWordWrap(True)
        self._lang_info_label.setStyleSheet("font-size: 10px; color: #71717a; background: transparent;")
        lang_layout.addWidget(self._lang_info_label)

        layout.addWidget(lang_card)

        # Model selection card with slider
        selection_card = QFrame()
        selection_card.setObjectName("card")
        selection_layout = QVBoxLayout(selection_card)
        selection_layout.setContentsMargins(16, 12, 16, 12)
        selection_layout.setSpacing(4)

        selection_title = QLabel("02  Accuracy & speed")
        selection_title.setObjectName("section_title")
        selection_layout.addWidget(selection_title)

        # Container for slider labels (will be rebuilt on language change)
        self._labels_container = QWidget()
        self._labels_container.setStyleSheet("background: transparent;")
        self._labels_layout = QHBoxLayout(self._labels_container)
        self._labels_layout.setContentsMargins(0, 4, 0, 0)
        self._labels_layout.setSpacing(0)
        selection_layout.addWidget(self._labels_container)

        # Slider with proper padding for handle visibility
        slider_container = QWidget()
        slider_container.setStyleSheet("background: transparent;")
        slider_container.setFixedHeight(36)
        slider_inner = QHBoxLayout(slider_container)
        slider_inner.setContentsMargins(0, 0, 0, 0)

        self._model_slider = QSlider(Qt.Orientation.Horizontal)
        self._model_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self._model_slider.setTickInterval(1)
        self._model_slider.setStyleSheet("""
            QSlider {
                background: transparent;
                height: 32px;
            }
            QSlider::groove:horizontal {
                border: 1px solid #27272a;
                height: 4px;
                background: #1a1d26;
                border-radius: 2px;
                margin: 0;
            }
            QSlider::handle:horizontal {
                background: #f59e0b;
                border: none;
                width: 16px;
                height: 16px;
                margin: -6px 0;
                border-radius: 8px;
            }
            QSlider::handle:horizontal:hover {
                background: #fbbf24;
            }
            QSlider::sub-page:horizontal {
                background: rgba(245, 158, 11, 0.4);
                border-radius: 2px;
            }
            QSlider::tick-mark {
                background: #71717a;
            }
        """)
        self._model_slider.valueChanged.connect(self._on_slider_changed)
        slider_inner.addWidget(self._model_slider)
        selection_layout.addWidget(slider_container)

        # Container for size labels (will be rebuilt on language change)
        self._size_container = QWidget()
        self._size_container.setStyleSheet("background: transparent;")
        self._size_layout = QHBoxLayout(self._size_container)
        self._size_layout.setContentsMargins(0, 0, 0, 4)
        self._size_layout.setSpacing(0)
        selection_layout.addWidget(self._size_container)

        # Selected model info
        self._model_info_label = QLabel()
        self._model_info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._model_info_label.setWordWrap(True)
        self._model_info_label.setStyleSheet("""
            font-size: 11px;
            color: #e4e4e7;
            padding: 6px 10px;
            background: #1a1d26;
            border-radius: 6px;
        """)
        selection_layout.addWidget(self._model_info_label)

        layout.addWidget(selection_card)

        # Store selected model (default to medium for best balance)
        self._selected_whisper_model: str = "medium"

        # Build initial slider UI
        self._rebuild_slider_ui()
        self._update_language_info()

        # MLX-specific installation section (only for Apple Silicon)
        self._mlx_section = QFrame()
        self._mlx_section.setObjectName("card")
        mlx_layout = QVBoxLayout(self._mlx_section)
        mlx_layout.setContentsMargins(16, 12, 16, 12)
        mlx_layout.setSpacing(6)

        status_title = QLabel("03  Local acceleration")
        status_title.setObjectName("section_title")
        mlx_layout.addWidget(status_title)

        self.ffmpeg_status = self._create_status_row("🎬 FFmpeg", "Checking...")
        self.mlx_status = self._create_status_row("🧠 MLX Whisper", "Checking...")

        mlx_layout.addWidget(self.ffmpeg_status)
        mlx_layout.addWidget(self.mlx_status)

        # Progress bar for installations
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setFixedHeight(16)
        mlx_layout.addWidget(self.progress)

        # Log output for installations
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setVisible(False)
        self.log_output.setMaximumHeight(60)
        self.log_output.setStyleSheet("font-size: 10px;")
        mlx_layout.addWidget(self.log_output)

        # Installation buttons
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(8)

        self.install_ffmpeg_btn = QPushButton("🎬 FFmpeg")
        self.install_ffmpeg_btn.clicked.connect(self._install_ffmpeg)
        btn_layout.addWidget(self.install_ffmpeg_btn)

        self.install_mlx_btn = QPushButton("🧠 MLX Whisper")
        self.install_mlx_btn.clicked.connect(self._install_mlx_whisper)
        btn_layout.addWidget(self.install_mlx_btn)

        btn_layout.addStretch()
        mlx_layout.addLayout(btn_layout)

        layout.addWidget(self._mlx_section)

        # Hide MLX section on non-Apple Silicon
        if not self._is_apple_silicon:
            self._mlx_section.setVisible(False)

        # Status label
        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet("font-size: 11px; background: transparent;")
        layout.addWidget(self.status_label)

        layout.addStretch()

        scroll.setWidget(content)
        main_layout.addWidget(scroll)
        self.setLayout(main_layout)

        self._is_complete = True  # Always complete - model selection can always proceed
        self._worker: Optional[CommandWorker] = None

    def _get_current_model_options(self) -> list:
        """Get the model options list based on current language mode.

        Filters out large-v3-turbo unless the effective Whisper backend can
        load it.  MLX supports turbo on Apple Silicon; faster-whisper needs a
        version that includes the model.
        """
        options = wizard_model_options(self._is_english_only)
        backend = _get_effective_whisper_backend(self._is_apple_silicon)
        if backend != "mlx" and not whisper_capabilities.is_faster_whisper_turbo_supported():
            options = [opt for opt in options if opt[0] != "large-v3-turbo"]
        return options

    def _on_language_changed(self, is_english: bool):
        """Handle language mode change."""
        self._is_english_only = is_english
        self._english_btn.setChecked(is_english)
        self._multilingual_btn.setChecked(not is_english)

        # Update the language info text
        self._update_language_info()

        # Rebuild slider with new model options
        self._rebuild_slider_ui()

    def _update_language_info(self):
        """Update the language info label based on current selection."""
        if self._is_english_only:
            self._lang_info_label.setText(
                "English-only models are optimized for English and may have slightly better accuracy."
            )
        else:
            self._lang_info_label.setText(
                "Multilingual models support 99 languages including: Spanish, French, German, Chinese, "
                "Japanese, Korean, Arabic, Hindi, Portuguese, Russian, and many more."
            )

    def _rebuild_slider_ui(self):
        """Rebuild the slider labels based on current language mode."""
        options = self._get_current_model_options()
        n = len(options)

        # Hide removed labels immediately: deferred deletion can wait until
        # the wizard's nested event loop returns. Keep their container parent
        # until deletion; setParent(None) creates native top-level windows
        # during page transitions and can crash on macOS and Windows.
        while self._labels_layout.count():
            item = self._labels_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
                widget.deleteLater()
            # Spacers are automatically cleaned up when the item goes out of scope.

        while self._size_layout.count():
            item = self._size_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
                widget.deleteLater()

        # Add labels aligned with slider tick positions
        # Slider ticks are at 0, 1/(n-1), 2/(n-1), ..., 1 of the groove width
        # We achieve this by: label[0], stretch, label[1], stretch, ..., label[n-1]
        # First label left-aligned, last label right-aligned, middle labels centered
        for i, (model_id, name, file_size, vram, desc) in enumerate(options):
            # Model name label
            label = QLabel(name)
            if i == 0:
                label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            elif i == n - 1:
                label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            else:
                label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label.setStyleSheet("font-size: 11px; color: #e4e4e7; background: transparent;")
            label.setFixedHeight(18)
            self._labels_layout.addWidget(label)

            # Size/VRAM label - single line to save space
            size_label = QLabel(f"{file_size} / {vram}")
            if i == 0:
                size_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            elif i == n - 1:
                size_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            else:
                size_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            size_label.setStyleSheet("font-size: 9px; color: #71717a; background: transparent;")
            size_label.setFixedHeight(16)
            self._size_layout.addWidget(size_label)

            # Add stretch after each label except the last
            if i < n - 1:
                self._labels_layout.addStretch(1)
                self._size_layout.addStretch(1)

        # Update slider range
        self._model_slider.setMinimum(0)
        self._model_slider.setMaximum(len(options) - 1)

        # Find best matching position for current selection. If a stale turbo
        # selection was filtered out, use the same medium fallback as startup.
        model_ids = [m[0] for m in options]
        current_base = self._selected_whisper_model.replace(".en", "")

        # Try to find matching model
        if self._is_english_only:
            target = f"{current_base}.en" if not current_base.endswith(".en") else current_base
        else:
            target = current_base.replace(".en", "")

        if target in model_ids:
            slider_pos = model_ids.index(target)
        elif current_base == "large-v3-turbo" and "medium.en" in model_ids:
            slider_pos = model_ids.index("medium.en")
        elif current_base == "large-v3-turbo" and "medium" in model_ids:
            slider_pos = model_ids.index("medium")
        elif "tiny.en" in model_ids:
            slider_pos = model_ids.index("tiny.en")
        elif "tiny" in model_ids:
            slider_pos = model_ids.index("tiny")
        else:
            slider_pos = 0  # Default to first (smallest) model

        self._model_slider.setValue(slider_pos)
        self._selected_whisper_model = options[slider_pos][0]
        self._update_model_info()

    def _on_slider_changed(self, value: int):
        """Handle slider value change."""
        options = self._get_current_model_options()
        if 0 <= value < len(options):
            model_id, name, file_size, ram, desc = options[value]
            self._selected_whisper_model = model_id
            self._update_model_info()

    def _update_model_info(self):
        """Update the model info label based on current selection."""
        options = self._get_current_model_options()
        for model_id, name, file_size, ram, desc in options:
            if model_id == self._selected_whisper_model:
                lang_note = "English only" if self._is_english_only else "99 languages"
                self._model_info_label.setText(f"Selected: {name} ({file_size}, {ram}) — {desc} [{lang_note}]")
                break

    def _create_status_row(self, label_text: str, status_text: str) -> QWidget:
        """Create a status row widget."""
        row = QWidget()
        row.setStyleSheet("background: transparent;")
        row.setFixedHeight(28)
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 4, 0, 4)

        label = QLabel(label_text)
        label.setStyleSheet("font-size: 12px; background: transparent;")
        row_layout.addWidget(label)

        row_layout.addStretch()

        status = QLabel(status_text)
        status.setStyleSheet("font-size: 12px; color: #a1a1aa; background: transparent;")
        status.setObjectName("status_label")
        row_layout.addWidget(status)

        return row

    def _update_status_row(self, row: QWidget, status_text: str, is_success: bool):
        """Update a status row with new status."""
        status_label = row.findChild(QLabel, "status_label")
        if status_label:
            status_label.setText(status_text)
            if is_success:
                status_label.setStyleSheet("font-size: 12px; color: #4ade80; background: transparent;")
            else:
                status_label.setStyleSheet("font-size: 12px; color: #fbbf24; background: transparent;")

    def _save_whisper_model_to_config(self):
        """Save the selected whisper model to config file."""
        try:
            from jarvis.config import _load_json, _save_json
            config_path = get_config_path()
            config_path.parent.mkdir(parents=True, exist_ok=True)

            config = _load_json(config_path) or {}
            config["whisper_model"] = self._selected_whisper_model

            # _save_json keeps the file at 0o600 (it can hold llm_api_key).
            return _save_json(config_path, config)
        except Exception:
            return False

    def initializePage(self):
        """Check status when page is shown."""
        # Load the currently configured whisper model
        current_whisper_model = "medium"  # Default to medium multilingual
        try:
            cfg = load_settings()
            current_whisper_model = cfg.whisper_model
        except Exception:
            pass

        # Detect language mode from the model name
        self._is_english_only = current_whisper_model.endswith(".en")
        self._english_btn.setChecked(self._is_english_only)
        self._multilingual_btn.setChecked(not self._is_english_only)
        self._update_language_info()

        # Set the selected model and rebuild slider
        self._selected_whisper_model = current_whisper_model
        self._rebuild_slider_ui()

        # Refresh MLX status only on Apple Silicon
        if self._is_apple_silicon:
            self._refresh_mlx_status()

    def _refresh_mlx_status(self):
        """Refresh MLX Whisper installation status (Apple Silicon only)."""
        status = check_mlx_whisper_status()

        # Update wizard status
        wizard = self.wizard()
        if isinstance(wizard, SetupWizard):
            wizard.mlx_whisper_status = status

        # Update FFmpeg status
        if status.is_ffmpeg_installed:
            self._update_status_row(self.ffmpeg_status, f"✅ Installed ({status.ffmpeg_path})", True)
            self.install_ffmpeg_btn.setEnabled(False)
            self.install_ffmpeg_btn.setText("✅ FFmpeg Installed")
        else:
            self._update_status_row(self.ffmpeg_status, "❌ Not installed", False)
            self.install_ffmpeg_btn.setEnabled(True)
            self.install_ffmpeg_btn.setText("🎬 Install FFmpeg")

        # Update MLX Whisper status
        if status.is_mlx_whisper_installed:
            self._update_status_row(self.mlx_status, "✅ Installed", True)
            self.install_mlx_btn.setEnabled(False)
            self.install_mlx_btn.setText("✅ MLX Whisper Installed")
            self.install_mlx_btn.setVisible(True)
        elif self._is_bundled:
            # In bundled mode, can't pip install - hide the button
            self._update_status_row(self.mlx_status, "⚡ Using faster-whisper", True)
            self.install_mlx_btn.setVisible(False)
        else:
            self._update_status_row(self.mlx_status, "❌ Not installed", False)
            self.install_mlx_btn.setEnabled(True)
            self.install_mlx_btn.setText("🧠 Install MLX Whisper")
            self.install_mlx_btn.setVisible(True)

        # Update status message based on setup state
        if status.is_fully_setup:
            self.status_label.setText("✅ MLX Whisper is ready! GPU-accelerated speech recognition enabled.")
            self.status_label.setStyleSheet("color: #4ade80;")
        elif self._is_bundled and not status.is_mlx_whisper_installed:
            # In bundled mode without MLX, faster-whisper is used automatically
            self.status_label.setText("✅ Speech recognition ready using faster-whisper.")
            self.status_label.setStyleSheet("color: #4ade80;")
        else:
            if not status.is_ffmpeg_installed:
                self.status_label.setText(
                    "💡 Install FFmpeg for audio processing, or continue to save your model selection."
                )
            elif not status.is_mlx_whisper_installed:
                self.status_label.setText(
                    "💡 Install MLX Whisper for GPU acceleration, or continue to save your model selection."
                )
            self.status_label.setStyleSheet("color: #a1a1aa;")

        self.completeChanged.emit()

    def _install_ffmpeg(self):
        """Install FFmpeg via Homebrew."""
        # Check if Homebrew is installed
        brew_path = shutil.which("brew")
        if not brew_path:
            self.status_label.setText(
                "❌ Homebrew not found. Please install Homebrew first:\n"
                "/bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
            )
            self.status_label.setStyleSheet("color: #f87171;")
            return

        self.install_ffmpeg_btn.setEnabled(False)
        self.install_ffmpeg_btn.setText("⏳ Installing...")
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self.log_output.setVisible(True)
        self.log_output.clear()

        self._worker = CommandWorker([brew_path, "install", "ffmpeg"])
        self._worker.output.connect(self._on_output)
        self._worker.completed.connect(self._on_ffmpeg_installed)
        self._worker.start()

    def _install_mlx_whisper(self):
        """Install MLX Whisper via pip."""
        self.install_mlx_btn.setEnabled(False)
        self.install_mlx_btn.setText("⏳ Installing...")
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self.log_output.setVisible(True)
        self.log_output.clear()

        # Use the current Python interpreter
        python_path = sys.executable
        self._worker = CommandWorker([python_path, "-m", "pip", "install", "mlx-whisper"])
        self._worker.output.connect(self._on_output)
        self._worker.completed.connect(self._on_mlx_installed)
        self._worker.start()

    def _on_output(self, text: str):
        """Handle command output."""
        self.log_output.append(text)
        scrollbar = self.log_output.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def _on_ffmpeg_installed(self, success: bool, message: str):
        """Handle FFmpeg installation completion."""
        self.progress.setVisible(False)
        self.install_ffmpeg_btn.setEnabled(True)
        self.install_ffmpeg_btn.setText("🎬 Install FFmpeg")

        if success:
            self._refresh_mlx_status()
        else:
            self.status_label.setText(f"❌ Failed to install FFmpeg: {message}")
            self.status_label.setStyleSheet("color: #f87171;")

    def _on_mlx_installed(self, success: bool, message: str):
        """Handle MLX Whisper installation completion."""
        self.progress.setVisible(False)
        self.install_mlx_btn.setEnabled(True)
        self.install_mlx_btn.setText("🧠 Install MLX Whisper")

        if success:
            self._refresh_mlx_status()
            # MLX may have been installed while this page was open. Rebuild
            # the choices so large-v3-turbo becomes selectable immediately.
            self._rebuild_slider_ui()
        else:
            self.status_label.setText(f"❌ Failed to install MLX Whisper: {message}")
            self.status_label.setStyleSheet("color: #f87171;")

    def isComplete(self) -> bool:
        """Page is complete when setup is done or skipped."""
        return self._is_complete

    def validatePage(self) -> bool:
        """Save whisper model selection when leaving the page."""
        self._save_whisper_model_to_config()
        return True

    def nextId(self) -> int:
        """Go to Provider Choice so the user can confirm or change
        their LLM runtime before continuing."""
        wizard = self.wizard()
        if isinstance(wizard, SetupWizard):
            return wizard.provider_choice_page_id
        return super().nextId()


class LocationPage(ScrollableWizardPage):
    """Page for configuring location detection."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("")

        # Main layout with scroll area
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)

        # Scroll area for content
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("""
            QScrollArea { background: transparent; }
            QScrollArea > QWidget > QWidget { background: transparent; }
            QScrollArea > QWidget#qt_scrollarea_viewport { background: transparent; }
        """)

        # Content widget inside scroll area
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setSpacing(20)
        layout.setContentsMargins(28, 20, 28, 20)

        # Header
        title = QLabel("Make Jarvis feel at home")
        title.setObjectName("title")
        layout.addWidget(title)

        subtitle = QLabel("Location helps Jarvis provide weather, local services, and time-aware responses.")
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        layout.addSpacing(20)

        # Status card
        card = QFrame()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(18, 16, 18, 16)
        card_layout.setSpacing(12)

        status_title = QLabel("🔍 Detection Status")
        status_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #fbbf24;")
        card_layout.addWidget(status_title)
        card_layout.addSpacing(8)

        self.status_label = QLabel("Checking location detection...")
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet("line-height: 1.6;")
        card_layout.addWidget(self.status_label)

        layout.addWidget(card)

        # IP configuration section
        config_card = QFrame()
        config_card.setObjectName("card")
        config_layout = QVBoxLayout(config_card)
        config_layout.setContentsMargins(18, 16, 18, 16)
        config_layout.setSpacing(12)

        config_title = QLabel("⚙️ Manual Configuration (Optional)")
        config_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #fbbf24;")
        config_layout.addWidget(config_title)
        config_layout.addSpacing(8)

        config_info = QLabel("If automatic detection fails, you can manually enter your public IP address.")
        config_info.setWordWrap(True)
        config_info.setStyleSheet("color: #a1a1aa;")
        config_layout.addWidget(config_info)

        config_layout.addSpacing(8)

        # IP input row
        ip_layout = QHBoxLayout()
        ip_layout.setSpacing(12)

        self.ip_input = QLineEdit()
        self.ip_input.setPlaceholderText("Enter your public IP (e.g., 203.0.113.45)")
        self.ip_input.setMinimumHeight(44)
        ip_layout.addWidget(self.ip_input, stretch=1)

        self.test_btn = QPushButton("🧪 Test")
        self.test_btn.clicked.connect(self._test_ip)
        self.test_btn.setMinimumHeight(44)
        ip_layout.addWidget(self.test_btn)

        config_layout.addLayout(ip_layout)

        layout.addWidget(config_card)

        # Test result label
        self.test_result_label = QLabel("")
        self.test_result_label.setWordWrap(True)
        layout.addWidget(self.test_result_label)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(12)

        self.open_ip_btn = QPushButton("🔍 Detect My IP")
        self.open_ip_btn.setObjectName("secondary")
        self.open_ip_btn.setMinimumHeight(44)
        self.open_ip_btn.clicked.connect(self._open_ip_lookup)
        btn_layout.addWidget(self.open_ip_btn)

        self.save_btn = QPushButton("💾 Save IP to Config")
        self.save_btn.setObjectName("success")
        self.save_btn.setMinimumHeight(44)
        self.save_btn.clicked.connect(self._save_ip_to_config)
        self.save_btn.setEnabled(False)
        btn_layout.addWidget(self.save_btn)

        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        # Save status label
        self.save_status_label = QLabel("")
        self.save_status_label.setWordWrap(True)
        layout.addWidget(self.save_status_label)

        layout.addStretch()

        scroll.setWidget(content)
        main_layout.addWidget(scroll)
        self.setLayout(main_layout)
        self._validated_ip: Optional[str] = None

    def initializePage(self):
        """Check location status when page is shown."""
        self._check_location_status()

    def _check_location_status(self):
        """Check current location detection status."""
        status_parts = []

        if not GEOIP2_AVAILABLE:
            status_parts.append("❌ GeoIP2 library not installed (pip install geoip2)")
        elif not is_location_available():
            db_path = _get_database_path()
            status_parts.append("❌ GeoLite2 database not found")
            status_parts.append(f"   Expected location: {db_path}")
            status_parts.append("")
            status_parts.append("   To set up:")
            status_parts.append("   1. Register at: maxmind.com/en/geolite2/signup")
            status_parts.append("   2. Download GeoLite2-City (MMDB format)")
            status_parts.append(f"   3. Save as: {db_path}")
        else:
            status_parts.append("✅ GeoLite2 database found")
            try:
                cfg = load_settings()
                location_context = get_location_context(
                    config_ip=cfg.location_ip_address,
                    auto_detect=cfg.location_auto_detect,
                    resolve_cgnat_public_ip=cfg.location_cgnat_resolve_public_ip,
                )
            except Exception:
                location_context = get_location_context(auto_detect=True, resolve_cgnat_public_ip=True)

            if location_context == "Location: Unknown":
                status_parts.append("❌ Could not detect public IP address")
                status_parts.append("")
                status_parts.append("   Your network likely uses NAT without UPnP support.")
                status_parts.append("   Enter your public IP below to enable location features.")
            else:
                status_parts.append(f"✅ {location_context}")
                status_parts.append("")
                status_parts.append("   Location is working! You can skip this step.")

        self.status_label.setText("\n".join(status_parts))

    def _open_ip_lookup(self):
        """Resolve public IP via OpenDNS and populate the input field."""
        from jarvis.utils.location import _resolve_public_ip_via_opendns
        resolved = _resolve_public_ip_via_opendns()
        if resolved:
            self.ip_input.setText(resolved)
            self.test_result_label.setText(f"✅ Detected public IP: {resolved}")
            self.test_result_label.setStyleSheet("color: #4ade80;")
        else:
            self.test_result_label.setText("⚠️ Could not detect public IP via DNS")
            self.test_result_label.setStyleSheet("color: #fbbf24;")

    def _test_ip(self):
        """Test the entered IP address."""
        ip = self.ip_input.text().strip()

        if not ip:
            self.test_result_label.setText("❌ Please enter an IP address")
            self.test_result_label.setStyleSheet("color: #f87171;")
            self.save_btn.setEnabled(False)
            self._validated_ip = None
            return

        import re
        ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        if not re.match(ip_pattern, ip):
            self.test_result_label.setText("❌ Invalid IP format. Use format: 203.0.113.45")
            self.test_result_label.setStyleSheet("color: #f87171;")
            self.save_btn.setEnabled(False)
            self._validated_ip = None
            return

        octets = ip.split('.')
        for octet in octets:
            if int(octet) > 255:
                self.test_result_label.setText("❌ Invalid IP: octets must be 0-255")
                self.test_result_label.setStyleSheet("color: #f87171;")
                self.save_btn.setEnabled(False)
                self._validated_ip = None
                return

        if _is_private_ip(ip):
            self.test_result_label.setText("⚠️ This appears to be a private IP. Use your public IP instead.")
            self.test_result_label.setStyleSheet("color: #fbbf24;")
            self.save_btn.setEnabled(False)
            self._validated_ip = None
            return

        if _is_cgnat_ip(ip):
            self.test_result_label.setText("⚠️ This is a CGNAT IP (100.64.0.0/10). Use your true public IP instead.")
            self.test_result_label.setStyleSheet("color: #fbbf24;")
            self.save_btn.setEnabled(False)
            self._validated_ip = None
            return

        if not is_location_available():
            self.test_result_label.setText("⚠️ Cannot test: GeoLite2 database not installed")
            self.test_result_label.setStyleSheet("color: #fbbf24;")
            self.save_btn.setEnabled(True)
            self._validated_ip = ip
            return

        location_info = get_location_info(ip_address=ip)

        if "error" in location_info:
            self.test_result_label.setText("⚠️ IP not found in database. It may still work.")
            self.test_result_label.setStyleSheet("color: #fbbf24;")
            self.save_btn.setEnabled(True)
            self._validated_ip = ip
        else:
            city = location_info.get("city", "Unknown")
            country = location_info.get("country", "Unknown")
            self.test_result_label.setText(f"✅ Location: {city}, {country}")
            self.test_result_label.setStyleSheet("color: #4ade80;")
            self.save_btn.setEnabled(True)
            self._validated_ip = ip

    def _save_ip_to_config(self):
        """Save the validated IP to config file."""
        if not self._validated_ip:
            self.save_status_label.setText("❌ Please test an IP address first")
            self.save_status_label.setStyleSheet("color: #f87171;")
            return

        try:
            from jarvis.config import _load_json, _save_json

            config_path = get_config_path()
            config_path.parent.mkdir(parents=True, exist_ok=True)

            config = _load_json(config_path) or {}
            config["location_ip_address"] = self._validated_ip

            # _save_json keeps the file at 0o600 (it can hold llm_api_key).
            _save_json(config_path, config)

            self.save_status_label.setText(f"✅ Saved to {config_path}")
            self.save_status_label.setStyleSheet("color: #4ade80;")
            self._check_location_status()

        except Exception as e:
            self.save_status_label.setText(f"❌ Error saving config: {e}")
            self.save_status_label.setStyleSheet("color: #f87171;")

    def isComplete(self) -> bool:
        """Page is always complete - location is optional."""
        return True

    def nextId(self) -> int:
        """Go to complete page next."""
        wizard = self.wizard()
        if isinstance(wizard, SetupWizard):
            return wizard.complete_page_id
        return super().nextId()


class DictationPage(ScrollableWizardPage):
    """Page for configuring dictation (hold-to-dictate) settings."""

    @staticmethod
    def _hotkey_options():
        from jarvis.dictation.dictation_engine import format_hotkey_display
        from jarvis.config import _default_dictation_hotkey
        default = _default_dictation_hotkey()
        options = [
            ("ctrl+alt", format_hotkey_display("ctrl+alt")),
            ("ctrl+cmd", format_hotkey_display("ctrl+cmd")),
            ("ctrl+shift+d", format_hotkey_display("ctrl+shift+d")),
            ("ctrl+shift", format_hotkey_display("ctrl+shift")),
        ]
        # Tag the platform default
        return [
            (val, f"{label} (default)" if val == default else label)
            for val, label in options
        ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("")

        layout = QVBoxLayout()
        layout.setSpacing(16)
        layout.setContentsMargins(28, 20, 28, 20)

        # Header
        title = QLabel("Your words, anywhere")
        title.setObjectName("title")
        layout.addWidget(title)

        subtitle = QLabel(
            "Hold a hotkey to record speech, release to paste the transcription "
            "into any app. Private, local, and ready when you are."
        )
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        layout.addSpacing(16)

        # Enabled checkbox
        self._enabled_check = QCheckBox("  Enable dictation mode")
        self._enabled_check.setChecked(True)
        self._enabled_check.setStyleSheet("font-size: 14px; color: #fafafa;")
        layout.addWidget(self._enabled_check)

        layout.addSpacing(4)

        # Filler removal checkbox
        self._filler_check = QCheckBox("  Remove filler words (um, uh, like) using local LLM")
        self._filler_check.setChecked(self._load_current_filler_removal())
        self._filler_check.setStyleSheet("font-size: 14px; color: #fafafa;")
        layout.addWidget(self._filler_check)

        filler_note = QLabel(
            "Uses your chat model to clean up dictation output. "
            "Adds a small delay (~1–3 s) after each dictation."
        )
        filler_note.setWordWrap(True)
        filler_note.setStyleSheet("color: #71717a; font-size: 12px; margin-left: 28px;")
        layout.addWidget(filler_note)

        layout.addSpacing(8)

        # Hotkey selection
        hotkey_card = QFrame()
        hotkey_card.setObjectName("card")
        hotkey_layout = QVBoxLayout(hotkey_card)
        hotkey_layout.setContentsMargins(18, 16, 18, 16)
        hotkey_layout.setSpacing(12)

        hotkey_title = QLabel("⌨️ Dictation Hotkey")
        hotkey_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #fbbf24;")
        hotkey_layout.addWidget(hotkey_title)

        hotkey_desc = QLabel(
            "Choose the key combination you hold down while speaking. "
            "Double-tap the same hotkey for hands-free mode (continuous recording)."
        )
        hotkey_desc.setWordWrap(True)
        hotkey_desc.setStyleSheet("color: #a1a1aa; font-size: 13px;")
        hotkey_layout.addWidget(hotkey_desc)

        self._hotkey_combo = QComboBox()
        for value, label in self._hotkey_options():
            self._hotkey_combo.addItem(label, value)
        self._hotkey_combo.setStyleSheet(
            "QComboBox { padding: 8px; font-size: 14px; background: #27272a; "
            "color: #fafafa; border: 1px solid #3f3f46; border-radius: 6px; }"
        )

        # Pre-select the current/default hotkey
        current_hotkey = self._load_current_hotkey()
        idx = self._hotkey_combo.findData(current_hotkey)
        if idx >= 0:
            self._hotkey_combo.setCurrentIndex(idx)

        hotkey_layout.addWidget(self._hotkey_combo)
        layout.addWidget(hotkey_card)

        # Tips
        tips_card = QFrame()
        tips_card.setObjectName("card")
        tips_layout = QVBoxLayout(tips_card)
        tips_layout.setContentsMargins(18, 16, 18, 16)
        tips_layout.setSpacing(8)

        tips_title = QLabel("💡 How it Works")
        tips_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #fbbf24;")
        tips_layout.addWidget(tips_title)

        tips = QLabel(
            "<b>Hold to speak.</b> Release to transcribe and paste.<br><br>"
            "<b>Double-tap for hands-free.</b> Tap again or press Esc to stop.<br><br>"
            "Find past dictations in the tray, and customise your dictionary in Settings."
        )
        tips.setWordWrap(True)
        tips.setStyleSheet("color: #d4d4d8; font-size: 13px; line-height: 1.6;")
        tips_layout.addWidget(tips)

        layout.addWidget(tips_card)
        layout.addStretch()
        self.setLayout(layout)

    def _load_current_filler_removal(self) -> bool:
        """Load the current filler removal setting from config, defaulting to False."""
        try:
            from jarvis.config import get_config_path, _load_json
            config = _load_json(get_config_path())
            if config and "dictation_filler_removal" in config:
                return bool(config["dictation_filler_removal"])
            return False
        except Exception:
            return False

    def _load_current_hotkey(self) -> str:
        """Load the current hotkey from config, or platform default."""
        try:
            from jarvis.config import get_config_path, _load_json, _default_dictation_hotkey
            config = _load_json(get_config_path())
            if config and "dictation_hotkey" in config:
                return config["dictation_hotkey"]
            return _default_dictation_hotkey()
        except Exception:
            if sys.platform == "win32":
                return "ctrl+cmd"
            return "ctrl+alt"

    def validatePage(self) -> bool:
        """Save dictation settings to config before leaving page."""
        try:
            from jarvis.config import get_config_path, _load_json, _save_json
            config_path = get_config_path()
            config = _load_json(config_path) or {}

            enabled = self._enabled_check.isChecked()
            hotkey = self._hotkey_combo.currentData()
            filler_removal = self._filler_check.isChecked()

            config["dictation_enabled"] = enabled
            if hotkey:
                config["dictation_hotkey"] = hotkey
            config["dictation_filler_removal"] = filler_removal

            config_path.parent.mkdir(parents=True, exist_ok=True)
            _save_json(config_path, config)
        except Exception:
            pass
        return True

    def isComplete(self) -> bool:
        return True

    def nextId(self) -> int:
        wizard = self.wizard()
        if isinstance(wizard, SetupWizard):
            return wizard.mcp_page_id
        return super().nextId()


class MCPPage(ScrollableWizardPage):
    """Page for selecting popular MCP servers to enable."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("")

        layout = QVBoxLayout()
        layout.setSpacing(16)
        layout.setContentsMargins(28, 20, 28, 20)

        # Header
        title = QLabel("Give Jarvis more abilities")
        title.setObjectName("title")
        layout.addWidget(title)

        subtitle = QLabel(
            "MCP (Model Context Protocol) servers give Jarvis extra abilities. "
            "Select any you'd like to enable — you can always change these later in Settings."
        )
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        layout.addSpacing(8)

        # Node.js availability warning
        self._node_warning = QLabel(
            "⚠️  <b>Node.js not found.</b> The MCP servers below require Node.js to run. "
            "<a href='https://nodejs.org/' style='color: #f59e0b;'>Download Node.js</a> "
            "and restart Jarvis, or skip this page for now."
        )
        self._node_warning.setOpenExternalLinks(True)
        self._node_warning.setWordWrap(True)
        self._node_warning.setStyleSheet(
            "background: rgba(239, 68, 68, 0.12);"
            "border: 1px solid rgba(239, 68, 68, 0.35);"
            "border-radius: 8px; padding: 12px 16px; color: #fca5a5; font-size: 13px;"
        )
        self._node_warning.setVisible(not self._is_node_available())
        layout.addWidget(self._node_warning)

        # Scrollable cards for wizard-featured entries
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        inner = QWidget()
        inner_layout = QVBoxLayout(inner)
        inner_layout.setSpacing(10)

        self._checkboxes: Dict[str, QCheckBox] = {}
        for entry in get_wizard_entries():
            card = QFrame()
            card.setObjectName("card")
            card_layout = QHBoxLayout(card)
            card_layout.setContentsMargins(16, 14, 16, 14)
            card_layout.setSpacing(14)

            cb = QCheckBox()
            cb.setChecked(self._is_already_configured(entry.name))
            self._checkboxes[entry.name] = cb
            card_layout.addWidget(cb)

            text_layout = QVBoxLayout()
            text_layout.setSpacing(2)

            name_label = QLabel(entry.display_name)
            name_label.setStyleSheet("font-size: 15px; font-weight: bold;")
            text_layout.addWidget(name_label)

            desc_label = QLabel(entry.description)
            desc_label.setWordWrap(True)
            desc_label.setStyleSheet("color: #a1a1aa; font-size: 13px;")
            text_layout.addWidget(desc_label)

            card_layout.addLayout(text_layout, 1)
            inner_layout.addWidget(card)

        inner_layout.addStretch()
        scroll.setWidget(inner)
        layout.addWidget(scroll, 1)

        # Tip about more MCPs in settings
        tip = QLabel(
            "💡  Many more MCP servers are available in <b>Settings → 🔌 MCP Servers</b>, "
            "including GitHub, Slack, Spotify, and custom servers."
        )
        tip.setWordWrap(True)
        tip.setStyleSheet(
            "background: qlineargradient(x1:0, y1:0, x2:1, y2:0, "
            "stop:0 rgba(245, 158, 11, 0.12), stop:1 rgba(139, 92, 246, 0.08));"
            "border: 1px solid rgba(245, 158, 11, 0.25);"
            "border-radius: 8px; padding: 12px 16px; color: #fbbf24; font-size: 13px;"
        )
        layout.addWidget(tip)

        self.setLayout(layout)

    @staticmethod
    def _is_node_available() -> bool:
        """Check if Node.js (npx) is available on the system."""
        try:
            from jarvis.tools.external.mcp_client import _resolve_command
            _resolve_command("npx")
            return True
        except (FileNotFoundError, Exception):
            return False

    @staticmethod
    def _is_already_configured(name: str) -> bool:
        """Check if an MCP server is already in the user's config."""
        try:
            from jarvis.config import get_config_path, _load_json
            config = _load_json(get_config_path())
            return name in (config.get("mcps") or {})
        except Exception:
            return False

    def validatePage(self) -> bool:
        """Save selected MCPs to config before leaving page."""
        try:
            from jarvis.config import get_config_path, _load_json, _save_json
            config_path = get_config_path()
            config = _load_json(config_path) or {}

            mcps = config.get("mcps", {})
            if not isinstance(mcps, dict):
                mcps = {}

            for entry in get_wizard_entries():
                cb = self._checkboxes.get(entry.name)
                if cb and cb.isChecked() and entry.name not in mcps:
                    mcps[entry.name] = entry.to_config()
                elif cb and not cb.isChecked() and entry.name in mcps:
                    del mcps[entry.name]

            if mcps:
                config["mcps"] = mcps
            else:
                config.pop("mcps", None)

            config_path.parent.mkdir(parents=True, exist_ok=True)
            _save_json(config_path, config)
        except Exception:
            pass
        return True

    def isComplete(self) -> bool:
        return True

    def nextId(self) -> int:
        wizard = self.wizard()
        if isinstance(wizard, SetupWizard):
            return wizard.search_providers_page_id
        return super().nextId()


class SearchProvidersPage(ScrollableWizardPage):
    """Explain and configure web-search fallback providers.

    Ordering mirrors the runtime fallback chain: DDG → Brave → Wikipedia →
    honest "blocked" envelope. The page is always shown (even when nothing
    needs configuring) because the explainer itself is the point — users
    should understand what Jarvis will and won't reach over the network
    before they start using it.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("")

        layout = QVBoxLayout()
        layout.setSpacing(16)
        layout.setContentsMargins(28, 20, 28, 20)

        title = QLabel("Stay curious")
        title.setObjectName("title")
        layout.addWidget(title)

        subtitle = QLabel(
            "Jarvis uses DuckDuckGo for web search. When DuckDuckGo blocks a "
            "request or has nothing useful, these optional fallbacks keep "
            "answers flowing — all off by default except Wikipedia."
        )
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        layout.addSpacing(4)

        # --- Brave Search card ---
        brave_card = QFrame()
        brave_card.setObjectName("card")
        brave_layout = QVBoxLayout(brave_card)
        brave_layout.setContentsMargins(16, 14, 16, 14)
        brave_layout.setSpacing(8)

        brave_title = QLabel("🦁 Brave Search (optional)")
        brave_title.setStyleSheet("font-size: 15px; font-weight: bold;")
        brave_layout.addWidget(brave_title)

        brave_desc = QLabel(
            "When set, Brave becomes the first fallback the moment "
            "DuckDuckGo is rate-limited. Free tier: 2,000 queries/month. "
            "Get a key at "
            "<a href='https://api.search.brave.com/app/keys' "
            "style='color: #f59e0b;'>api.search.brave.com</a>."
        )
        brave_desc.setOpenExternalLinks(True)
        brave_desc.setWordWrap(True)
        brave_desc.setStyleSheet("color: #a1a1aa; font-size: 13px;")
        brave_layout.addWidget(brave_desc)

        self._brave_input = QLineEdit()
        self._brave_input.setPlaceholderText("BSA... (leave empty to skip)")
        self._brave_input.setEchoMode(QLineEdit.EchoMode.Password)
        self._brave_input.setText(self._load_current_brave_key())
        brave_layout.addWidget(self._brave_input)

        layout.addWidget(brave_card)

        # --- Wikipedia card ---
        wiki_card = QFrame()
        wiki_card.setObjectName("card")
        wiki_layout = QVBoxLayout(wiki_card)
        wiki_layout.setContentsMargins(16, 14, 16, 14)
        wiki_layout.setSpacing(8)

        wiki_title = QLabel("📚 Wikipedia (zero-config)")
        wiki_title.setStyleSheet("font-size: 15px; font-weight: bold;")
        wiki_layout.addWidget(wiki_title)

        wiki_desc = QLabel(
            "Last-resort fallback. No key, no account, privacy-light. Uses "
            "the Wikipedia host matching the language Whisper detects in "
            "your utterance, so a Turkish question gets a Turkish answer."
        )
        wiki_desc.setWordWrap(True)
        wiki_desc.setStyleSheet("color: #a1a1aa; font-size: 13px;")
        wiki_layout.addWidget(wiki_desc)

        self._wiki_check = QCheckBox("  Enable Wikipedia fallback")
        self._wiki_check.setChecked(self._load_current_wikipedia_enabled())
        wiki_layout.addWidget(self._wiki_check)

        layout.addWidget(wiki_card)

        tip = QLabel(
            "💡  When every provider fails, Jarvis tells you the search was "
            "blocked rather than making something up."
        )
        tip.setWordWrap(True)
        tip.setStyleSheet(
            "background: qlineargradient(x1:0, y1:0, x2:1, y2:0, "
            "stop:0 rgba(245, 158, 11, 0.12), stop:1 rgba(139, 92, 246, 0.08));"
            "border: 1px solid rgba(245, 158, 11, 0.25);"
            "border-radius: 8px; padding: 12px 16px; color: #fbbf24; font-size: 13px;"
        )
        layout.addWidget(tip)

        layout.addStretch()

        self.setLayout(layout)

    @staticmethod
    def _load_current_brave_key() -> str:
        try:
            from jarvis.config import get_config_path, _load_json
            config = _load_json(get_config_path())
            return str(config.get("brave_search_api_key", "") or "")
        except Exception:
            return ""

    @staticmethod
    def _load_current_wikipedia_enabled() -> bool:
        try:
            from jarvis.config import get_config_path, _load_json
            config = _load_json(get_config_path())
            # Default True to match config.py's default.
            val = config.get("wikipedia_fallback_enabled", True)
            return bool(val)
        except Exception:
            return True

    def validatePage(self) -> bool:
        """Persist Brave key + Wikipedia toggle. Only writes non-default
        values to keep config.json minimal (consistent with the settings
        window's "only non-default values written" invariant)."""
        try:
            from jarvis.config import get_config_path, _load_json, _save_json
            config_path = get_config_path()
            config = _load_json(config_path) or {}

            brave_key = (self._brave_input.text() or "").strip()
            if brave_key:
                config["brave_search_api_key"] = brave_key
            else:
                config.pop("brave_search_api_key", None)

            wiki_on = bool(self._wiki_check.isChecked())
            # Default is True; only persist when the user diverges from it.
            if not wiki_on:
                config["wikipedia_fallback_enabled"] = False
            else:
                config.pop("wikipedia_fallback_enabled", None)

            config_path.parent.mkdir(parents=True, exist_ok=True)
            _save_json(config_path, config)
        except Exception:
            pass
        return True

    def isComplete(self) -> bool:
        return True

    def nextId(self) -> int:
        wizard = self.wizard()
        if isinstance(wizard, SetupWizard):
            if not wizard.is_location_working():
                return wizard.location_page_id
            return wizard.complete_page_id
        return super().nextId()


class CompletePage(ScrollableWizardPage):
    """Final page showing setup is complete."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("")
        self.setFinalPage(True)

        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setContentsMargins(28, 20, 28, 20)

        # Big success icon
        success_icon = QLabel("🎉")
        success_icon.setStyleSheet("font-size: 72px;")
        success_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(success_icon)

        # Header
        title = QLabel("Meet your Jarvis")
        title.setObjectName("title")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel("Jarvis is ready to use. Click 'Start Jarvis' to launch the voice assistant.")
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)

        layout.addSpacing(40)

        # Tips card
        card = QFrame()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(18, 16, 18, 16)
        card_layout.setSpacing(12)

        tips_title = QLabel("💡 Quick Tips")
        tips_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #fbbf24;")
        card_layout.addWidget(tips_title)
        card_layout.addSpacing(8)

        tips = QLabel(
            "• Say your wake word (e.g. 'Jarvis') anywhere in your sentence to activate the assistant\n"
            "• After Jarvis replies, speak your follow-up — no need to repeat the wake word\n"
            "• Jarvis will appear in your system tray (menu bar on macOS)\n"
            "• Right-click the tray icon to access settings and controls\n"
            "• View logs by clicking '📝 View Logs' in the tray menu"
        )
        tips.setWordWrap(True)
        tips.setStyleSheet("line-height: 1.8;")
        card_layout.addWidget(tips)

        # Memory viewer tip with special styling
        brain_tip = QLabel("🧠  Peek inside Jarvis's brain — open the Memory Viewer to see what he remembers")
        brain_tip.setWordWrap(True)
        brain_tip.setStyleSheet("""
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 rgba(245, 158, 11, 0.15), stop:1 rgba(139, 92, 246, 0.1));
            border: 1px solid rgba(245, 158, 11, 0.3);
            border-radius: 8px;
            padding: 12px 16px;
            margin-top: 8px;
            color: #fbbf24;
            font-style: italic;
        """)
        card_layout.addWidget(brain_tip)

        layout.addWidget(card)

        layout.addStretch()

        self.setLayout(layout)

    def initializePage(self):
        """Hide Cancel button on final page - user can use window close if needed."""
        wizard = self.wizard()
        if wizard:
            wizard.button(QWizard.WizardButton.CancelButton).setVisible(False)

    def nextId(self) -> int:
        """No next page."""
        return -1


def run_setup_wizard() -> bool:
    """
    Run the setup wizard.
    Returns True if setup completed successfully, False if cancelled.
    """
    if not _PYQT6_AVAILABLE:
        raise ImportError(
            "PyQt6 is not available. Install it with: pip install PyQt6\n"
            "On Linux, you may also need: apt-get install libegl1"
        )

    # Create app if not exists
    app = QApplication.instance()
    if app is None:
        app = QApplication([])

    wizard = SetupWizard()
    result = wizard.exec()

    return result == QWizard.DialogCode.Accepted


if __name__ == "__main__":
    # For testing
    app = QApplication(sys.argv)
    wizard = SetupWizard()
    result = wizard.exec()
    print(f"Wizard result: {result}")
    sys.exit(0)
