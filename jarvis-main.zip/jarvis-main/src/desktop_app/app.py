"""
Jarvis Desktop App - System Tray Application

A cross-platform system tray app for controlling the Jarvis voice assistant.
Supports Windows, Ubuntu (Linux), and macOS.
"""

from __future__ import annotations
import sys
import os
import time

# Fix OpenBLAS threading crash in bundled apps
# Must be set before numpy is imported (via faster-whisper, etc.)
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
# Hugging Face uses this non-terminal mode to emit actual byte progress.
# Set it before importing tqdm, including in the inherited daemon environment.
os.environ.setdefault('TQDM_POSITION', '-1')

# Suppress pkg_resources deprecation warning from webrtcvad
import warnings
warnings.filterwarnings('ignore', message='pkg_resources is deprecated',
                        category=UserWarning)

# Note: QtWebEngine is not used on macOS bundled apps due to sandbox/bundling issues
# The Memory Viewer opens in the system browser instead (see MemoryViewerWindow)

import subprocess
import signal
import psutil
import threading
import traceback
import atexit
import webbrowser
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from desktop_app.cuda_recovery import CudaRecoveryAction
from PyQt6.QtWidgets import QApplication, QSystemTrayIcon, QMenu, QMainWindow, QTextEdit, QVBoxLayout, QHBoxLayout, QWidget, QLabel, QDialog, QPushButton, QProgressBar, QScrollArea, QFrame
from PyQt6.QtGui import QIcon, QAction, QFont, QTextCursor, QTextCharFormat, QColor
from PyQt6.QtCore import QTimer, Qt, pyqtSignal, QObject, QThread, QUrl
from desktop_app.qt_worker import KeepAliveWorker

# Global lock file handle (must remain open for the lock to persist)
_lock_file_handle = None
# Byte offset used for the lock region — deliberately beyond where PID content
# lives (bytes 0–~10) so other processes can still read the PID while the lock
# is held.  Windows msvcrt.locking() creates mandatory locks that block ALL
# access (including reads from other handles) on the locked bytes, so locking
# at byte 0 would make the PID unreadable by a second instance.
_LOCK_OFFSET = 1024

# Try to import WebEngine (optional dependency for embedded memory viewer)
try:
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    HAS_WEBENGINE = True
except ImportError:
    HAS_WEBENGINE = False
    QWebEngineView = None

from jarvis.debug import debug_log
from jarvis.llm.model_names import missing_ollama_models
from jarvis.config import get_config_path, _default_db_path, get_model_recommendations, Settings
from desktop_app.diary_dialog import DiaryUpdateDialog
from desktop_app.themes import JARVIS_THEME_STYLESHEET, COLORS, apply_theme
from desktop_app.log_output import LogStream, clean_log, parse_progress
from desktop_app.face_widget import FaceWindow


_LOG_SEPARATOR = "─" * 50


@dataclass
class OllamaRuntimeOwnership:
    """Tracks whether this desktop session launched the local Ollama runtime."""

    started_by_jarvis: bool = False
    launch_method: str = ""
    process: Optional[subprocess.Popen] = None
    stopped: bool = False


@dataclass(frozen=True)
class RuntimeStatusSnapshot:
    """Current desktop runtime state shown in the tray diagnostics dialog."""

    daemon_state: str
    daemon_mode: str
    daemon_pid: Optional[int]
    ollama_needed: bool
    ollama_running: bool
    ollama_version: Optional[str]
    ollama_owner: str
    ollama_launch_method: str
    low_power_mode: bool
    llm_provider: str
    chat_model: str
    embedding_provider: str
    embedding_model: str
    mcp_count: int


class RuntimeStatusSignals(QObject):
    """Carries a collected runtime snapshot back to the GUI thread."""

    ready = pyqtSignal(object)


def _should_emit_as_log(line: str) -> bool:
    """Whether a daemon output line belongs in the general log viewer.

    Chat and voice-control IPC are excluded. The daemon supplies separate
    redacted query and scrubbed reply activity lines for chat. Diary IPC
    carries progress and token deltas for the log window.
    """
    from jarvis.daemon import CHAT_IPC_PREFIX, VOICE_STATUS_IPC_PREFIX

    from jarvis.tasks import TASK_EVENT_PREFIX
    return not line.startswith((CHAT_IPC_PREFIX, VOICE_STATUS_IPC_PREFIX, TASK_EVENT_PREFIX))


def _collect_runtime_status_snapshot(
    *,
    is_listening: bool,
    is_bundled: bool,
    daemon_process,
    daemon_thread,
    ollama_runtime_ownership: Optional[OllamaRuntimeOwnership],
    settings_loader=None,
    ollama_checker=None,
) -> RuntimeStatusSnapshot:
    """Collect runtime status without mutating desktop or daemon state."""
    if settings_loader is None:
        from jarvis.config import load_settings as settings_loader
    if ollama_checker is None:
        from desktop_app.setup_wizard import check_ollama_server as ollama_checker

    cfg = None
    try:
        cfg = settings_loader()
        ollama_needed, _chat_on_ollama = _ollama_runtime_flags(cfg)
    except Exception as exc:
        debug_log(f"runtime status config load failed: {exc}", "desktop")
        ollama_needed = True

    try:
        ollama_running, ollama_version = ollama_checker()
    except Exception as exc:
        debug_log(f"runtime status Ollama check failed: {exc}", "desktop")
        ollama_running, ollama_version = False, None

    daemon_pid = None
    if is_listening:
        if daemon_process is not None:
            daemon_pid = getattr(daemon_process, "pid", None)
        elif is_bundled and daemon_thread is not None:
            daemon_pid = os.getpid()

    ownership = ollama_runtime_ownership or OllamaRuntimeOwnership()
    if ownership.started_by_jarvis and not ownership.stopped:
        ollama_owner = "Jarvis"
    elif ollama_running:
        ollama_owner = "External"
    else:
        ollama_owner = "None"

    llm_provider = "unknown"
    chat_model = "unknown"
    embedding_provider = "unknown"
    embedding_model = "unknown"
    low_power_mode = False
    mcp_count = 0
    if cfg is not None:
        llm_provider = str(getattr(cfg, "llm_provider", "") or "unknown")
        chat_model = str(getattr(cfg, "llm_chat_model", "") or "unknown")
        embedding_provider = str(
            getattr(cfg, "embedding_provider", "") or llm_provider or "unknown"
        )
        embedding_model = str(getattr(cfg, "embedding_model", "") or "unknown")
        low_power_mode = getattr(cfg, "low_power_mode", False) is True
        mcps = getattr(cfg, "mcps", {}) or {}
        mcp_count = len(mcps) if isinstance(mcps, dict) else 0

    return RuntimeStatusSnapshot(
        daemon_state="Listening" if is_listening else "Stopped",
        daemon_mode="bundled" if is_bundled else "subprocess",
        daemon_pid=daemon_pid,
        ollama_needed=ollama_needed,
        ollama_running=ollama_running,
        ollama_version=ollama_version,
        ollama_owner=ollama_owner,
        ollama_launch_method=ownership.launch_method or "n/a",
        low_power_mode=low_power_mode,
        llm_provider=llm_provider,
        chat_model=chat_model,
        embedding_provider=embedding_provider,
        embedding_model=embedding_model,
        mcp_count=mcp_count,
    )


def _runtime_status_rows(snapshot: RuntimeStatusSnapshot) -> list[tuple[str, str, str]]:
    """Return ``(section, key, value)`` rows for the runtime status dialog.

    Sections keep the emoji headers of the original text format so the
    dialog and the (test-pinned) ``_format_runtime_status`` text stay in
    sync from one source of truth.
    """
    pid = str(snapshot.daemon_pid) if snapshot.daemon_pid is not None else "n/a"
    ollama_running = (
        f"Yes ({snapshot.ollama_version})"
        if snapshot.ollama_running and snapshot.ollama_version
        else "Yes"
        if snapshot.ollama_running
        else "No"
    )
    return [
        ("🎙️ Assistant", "State", snapshot.daemon_state),
        ("🎙️ Assistant", "Mode", snapshot.daemon_mode),
        ("🎙️ Assistant", "PID", pid),
        ("🎙️ Assistant", "Low Power Mode", "On" if snapshot.low_power_mode else "Off"),
        ("🦙 Ollama", "Needed", "Yes" if snapshot.ollama_needed else "No"),
        ("🦙 Ollama", "Running", ollama_running),
        ("🦙 Ollama", "Owner", snapshot.ollama_owner),
        ("🦙 Ollama", "Launch method", snapshot.ollama_launch_method),
        ("🧠 Models", "Provider", snapshot.llm_provider),
        ("🧠 Models", "Chat", snapshot.chat_model),
        (
            "🧠 Models",
            "Embeddings",
            f"{snapshot.embedding_provider} / {snapshot.embedding_model}",
        ),
        ("🔌 MCP", "Configured servers", str(snapshot.mcp_count)),
    ]


def _format_runtime_status(snapshot: RuntimeStatusSnapshot) -> str:
    """Format a runtime status snapshot for the tray diagnostics dialog."""
    lines: list[str] = ["🩺 Runtime Status", ""]
    current_section = None
    for section, key, value in _runtime_status_rows(snapshot):
        if section != current_section:
            if current_section is not None:
                lines.append("")
            lines.append(section)
            current_section = section
        lines.append(f"  {key}: {value}")
    return "\n".join(lines)


class RuntimeStatusDialog(QDialog):
    """Themed diagnostic summary of Jarvis' active runtime.

    Renders the collected snapshot as a structured dialog: emoji section
    headers, aligned key/value rows (secondary-colour keys, monospace
    values), and a Close button. Snapshot collection stays on the worker
    thread; this dialog only renders the data it is handed.
    """

    def __init__(self, snapshot: RuntimeStatusSnapshot, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Runtime Status")
        self.setStyleSheet(JARVIS_THEME_STYLESHEET)
        self.setMinimumWidth(380)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(4)

        title = QLabel("🩺 Runtime Status")
        title.setObjectName("title")
        layout.addWidget(title)
        layout.addSpacing(6)

        current_section = None
        for section, key, value in _runtime_status_rows(snapshot):
            if section != current_section:
                if current_section is not None:
                    layout.addSpacing(8)
                header = QLabel(section)
                header.setStyleSheet(
                    "color: #fbbf24; font-weight: bold; font-size: 13px;"
                )
                layout.addWidget(header)
                current_section = section
            row = QHBoxLayout()
            key_label = QLabel(key)
            key_label.setStyleSheet("color: #a1a1aa; font-size: 13px;")
            value_label = QLabel(value)
            value_label.setStyleSheet(
                "color: #f4f4f5; font-size: 13px;"
                " font-family: 'SF Mono', 'Menlo', monospace;"
            )
            value_label.setWordWrap(True)
            row.addWidget(key_label)
            row.addStretch(1)
            row.addWidget(value_label)
            layout.addLayout(row)

        layout.addSpacing(12)
        close_btn = QPushButton("Close")
        close_btn.setDefault(True)
        close_btn.clicked.connect(self.accept)
        button_row = QHBoxLayout()
        button_row.addStretch(1)
        button_row.addWidget(close_btn)
        layout.addLayout(button_row)


def _stop_owned_ollama_runtime(
    ownership: Optional[OllamaRuntimeOwnership],
    *,
    timeout_sec: float = 5.0,
    command_runner=subprocess.run,
) -> bool:
    """Stop Ollama only when this desktop session launched it.

    Returns True when a stop command was sent, False when there was no owned
    runtime to stop. This is intentionally conservative: a pre-existing
    user-managed Ollama process is left alone.
    """
    if (
        ownership is None
        or not ownership.started_by_jarvis
        or ownership.stopped
    ):
        return False

    stopped = False
    process = ownership.process

    if ownership.launch_method == "macos_app" and sys.platform == "darwin":
        try:
            result = command_runner(
                ["osascript", "-e", 'tell application "Ollama" to quit'],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=timeout_sec,
                check=False,
            )
            stopped = True
            if getattr(result, "returncode", 0) != 0:
                debug_log("Ollama AppleScript quit failed, falling back to TERM", "desktop")
                command_runner(
                    ["pkill", "-TERM", "-x", "Ollama"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=timeout_sec,
                    check=False,
                )
                command_runner(
                    [
                        "pkill",
                        "-TERM",
                        "-f",
                        "/Applications/Ollama.app/Contents/Resources/ollama serve",
                    ],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=timeout_sec,
                    check=False,
                )
        except Exception as exc:
            debug_log(f"failed to stop owned Ollama.app runtime: {exc}", "desktop")
    elif process is not None:
        try:
            if process.poll() is None:
                process.terminate()
                stopped = True
                try:
                    process.wait(timeout=timeout_sec)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=timeout_sec)
        except Exception as exc:
            debug_log(f"failed to stop owned Ollama serve process: {exc}", "desktop")

    ownership.stopped = stopped
    if stopped:
        debug_log("owned Ollama runtime stopped", "desktop")
    return stopped


def _trim_extension_modules(logs: str) -> str:
    """Shorten the faulthandler 'Extension modules:' line to a brief summary.

    This line typically consumes 1500-2500 chars of module names that rarely
    help with crash diagnosis.  Replacing it frees space for the critical
    'Fatal Python error' header and current-thread stack trace.
    """
    import re
    # Match "Extension modules: mod1, mod2, ... (total: N)\n"
    m = re.search(
        r'^(Extension modules:) [^\n]+\(total: (\d+)\)\s*$',
        logs, re.MULTILINE,
    )
    if m:
        return logs[:m.start()] + f"{m.group(1)} ({m.group(2)} total — trimmed for brevity)\n" + logs[m.end():]

    # Fallback: line without "(total: N)" — just truncate after first few modules
    m = re.search(
        r'^(Extension modules:) (.{80}).+$',
        logs, re.MULTILINE,
    )
    if m:
        return logs[:m.start()] + f"{m.group(1)} {m.group(2)}... (trimmed)\n" + logs[m.end():]

    return logs


def _extract_fatal_section(logs: str) -> str:
    """Extract the 'Fatal Python error' header + current thread stack.

    In faulthandler dumps these lines carry the actual crash cause and
    appear between the fatal error line and the first other thread
    (i.e. the first ``Thread 0x`` header after ``Current thread 0x``).
    Returns "" if not found.
    """
    import re
    # Find "Fatal Python error: ..." line
    m = re.search(r'^Fatal Python error: .+$', logs, re.MULTILINE)
    if not m:
        return ""

    start = m.start()

    # Grab everything up to (but not including) the first "Thread 0x" header.
    # "Current thread 0x..." uses a different prefix so won't match here.
    rest = logs[start:]
    first_other_thread = next(re.finditer(r'^Thread 0x', rest, re.MULTILINE), None)
    if first_other_thread:
        end = start + first_other_thread.start()
    else:
        # No other thread header — take up to 500 chars
        end = start + min(500, len(rest))

    return logs[start:end].rstrip() + "\n"


def _snap_to_line_boundary(text: str) -> str:
    """Advance past a partial first line so truncated output starts cleanly."""
    newline_idx = text.find('\n')
    if newline_idx != -1 and newline_idx < 200:
        return text[newline_idx + 1:]
    return text


def _truncate_logs_for_report(logs: str, max_len: int) -> str:
    """Truncate logs keeping init section + recent tail.

    Recent logs are more valuable for debugging, so we preserve the tail.
    The init section (everything up to the last separator line) is kept
    for context (version, platform, configuration info).

    For faulthandler crash dumps, the bulky 'Extension modules:' line is
    trimmed first and the 'Fatal Python error' header + current thread
    stack are preserved as a priority section so the root cause survives
    truncation.
    """
    # Trim the Extension modules line before size check — it wastes ~1700
    # chars of budget on module names that almost never help diagnose a crash.
    if "Extension modules:" in logs:
        logs = _trim_extension_modules(logs)

    if len(logs) <= max_len:
        return logs

    marker = "\n\n... (truncated) ...\n\n"

    # Find the init section: everything up to and including the last separator line
    last_sep = logs.rfind(_LOG_SEPARATOR)
    if last_sep != -1:
        init_end = logs.find('\n', last_sep)
        if init_end == -1:
            init_end = last_sep + len(_LOG_SEPARATOR)
        else:
            init_end += 1  # Include the newline
        init_section = logs[:init_end]
    else:
        # No separator found (e.g. crash logs); skip init preservation
        init_section = ""

    # For faulthandler dumps, extract the fatal error + current thread stack
    # as a second must-keep section (the most diagnostic part of the dump).
    fatal_section = _extract_fatal_section(logs)

    # Cap fatal_section so it never alone exceeds the budget
    fatal_cap = max(0, max_len - len(marker) - 200)  # leave room for tail
    if len(fatal_section) > fatal_cap:
        fatal_section = fatal_section[:fatal_cap].rstrip() + "\n"

    if len(init_section) + len(fatal_section) + len(marker) * 2 >= max_len:
        # Budget too tight — keep fatal section + tail only
        if fatal_section:
            tail_budget = max(0, max_len - len(fatal_section) - len(marker))
            if tail_budget == 0:
                return fatal_section[:max_len]
            tail_part = _snap_to_line_boundary(logs[-tail_budget:])
            return fatal_section + marker + tail_part

        # No fatal section — just keep the tail
        tail_budget = max(0, max_len - len(marker))
        tail_part = _snap_to_line_boundary(logs[-tail_budget:])
        return marker.lstrip() + tail_part

    # Build: init_section + marker + fatal_section + marker + tail
    fixed_parts = init_section + marker + fatal_section
    if fatal_section:
        fixed_parts += marker

    tail_budget = max(0, max_len - len(fixed_parts))
    tail_part = _snap_to_line_boundary(logs[-tail_budget:])

    return fixed_parts + tail_part


def setup_crash_logging():
    """Set up crash logging for the bundled app to capture startup errors."""
    if getattr(sys, 'frozen', False):
        # Running as bundled app - use shared crash path helper
        crash_log, _, _ = get_crash_paths()
        log_file = crash_log
        log_dir = log_file.parent

        try:
            log_dir.mkdir(parents=True, exist_ok=True)

            # Redirect stdout and stderr to log file with line buffering for immediate writes
            # buffering=1 means line-buffered mode (flush on newline)
            log_handle = open(log_file, 'w', encoding='utf-8', buffering=1)
            sys.stdout = log_handle
            sys.stderr = log_handle

            # Enable faulthandler to dump Python traceback on segfaults/aborts
            # This catches SIGSEGV, SIGFPE, SIGABRT, SIGBUS, SIGILL
            import faulthandler
            faulthandler.enable(file=log_handle)

            print(f"=== Jarvis Desktop App Crash Log ===", flush=True)
            print(f"Timestamp: {__import__('datetime').datetime.now()}", flush=True)
            print(f"Platform: {sys.platform}", flush=True)
            print(f"Python: {sys.version}", flush=True)
            print(f"Executable: {sys.executable}", flush=True)
            print(f"Frozen: {getattr(sys, 'frozen', False)}", flush=True)
            print(f"Bundle dir: {getattr(sys, '_MEIPASS', 'N/A')}", flush=True)
            print("=" * 50, flush=True)
            print(f"📁 This log: {log_file}", flush=True)
            if sys.platform == "darwin":
                print(f"📁 System crash reports: ~/Library/Logs/DiagnosticReports/", flush=True)
            elif sys.platform == "win32":
                print(f"📁 Windows Event Viewer: eventvwr.msc → Windows Logs → Application", flush=True)
            print("=" * 50, flush=True)
            print(flush=True)

            return log_file
        except Exception as e:
            # If we can't set up logging, at least try to show a dialog
            return None
    return None


def get_crash_paths() -> tuple[Path, Path, Path]:
    """Get paths for crash log, marker, and previous crash log."""
    from desktop_app.paths import get_log_dir
    log_dir = get_log_dir()

    crash_log = log_dir / "jarvis_desktop_crash.log"
    crash_marker = log_dir / ".crash_marker"
    previous_crash = log_dir / "previous_crash.log"

    return crash_log, crash_marker, previous_crash


def collect_macos_crash_report(
    crash_log_path: Path,
    diagnostics_dir: Optional[Path] = None,
    max_frames: int = 20,
) -> Optional[str]:
    """Collect the macOS native crash report (``.ips``) for a crashed
    session, if one exists.

    "Fatal Python error: Aborted" crashes are C-level aborts whose native
    stack faulthandler cannot capture (it only dumps Python frames). The
    OS still writes a full report to ``~/Library/Logs/DiagnosticReports/``;
    surfacing its exception type and top native frames alongside the Python
    dump makes these crashes diagnosable (#584/#575/#576).

    Returns a short human-readable excerpt (exception type, termination
    indicator, process name and the top native frames of the crashed
    thread), or ``None`` when no report applies: non-macOS platform,
    missing/empty diagnostics directory, no report newer than the crash
    log, or unparseable content.
    """
    if sys.platform != "darwin":
        return None
    try:
        if diagnostics_dir is None:
            diagnostics_dir = Path.home() / "Library" / "Logs" / "DiagnosticReports"
        if not diagnostics_dir.is_dir():
            return None

        app_name = "Jarvis"
        since = crash_log_path.stat().st_mtime if crash_log_path.exists() else 0.0

        candidates = []
        for report in diagnostics_dir.glob(f"{app_name}-*.ips"):
            try:
                modified = report.stat().st_mtime
                if modified >= since:
                    candidates.append((modified, report))
            except OSError:
                continue
        if not candidates:
            return None
        import json as _json
        data = None
        for _, newest in sorted(candidates, key=lambda item: item[0], reverse=True):
            try:
                raw_text = newest.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            # Reports contain a metadata line followed by a JSON payload;
            # the payload can be compact or pretty-printed.
            lines = raw_text.splitlines()
            payloads = [raw_text]
            if lines:
                payloads.extend(("\n".join(lines[1:]), lines[-1]))
            for payload in payloads:
                try:
                    parsed = _json.loads(payload)
                except ValueError:
                    continue
                if (isinstance(parsed, dict)
                        and isinstance(parsed.get("threads"), list)
                        and parsed["threads"]
                        and all(isinstance(thread, dict) for thread in parsed["threads"])):
                    data = parsed
                    break
            if data is not None:
                break
        if data is None:
            return None

        parts = [f"🧵 Native crash report: {newest.name}"]
        exc = data.get("exception") or {}
        if exc.get("type"):
            parts.append(f"  Exception: {exc['type']}")
        term = data.get("termination") or {}
        if term.get("indicator"):
            parts.append(f"  Termination: {term['indicator']}")

        crashed = None
        for thread in data.get("threads") or []:
            if thread.get("triggered"):
                crashed = thread
                break
        if crashed is None and data.get("threads"):
            crashed = data["threads"][0]
        frames = (crashed or {}).get("frames") or []
        if frames:
            parts.append("  Native frames (crashed thread):")
            for frame in frames[:max_frames]:
                # ``symbol`` is the demangled name; ``symbolLocation`` is a
                # byte offset — never fall back to it for display.
                symbol = frame.get("symbol")
                if not isinstance(symbol, str) or not symbol:
                    symbol = "?"
                parts.append(f"    {symbol}")
        return "\n".join(parts)
    except Exception:
        return None


def check_previous_crash() -> Optional[str]:
    """
    Check if previous session crashed and return crash details if so.

    Returns crash log content if previous session crashed, None otherwise.
    """
    try:
        crash_log, crash_marker, previous_crash = get_crash_paths()

        if crash_marker.exists():
            # Previous session didn't exit cleanly
            crash_marker.unlink()

            crash_content = None

            # Check for crash log content
            if crash_log.exists():
                content = crash_log.read_text(encoding='utf-8', errors='replace')
                # Only report if there's actual crash info (faulthandler output or errors)
                if 'Fatal' in content or 'Error' in content or 'Traceback' in content:
                    crash_content = content
                    # On macOS, append the native .ips stack so the crash
                    # dialog and report-issue body carry the C-level abort
                    # source faulthandler cannot show.
                    native = collect_macos_crash_report(crash_log)
                    if native:
                        crash_content += f"\n{native}\n"
                    # Save to previous_crash for reference
                    previous_crash.write_text(crash_content, encoding='utf-8')

            return crash_content

        return None
    except Exception:
        return None


def mark_session_started():
    """Mark that a session has started (for crash detection)."""
    try:
        _, crash_marker, _ = get_crash_paths()
        crash_marker.touch()
    except Exception:
        pass


def mark_session_clean_exit():
    """Mark that session exited cleanly (remove crash marker)."""
    try:
        _, crash_marker, _ = get_crash_paths()
        crash_marker.unlink(missing_ok=True)
    except Exception:
        pass


def show_crash_report_dialog(crash_content: str) -> None:
    """
    Show a dialog offering to submit a crash report to GitHub.

    Args:
        crash_content: The crash log content to include in the report.
    """
    try:
        from PyQt6.QtWidgets import (
            QDialog, QVBoxLayout, QHBoxLayout, QLabel,
            QPushButton, QTextEdit, QCheckBox
        )
        from PyQt6.QtCore import Qt
        import webbrowser
        import urllib.parse
        from jarvis import get_version

        class CrashReportDialog(QDialog):
            def __init__(self, crash_info: str):
                super().__init__()
                self.crash_info = crash_info
                self.setWindowTitle("🐛 Jarvis Crash Report")
                self.setMinimumSize(600, 450)
                self.setStyleSheet(JARVIS_THEME_STYLESHEET)
                self._setup_ui()

            def _setup_ui(self):
                layout = QVBoxLayout(self)
                layout.setSpacing(16)

                # Header
                header = QLabel("😵 Jarvis crashed in the previous session")
                header.setStyleSheet("font-size: 18px; font-weight: bold; color: #f87171;")
                layout.addWidget(header)

                # Description
                desc = QLabel(
                    "Would you like to report this crash? This helps us fix bugs faster.\n"
                    "The report will open as a GitHub issue (you can review before submitting)."
                )
                desc.setWordWrap(True)
                desc.setStyleSheet("color: #a1a1aa;")
                layout.addWidget(desc)

                # Crash log preview
                preview_label = QLabel("📋 Crash details (will be included in report):")
                preview_label.setStyleSheet("color: #71717a; margin-top: 8px;")
                layout.addWidget(preview_label)

                self.log_preview = QTextEdit()
                self.log_preview.setPlainText(self.crash_info[:3000])  # Limit preview
                self.log_preview.setReadOnly(True)
                self.log_preview.setStyleSheet("""
                    QTextEdit {
                        background-color: #18181b;
                        color: #a1a1aa;
                        font-family: monospace;
                        font-size: 11px;
                        border: 1px solid #27272a;
                        border-radius: 4px;
                    }
                """)
                self.log_preview.setMaximumHeight(200)
                layout.addWidget(self.log_preview)

                # Privacy note
                privacy = QLabel(
                    "ℹ️ No personal data is collected. You control what's submitted via GitHub."
                )
                privacy.setStyleSheet("color: #71717a; font-size: 11px;")
                layout.addWidget(privacy)

                # Buttons
                btn_layout = QHBoxLayout()
                btn_layout.addStretch()

                dismiss_btn = QPushButton("Dismiss")
                dismiss_btn.setStyleSheet("""
                    QPushButton {
                        background-color: #27272a;
                        color: #a1a1aa;
                        border: none;
                        padding: 8px 16px;
                        border-radius: 4px;
                    }
                    QPushButton:hover {
                        background-color: #3f3f46;
                    }
                """)
                dismiss_btn.clicked.connect(self.reject)
                btn_layout.addWidget(dismiss_btn)

                report_btn = QPushButton("📝 Report on GitHub")
                report_btn.setStyleSheet("""
                    QPushButton {
                        background-color: #2563eb;
                        color: white;
                        border: none;
                        padding: 8px 16px;
                        border-radius: 4px;
                        font-weight: bold;
                    }
                    QPushButton:hover {
                        background-color: #3b82f6;
                    }
                """)
                report_btn.clicked.connect(self._open_github_issue)
                btn_layout.addWidget(report_btn)

                layout.addLayout(btn_layout)

            def _open_github_issue(self):
                """Open GitHub issue with crash details pre-filled."""
                try:
                    version = get_version()
                except Exception:
                    version = "unknown"

                # Truncate crash info for URL (GitHub has limits)
                # Keep init lines + recent tail (recent logs are most useful for debugging)
                truncated = _truncate_logs_for_report(self.crash_info, 4000)
                # Escape backtick fences so log content can't break out of the code block
                truncated = truncated.replace('```', '`` `')

                title = "Crash Report"
                body = f"""## Crash Report

**Version:** {version}
**Platform:** {sys.platform}

### Crash Log
```
{truncated}
```

### Steps to Reproduce
(Please describe what you were doing when the crash occurred)

1.
2.
3.

### Additional Context
(Any other relevant information)
"""
                # URL encode
                params = urllib.parse.urlencode({
                    'title': title,
                    'body': body,
                    'labels': 'bug,crash'
                })
                url = f"https://github.com/isair/jarvis/issues/new?{params}"

                webbrowser.open(url)
                self.accept()

        dialog = CrashReportDialog(crash_content)
        dialog.exec()

    except Exception as e:
        debug_log(f"failed to show crash report dialog: {e}", "desktop")


def _model_role_selections(settings: Settings) -> tuple[tuple[str, str, str], ...]:
    """Resolved role, provider and model triples used by both advice and display."""
    return (
        ("Chat", settings.llm_provider, settings.llm_chat_model),
        ("Fast", settings.llm_provider, settings.fast_model),
        ("Embedding", settings.embedding_provider or settings.llm_provider,
         settings.embedding_model),
    )


def check_model_support(settings: Settings) -> dict[str, str]:
    """Return selections outside their provider's role recommendation names."""
    unlisted = {}
    for role, provider, model in _model_role_selections(settings):
        recommended = get_model_recommendations(provider)[role]
        is_unlisted = (
            bool(missing_ollama_models([model], recommended))
            if provider == "ollama" else model not in recommended
        )
        if is_unlisted:
            unlisted[role] = model
    return unlisted


class UnsupportedModelDialog(QDialog):
    """Optional recommendation advice with an explicit setup action."""

    def __init__(self, models: dict[str, str], settings: Settings):
        super().__init__()
        self.open_wizard = False
        self.setWindowTitle("Model recommendations")
        self.setMinimumWidth(500)
        self.setStyleSheet(JARVIS_THEME_STYLESHEET)
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.setContentsMargins(24, 24, 24, 24)
        header = QLabel("Your models are outside Jarvis's recommended list")
        header.setWordWrap(True)
        layout.addWidget(header)
        lines = [
            "You can keep using these models, or open setup to choose recommended models.",
            "",
        ]
        providers = {role: provider for role, provider, _ in _model_role_selections(settings)}
        for role, model in models.items():
            recommended = get_model_recommendations(providers[role])[role]
            lines.extend((f"{role}: {model}",
                          f"Recommended: {', '.join(recommended)}", ""))
        if any(providers[role] == "openai_compatible" for role in models):
            lines.append("External servers can use custom model names. A matching name does not "
                         "verify the model or its runtime. Use Connect & load models in setup "
                         "to check your server's models and capabilities.")
        description = QLabel("\n".join(lines))
        description.setTextFormat(Qt.TextFormat.PlainText)
        description.setWordWrap(True)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        margins = layout.contentsMargins()
        usable_width = (self.minimumWidth() - margins.left() - margins.right()
                        - scroll.verticalScrollBar().sizeHint().width())
        description.setMinimumSize(usable_width, description.heightForWidth(usable_width))
        scroll.setWidget(description)
        layout.addWidget(scroll)
        buttons = QHBoxLayout()
        buttons.addStretch()
        keep = QPushButton("Continue Anyway")
        keep.clicked.connect(self.accept)
        buttons.addWidget(keep)
        setup = QPushButton("🔧 Open Setup Wizard")
        setup.clicked.connect(self._open_wizard)
        buttons.addWidget(setup)
        layout.addLayout(buttons)

    def _open_wizard(self):
        self.open_wizard = True
        self.accept()


def show_unsupported_model_dialog(models: dict[str, str], settings: Settings) -> bool:
    """Return whether the user chose setup; advice never changes settings."""
    try:
        dialog = UnsupportedModelDialog(models, settings)
        dialog.exec()
        return dialog.open_wizard
    except Exception as exc:
        debug_log(f"failed to show model recommendation dialog: {exc}", "desktop")
        return False


def get_lock_file_path() -> Path:
    """Get the path to the single-instance lock file."""
    if sys.platform == "darwin":
        lock_dir = Path.home() / "Library" / "Application Support" / "Jarvis"
    elif sys.platform == "win32":
        lock_dir = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Jarvis"
    else:
        lock_dir = Path.home() / ".jarvis"

    lock_dir.mkdir(parents=True, exist_ok=True)
    return lock_dir / "jarvis_desktop.lock"


def get_existing_instance_pid() -> Optional[int]:
    """Read the PID of the existing Jarvis instance from the lock file."""
    lock_file = get_lock_file_path()
    try:
        if lock_file.exists():
            content = lock_file.read_text().strip()
            if content.isdigit():
                return int(content)
    except Exception:
        pass
    return None


def kill_existing_instance(pid: int) -> bool:
    """
    Terminate an existing Jarvis instance by PID.

    Returns True if the process was terminated, False otherwise.
    """
    try:
        process = psutil.Process(pid)
        # Verify it's actually a Jarvis process (safety check)
        proc_name = process.name().lower()
        if "jarvis" not in proc_name and "python" not in proc_name:
            debug_log(f"PID {pid} doesn't look like Jarvis (name: {proc_name}), not killing", "desktop")
            return False

        debug_log(f"Terminating existing Jarvis instance (PID {pid})", "desktop")
        process.terminate()

        # Wait up to 5 seconds for graceful shutdown
        try:
            process.wait(timeout=5)
        except psutil.TimeoutExpired:
            debug_log(f"Process {pid} didn't terminate gracefully, force killing", "desktop")
            process.kill()
            process.wait(timeout=2)

        return True
    except psutil.NoSuchProcess:
        # Process already gone
        return True
    except Exception as e:
        debug_log(f"Failed to kill process {pid}: {e}", "desktop")
        return False


def show_instance_conflict_dialog() -> bool:
    """
    Show a dialog asking the user if they want to kill the existing instance.

    Returns True if the user chose to kill, False to exit.
    Must be called after QApplication is created.
    """
    from PyQt6.QtWidgets import QMessageBox
    from PyQt6.QtGui import QIcon

    msg = QMessageBox()
    msg.setWindowTitle("Jarvis Already Running")
    msg.setText("Another instance of Jarvis is already running.")
    msg.setInformativeText("Would you like to close the existing instance and start a new one?")
    msg.setIcon(QMessageBox.Icon.Question)

    # Add custom buttons
    kill_btn = msg.addButton("Close Existing && Start New", QMessageBox.ButtonRole.AcceptRole)
    exit_btn = msg.addButton("Exit", QMessageBox.ButtonRole.RejectRole)
    msg.setDefaultButton(kill_btn)

    # Apply theme
    from desktop_app.themes import JARVIS_THEME_STYLESHEET
    msg.setStyleSheet(JARVIS_THEME_STYLESHEET)

    msg.exec()

    return msg.clickedButton() == kill_btn


def acquire_single_instance_lock() -> bool:
    """
    Acquire a lock to ensure only one instance of the desktop app runs.

    Returns True if lock acquired (we're the only instance), False otherwise.
    The lock file handle is kept open globally to maintain the lock.
    """
    global _lock_file_handle

    lock_file = get_lock_file_path()

    try:
        # Open in append+read binary mode — does NOT truncate the file.
        # Opening with 'w' would truncate immediately, destroying the existing
        # instance's PID before we even attempt the lock, making it unreadable.
        _lock_file_handle = open(lock_file, 'a+b')

        if sys.platform == "win32":
            # Windows: use msvcrt for file locking.
            # Lock at _LOCK_OFFSET (not byte 0) so the PID content at bytes
            # 0–~10 remains readable by other processes.  msvcrt.locking()
            # creates mandatory locks that block ALL I/O on the locked bytes.
            import msvcrt
            _lock_file_handle.seek(_LOCK_OFFSET)
            try:
                msvcrt.locking(_lock_file_handle.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                # Lock failed — another instance is running
                _lock_file_handle.close()
                _lock_file_handle = None
                return False
        else:
            # Unix (macOS, Linux): use fcntl for file locking
            import fcntl
            try:
                fcntl.flock(_lock_file_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except (IOError, OSError):
                # Lock failed - another instance is running
                _lock_file_handle.close()
                _lock_file_handle = None
                return False

        # Lock acquired — overwrite the file with our PID
        _lock_file_handle.seek(0)
        _lock_file_handle.truncate(0)
        _lock_file_handle.write(str(os.getpid()).encode())
        _lock_file_handle.flush()

        # Register cleanup to release lock on exit
        def release_lock():
            global _lock_file_handle
            if _lock_file_handle:
                try:
                    _lock_file_handle.close()
                except Exception:
                    pass
                _lock_file_handle = None

        atexit.register(release_lock)

        return True

    except Exception as e:
        print(f"Warning: Could not acquire single-instance lock: {e}")
        # On any error, allow the app to run (fail open)
        return True


class LogSignals(QObject):
    """Signals for thread-safe log updates."""
    new_log = pyqtSignal(str)
    voice_status = pyqtSignal(object, str)
    task_event = pyqtSignal(str)

    def dispatch_output(self, line: str) -> None:
        """Separate task protocol frames from user-facing activity lines."""
        from jarvis.tasks import TASK_EVENT_PREFIX
        if line.startswith(TASK_EVENT_PREFIX):
            self.task_event.emit(line)
        else:
            self.new_log.emit(line)


class LogViewerWindow(QMainWindow):
    """Window for viewing Jarvis logs in real-time."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("📝 Jarvis Logs")
        self.setGeometry(100, 100, 900, 650)

        # Apply theme
        self.setStyleSheet(JARVIS_THEME_STYLESHEET)

        # Create central widget and layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        # Header row with title on left, button on right
        header_row = QWidget()
        header_row_layout = QHBoxLayout(header_row)
        header_row_layout.setContentsMargins(0, 0, 0, 8)
        header_row_layout.setSpacing(12)

        # Title and subtitle on the left
        title_section = QWidget()
        title_layout = QVBoxLayout(title_section)
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_layout.setSpacing(4)

        title = QLabel("📝 Jarvis Logs")
        title.setObjectName("title")
        title.setStyleSheet("font-size: 20px; font-weight: 600; color: #fbbf24;")
        title_layout.addWidget(title)

        subtitle = QLabel("Activity timeline · downloads stay visible above the log")
        subtitle.setObjectName("subtitle")
        title_layout.addWidget(subtitle)

        header_row_layout.addWidget(title_section)
        header_row_layout.addStretch()

        # Clear button
        clear_btn = QPushButton("🗑️ Clear")
        clear_btn.setToolTip("Clear all logs")
        clear_btn.setStyleSheet("""
            QPushButton {
                background-color: #27272a;
                color: #fafafa;
                border: 1px solid #3f3f46;
                border-radius: 6px;
                padding: 8px 16px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #3f3f46;
                border-color: #f59e0b;
            }
        """)
        clear_btn.clicked.connect(self.clear_logs)
        header_row_layout.addWidget(clear_btn)

        # Report button on the right
        report_btn = QPushButton("🐛 Report Issue")
        report_btn.setToolTip("Report a bug or unexpected behavior on GitHub")
        report_btn.setStyleSheet("""
            QPushButton {
                background-color: #27272a;
                color: #fafafa;
                border: 1px solid #3f3f46;
                border-radius: 6px;
                padding: 8px 16px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #3f3f46;
                border-color: #f59e0b;
            }
        """)
        report_btn.clicked.connect(self._report_issue)
        header_row_layout.addWidget(report_btn)

        layout.addWidget(header_row)

        self.download_card = QWidget()
        self.download_card.setObjectName("download_card")
        download_layout = QVBoxLayout(self.download_card)
        download_layout.setContentsMargins(20, 16, 20, 16)
        self.download_title = QLabel()
        self.download_title.setObjectName("section_title")
        self.download_title.setTextFormat(Qt.TextFormat.PlainText)
        self.download_title.setWordWrap(True)
        self.download_detail = QLabel()
        self.download_detail.setTextFormat(Qt.TextFormat.PlainText)
        self.download_detail.setWordWrap(True)
        self.download_bar = QProgressBar()
        download_layout.addWidget(self.download_title)
        download_layout.addWidget(self.download_bar)
        download_layout.addWidget(self.download_detail)
        layout.addWidget(self.download_card)
        self.download_card.hide()
        self._downloads = {}
        self._download_times = {}
        self._last_progress_at = 0.0
        self._progress_detail = ""
        self._progress_timer = QTimer(self)
        self._progress_timer.setInterval(1000)
        self._progress_timer.timeout.connect(self._refresh_download_status)

        # Create text display for logs with monospace font
        self.log_display = QTextEdit()
        self.log_display.setReadOnly(True)
        mono_font = QFont("JetBrains Mono", 11) if sys.platform == "darwin" else QFont("Consolas", 10)
        mono_font.setStyleHint(QFont.StyleHint.Monospace)
        self.log_display.setFont(mono_font)
        layout.addWidget(self.log_display)

        # Initial message
        self.append_log("📝 Activity log ready\n")

    def append_log(self, text: str) -> None:
        """Keep transfer updates in a card and important events in the timeline."""
        for line in clean_log(text).replace('\r', '\n').splitlines():
            if not line.strip():
                continue
            progress = parse_progress(line)
            if progress:
                previous = self._downloads.get(progress.name)
                self._downloads[progress.name] = progress
                self._download_times[progress.name] = time.monotonic()
                if progress.percent == 100:
                    if previous is None or previous.percent != 100:
                        self._append_event(f"✅ Downloaded {progress.name} · {progress.detail}")
                    # A small metadata file can finish while model weights are
                    # still transferring on another Hub worker.
                    progress = next((p for p in self._downloads.values() if p.percent != 100), progress)
                elif previous is None or previous.percent == 100:
                    self._append_event(f"📥 Downloading {progress.name}")
                self.download_card.show()
                self.download_title.setText(f"📥 {progress.name}")
                self.download_bar.setFormat('%p%')
                self.download_bar.setRange(0, 0 if progress.percent is None else 100)
                if progress.percent is not None:
                    self.download_bar.setValue(progress.percent)
                self._progress_detail = progress.detail
                self.download_detail.setText(progress.detail)
                self._last_progress_at = self._download_times[progress.name]
                if progress.percent != 100:
                    self._progress_timer.start()
                else:
                    self._progress_timer.stop()
                    self.download_card.hide()
                continue
            if line.startswith('📥 Checking Whisper model files'):
                self._downloads.clear()
                self._download_times.clear()
                self.download_card.show()
                self.download_title.setText('📥 Preparing Whisper model files')
                self.download_bar.setRange(0, 0)
                self.download_bar.setFormat('%p%')
                self._progress_detail = 'Checking the local cache and model server'
                self.download_detail.setText(self._progress_detail)
                self._last_progress_at = time.monotonic()
                self._progress_timer.start()
            elif line.startswith('🎤 Loading Whisper into memory'):
                self._progress_timer.stop()
                self.download_card.show()
                self.download_title.setText('🎤 Preparing speech recognition')
                self.download_bar.setFormat('%p%')
                self.download_bar.setRange(0, 0)
                self._progress_detail = 'Model files ready · loading into memory and warming up'
                self.download_detail.setText(self._progress_detail)
            elif ('MLX Whisper' in line and 'ready (Apple Silicon GPU)' in line
                  or line.strip() == '🎙️  Listening! Try:'):
                self._progress_timer.stop()
                self.download_card.hide()
            if any(message in line for message in (
                'Download failed', 'Download error', 'Failed to initialise MLX Whisper',
                'Daemon exited unexpectedly', 'Daemon stopped',
            )):
                self._progress_timer.stop()
                self._downloads.clear()
                self._download_times.clear()
                if not self.download_card.isHidden():
                    self.download_bar.setRange(0, 100)
                    self.download_bar.setFormat('Interrupted')
                    self.download_detail.setText(self._progress_detail + " · See details below")
            self._append_event(line)

    def _append_event(self, line):
        cursor = self.log_display.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        style = QTextCharFormat()
        style.setForeground(QColor(COLORS['text_muted']))
        cursor.insertText(time.strftime('%H:%M:%S') + '  ', style)
        colour = 'text_primary'
        if '❌' in line or 'Traceback' in line:
            colour = 'error_light'
        elif '⚠' in line:
            colour = 'warning_light'
        elif line.lstrip().startswith(('✓', '✅')):
            colour = 'success_light'
        style.setForeground(QColor(COLORS[colour]))
        cursor.insertText(line + '\n', style)
        self.log_display.setTextCursor(cursor)
        self.log_display.ensureCursorVisible()

    def _refresh_download_status(self):
        elapsed = int(time.monotonic() - self._last_progress_at)
        if elapsed >= 15:
            self.download_detail.setText(
                self._progress_detail + f" · No new progress for {elapsed}s; waiting for the download server"
            )

    def clear_logs(self) -> None:
        """Clear all logs."""
        self.log_display.clear()
        self._downloads.clear()
        self._download_times.clear()
        self._progress_timer.stop()
        self.download_card.hide()
        self.append_log("🗑️ Logs cleared\n")

    def _report_issue(self) -> None:
        """Review a described, redacted report before opening GitHub."""
        import platform
        from jarvis import get_version
        from jarvis.config import load_settings
        from jarvis.utils.redact import scrub_secrets
        from desktop_app.issue_report import IssueReportDialog

        try:
            version = get_version()
        except Exception:
            version = ('unknown', 'unknown')
        metadata = {'Platform': f'{sys.platform} ({platform.release()}, {platform.machine()})'}
        try:
            cfg = load_settings()
            metadata.update({
                'Configured provider': cfg.llm_provider,
                'Configured chat model': cfg.llm_chat_model,
                'Configured Whisper model': cfg.whisper_model,
                'Configured Whisper backend': cfg.whisper_backend,
                'Configured Whisper device': cfg.whisper_device,
            })
        except Exception as exc:
            debug_log(f'Issue report settings unavailable: {type(exc).__name__}', 'desktop')
        log_content = self.log_display.toPlainText()
        if not self.download_card.isHidden():
            percentage = f"{self.download_bar.value()}% · " if self.download_bar.maximum() else ''
            log_content += f"\n{self.download_title.text()}: {percentage}{self.download_detail.text()}\n"
        logs = _truncate_logs_for_report(scrub_secrets(log_content), 5000)
        debug_log('Issue report composer opened for local review', 'desktop')
        dialog = IssueReportDialog(logs, version=version, metadata=metadata, parent=self)
        dialog.exec()


class MemoryViewerWindow(QMainWindow):
    """Open local memory in an embedded view or the system browser."""

    MEMORY_VIEWER_PORT = 5050

    def __init__(self):
        super().__init__()
        self.setWindowTitle("🧠 Jarvis Memory")
        self.setGeometry(150, 150, 1200, 900)

        # Apply theme
        self.setStyleSheet(JARVIS_THEME_STYLESHEET)

        self.server_process: Optional[subprocess.Popen] = None
        self.server_thread: Optional[threading.Thread] = None
        self.is_server_running = False

        # Create central widget and layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)

        # Determine if we should use embedded WebEngine or browser fallback
        # On macOS bundled apps, QtWebEngine crashes due to sandbox/bundling issues
        # so we use the system browser instead. Windows works fine with WebEngine.
        is_macos_bundle = sys.platform == 'darwin' and getattr(sys, 'frozen', False)
        use_webengine = HAS_WEBENGINE and not is_macos_bundle

        self.web_view = None
        if use_webengine:
            try:
                self.web_view = QWebEngineView()
                layout.addWidget(self.web_view)
            except Exception as e:
                debug_log(f"failed to create QWebEngineView: {e}", "desktop")
                self.web_view = None

    def open_viewer(self) -> None:
        """Open the usable viewer surface and focus it when embedded."""
        if self.web_view is None:
            debug_log("opening memory viewer in the system browser", "desktop")
            self._load_viewer()
        else:
            self.show()
            self.raise_()
            self.activateWindow()

    def start_server(self) -> bool:
        """Start the memory viewer Flask server."""
        if self.is_server_running:
            debug_log("memory viewer server already running (skipping start)", "desktop")
            return True

        print("🧠 Starting memory viewer server...", flush=True)

        try:
            # Check if server is already running on the port
            import socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            result = sock.connect_ex(('localhost', self.MEMORY_VIEWER_PORT))
            sock.close()

            if result == 0:
                # Port is already in use, assume server is running
                self.is_server_running = True
                print(f"   ✓ Server already running on port {self.MEMORY_VIEWER_PORT}", flush=True)
                debug_log(f"memory viewer server already running on port {self.MEMORY_VIEWER_PORT}", "desktop")
                return True

            # Check if we're running as a frozen/bundled app
            is_frozen = getattr(sys, 'frozen', False)
            print(f"   → Frozen app: {is_frozen}", flush=True)

            if is_frozen:
                # Bundled app: run Flask server in a thread
                try:
                    from desktop_app.memory_viewer import app as flask_app
                except Exception as import_err:
                    debug_log(f"failed to import memory_viewer: {import_err}", "desktop")
                    return False

                def run_flask_server():
                    try:
                        # Suppress Werkzeug's development server warning in bundled apps
                        import logging
                        logging.getLogger('werkzeug').setLevel(logging.ERROR)

                        # Disable Flask's reloader and debug mode
                        flask_app.run(
                            host="127.0.0.1",
                            port=self.MEMORY_VIEWER_PORT,
                            debug=False,
                            use_reloader=False,
                            threaded=True
                        )
                    except Exception as server_err:
                        debug_log(f"memory viewer server error: {server_err}", "desktop")

                self.server_thread = threading.Thread(target=run_flask_server, daemon=True)
                self.server_thread.start()
                debug_log("memory viewer server started in thread (bundled mode)", "desktop")

                # For bundled mode, use simple wait - Flask thread starts quickly
                # The complex socket polling below is for subprocess mode reliability
                import time
                time.sleep(1)
                self.is_server_running = True
                return True
            else:
                # Development: start server in subprocess
                python_exe = sys.executable

                # Set up environment with PYTHONPATH for source runs
                env = os.environ.copy()
                src_path = Path(__file__).parent.parent  # Go up to src/
                if "PYTHONPATH" in env:
                    env["PYTHONPATH"] = f"{src_path}{os.pathsep}{env['PYTHONPATH']}"
                else:
                    env["PYTHONPATH"] = str(src_path)

                # Ensure UTF-8 encoding for subprocess (Windows cp1252 can't handle emojis)
                env["PYTHONIOENCODING"] = "utf-8"

                # Use creationflags to prevent console window popup on Windows
                creationflags = 0
                if sys.platform == 'win32':
                    creationflags = subprocess.CREATE_NO_WINDOW

                print(f"   -> Python: {python_exe}", flush=True)
                print(f"   -> PYTHONPATH: {env.get('PYTHONPATH', 'not set')}", flush=True)

                self.server_process = subprocess.Popen(
                    [python_exe, "-m", "desktop_app.memory_viewer"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    stdin=subprocess.PIPE,
                    text=True,
                    encoding='utf-8',
                    errors='replace',
                    env=env,
                    creationflags=creationflags,
                )
                print(f"   → Subprocess PID: {self.server_process.pid}", flush=True)
                debug_log("memory viewer server started in subprocess (development mode)", "desktop")

            # Wait for server to actually start (with verification)
            import time
            import socket
            max_wait = 5  # seconds
            start_time = time.time()

            print(f"   → Waiting for server (max {max_wait}s)...", flush=True)

            while time.time() - start_time < max_wait:
                # Check if subprocess died
                if self.server_process and self.server_process.poll() is not None:
                    # Process exited - read any error output
                    print(f"   ✗ Subprocess exited with code {self.server_process.returncode}", flush=True)
                    try:
                        stdout, _ = self.server_process.communicate(timeout=1)
                        if stdout:
                            print(f"   → Output:\n{stdout}", flush=True)
                        debug_log(f"memory viewer subprocess exited: {stdout}", "desktop")
                    except Exception as e:
                        print(f"   → Error reading output: {e}", flush=True)
                    self.server_process = None
                    return False

                # Check if server is listening
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                result = sock.connect_ex(('127.0.0.1', self.MEMORY_VIEWER_PORT))
                sock.close()

                if result == 0:
                    self.is_server_running = True
                    print(f"   ✓ Server running on port {self.MEMORY_VIEWER_PORT}", flush=True)
                    debug_log(f"memory viewer server confirmed running on port {self.MEMORY_VIEWER_PORT}", "desktop")
                    return True

                time.sleep(0.2)

            # Timeout - server didn't start
            print(f"   ✗ Server failed to start within {max_wait}s", flush=True)
            debug_log(f"memory viewer server failed to start within {max_wait}s", "desktop")
            if self.server_process:
                # Try to get any output
                try:
                    poll_result = self.server_process.poll()
                    print(f"   → Process poll result: {poll_result}", flush=True)
                    self.server_process.terminate()
                    stdout, _ = self.server_process.communicate(timeout=2)
                    if stdout:
                        print(f"   → Server output:\n{stdout}", flush=True)
                        debug_log(f"memory viewer subprocess output: {stdout}", "desktop")
                    else:
                        print("   → No output from server process", flush=True)
                except Exception as e:
                    print(f"   → Error getting output: {e}", flush=True)
                self.server_process = None
            return False

        except Exception as e:
            print(f"   ✗ Exception starting server: {e}", flush=True)
            debug_log(f"failed to start memory viewer server: {e}", "desktop")
            return False

    def stop_server(self) -> None:
        """Stop the memory viewer Flask server."""
        if self.server_process:
            try:
                self.server_process.terminate()
                self.server_process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.server_process.kill()
                self.server_process.wait()
            except Exception as e:
                debug_log(f"error stopping memory viewer server: {e}", "desktop")
            finally:
                self.server_process = None
                self.is_server_running = False

        # Thread-based server (bundled mode) will stop when app exits (daemon thread)
        if self.server_thread:
            self.server_thread = None
            self.is_server_running = False

    def _show_viewer_error(self, message: str) -> None:
        """Show useful opening feedback in the selected viewer surface."""
        if self.web_view:
            error_html = f"""
            <html>
            <head><style>
                body {{ background: #18181b; color: #e4e4e7; font-family: system-ui;
                       display: flex; justify-content: center; align-items: center;
                       height: 100vh; margin: 0; }}
                .error {{ text-align: center; padding: 40px; }}
                .icon {{ font-size: 64px; margin-bottom: 20px; }}
                h1 {{ color: #fbbf24; margin-bottom: 16px; }}
                p {{ color: #71717a; max-width: 400px; line-height: 1.6; }}
            </style></head>
            <body><div class="error">
                <div class="icon">⚠️</div>
                <h1>Connection Failed</h1>
                <p>{message}</p>
            </div></body>
            </html>
            """
            self.web_view.setHtml(error_html)
        else:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(None, "🧠 Jarvis Memory", message)

    def showEvent(self, event) -> None:
        """Called when window is shown."""
        super().showEvent(event)

        self._load_viewer()

    def _load_viewer(self) -> None:
        """Start or reuse the local server and open its viewer."""
        url = f"http://localhost:{self.MEMORY_VIEWER_PORT}"
        try:
            # Start server when window opens
            if self.start_server():
                if self.web_view:
                    # Set URL and load (URL is set here, not in __init__, to avoid WebEngine crash)
                    self.web_view.setUrl(QUrl(url))
                else:
                    # Open in system browser as fallback
                    import webbrowser
                    if not webbrowser.open(url):
                        self._show_viewer_error(
                            f"Your browser could not be opened. Open {url} in your browser to view your memory."
                        )
            else:
                # Server failed to start - show error message
                debug_log("memory viewer server failed to start", "desktop")
                self._show_viewer_error(
                    "The memory viewer server failed to start. "
                    "Check the console output for details."
                )
        except Exception as e:
            debug_log(f"error opening memory viewer: {e}", "desktop")
            self._show_viewer_error(
                f"The memory viewer could not be opened. Try again, or open {url} in your browser."
            )

    def closeEvent(self, event) -> None:
        """Called when window is closed."""
        # Don't stop the server on close - just hide the window
        # Server will be stopped on app quit
        event.accept()


class DaemonThread(KeepAliveWorker):
    """QThread that runs the Jarvis daemon inside the bundled app.

    Inherits ``KeepAliveWorker`` so the object stays referenced in the
    registry until its OS thread has fully finished: ``_on_daemon_finished``
    clears ``tray.daemon_thread`` from a ``finished``-connected slot, and
    dropping that last reference while the thread is still winding down
    would destroy a running QThread and abort the whole app ("Fatal Python
    error: Aborted" — #584/#575/#576, same class as #509/#407/#239).
    """

    def __init__(self, log_signals):
        super().__init__()
        self.log_signals = log_signals

    def run(self):
        """Run the daemon in this QThread."""
        import sys as sys_module
        old_stdout = sys_module.stdout
        old_stderr = sys_module.stderr

        try:
            # Redirect stdout/stderr to capture logs
            log_writer = LogStream(self.log_signals.dispatch_output)
            sys_module.stdout = log_writer
            sys_module.stderr = log_writer

            try:
                # Import and run the daemon
                from jarvis.daemon import main as daemon_main
                self.log_signals.new_log.emit("🚀 Jarvis daemon started\n")
                self.log_signals.new_log.emit("📋 Initializing daemon components...\n")

                # Run daemon - this should run the main loop
                daemon_main()

                from jarvis.daemon import is_stop_requested
                if is_stop_requested():
                    self.log_signals.new_log.emit("✅ Daemon stopped gracefully\n")
                else:
                    self.log_signals.new_log.emit("⚠️ Daemon exited unexpectedly\n")
            except KeyboardInterrupt:
                self.log_signals.new_log.emit("⏸️ Daemon interrupted\n")
            except Exception as e:
                error_msg = f"❌ Daemon runtime error: {str(e)}\n{traceback.format_exc()}\n"
                self.log_signals.new_log.emit(error_msg)
                # Also try to log via debug_log (though it might not work)
                try:
                    debug_log(f"daemon thread error: {e}", "desktop")
                except Exception:
                    pass
            finally:
                sys_module.stdout = old_stdout
                sys_module.stderr = old_stderr
        except Exception as e:
            # Outer exception handler for setup errors
            error_msg = f"❌ Daemon setup error: {str(e)}\n{traceback.format_exc()}\n"
            try:
                self.log_signals.new_log.emit(error_msg)
            except Exception:
                # If we can't emit, at least try stdout
                print(error_msg, file=old_stderr)


class JarvisSystemTray:
    """System tray application for Jarvis voice assistant."""

    def __init__(
        self,
        *,
        ollama_runtime_ownership: Optional[OllamaRuntimeOwnership] = None,
    ):
        # Use existing QApplication if available, otherwise create one
        self.app = QApplication.instance()
        if self.app is None:
            self.app = QApplication(sys.argv)
        self.app.setQuitOnLastWindowClosed(False)

        # Initialize state
        self.daemon_process: Optional[subprocess.Popen] = None
        self.daemon_thread: Optional[QThread] = None
        self.is_listening = False
        self.is_bundled = getattr(sys, 'frozen', False)
        self._ollama_runtime_ownership = (
            ollama_runtime_ownership or OllamaRuntimeOwnership()
        )

        # Kill any orphaned Jarvis processes from previous sessions
        self.cleanup_orphaned_processes()

        # Create log viewer window (hidden by default)
        self.log_viewer = LogViewerWindow()
        self.log_signals = LogSignals()
        self.log_signals.new_log.connect(self.log_viewer.append_log)
        self.log_signals.voice_status.connect(self._on_voice_pause_status)

        from desktop_app.task_centre import TaskCentreWindow
        self.task_centre = TaskCentreWindow(
            submit_callback=self.submit_task,
            cancel_callback=self.cancel_task,
        )
        self.log_signals.task_event.connect(self.task_centre.process_log_line)

        # Create memory viewer window (hidden by default)
        self.memory_viewer = MemoryViewerWindow()

        # Create face window (hidden by default)
        # Note: Creating the face window also initializes the SpeakingState singleton
        # in the main thread, which is important for cross-thread signal delivery
        self.face_window = FaceWindow()

        # Create dictation history window (hidden by default)
        from desktop_app.dictation_history import DictationHistoryWindow
        from jarvis.dictation.history import DictationHistory
        self._dictation_history = DictationHistory()
        self.dictation_history_window = DictationHistoryWindow(history=self._dictation_history)

        # Chat window is created lazily on first open (see show_chat). Kept
        # alive for the session once created, same lifecycle as the dictation
        # history window. ``self._chat_submit_fn`` is set when the daemon
        # starts so the window can route queries in subprocess mode.
        self.chat_window = None
        self._chat_submit_fn = None
        self._chat_control_fn = None
        self._daemon_stop_expected = False
        self._daemon_stuck = False

        # Main-thread signal bridge for chat IPC. The log reader thread emits
        # ``line_received`` (a queued connection) so the chat window is created
        # and the IPC line is parsed on the Qt main thread, never on the
        # worker thread (Qt widgets must be created on the GUI thread).
        from desktop_app.chat_window import ChatIpcSignals
        self._chat_ipc_signals = ChatIpcSignals()
        self._chat_ipc_signals.line_received.connect(self._on_chat_ipc_line)

        # Same bridge for the runtime-status dialog: the snapshot is
        # gathered on a worker thread because it makes a blocking network
        # call, and only the rendering belongs on the GUI thread.
        self._runtime_status_signals = RuntimeStatusSignals()
        self._runtime_status_signals.ready.connect(self._show_runtime_status_dialog)

        # Log reader threads
        self.log_reader_threads = []

        # Create system tray icon
        from desktop_app.macos_tray import install_macos_tray_event_guard
        install_macos_tray_event_guard()
        self.tray_icon = QSystemTrayIcon()
        self.update_icon()

        # Create context menu
        self.create_menu()
        self.face_window.set_tray_menu(self.menu)

        # Set up status checking timer
        self.status_timer = QTimer()
        self.status_timer.timeout.connect(self.check_daemon_status)
        self.status_timer.start(2000)  # Check every 2 seconds

        # Show tray icon
        self.tray_icon.show()

        # Register cleanup on app exit
        self.app.aboutToQuit.connect(self.cleanup_on_exit)

        # Check for updates on startup (delayed by 5 seconds to not block app startup)
        QTimer.singleShot(5000, self.check_for_updates)

        debug_log("desktop app initialized", "desktop")

    def cleanup_orphaned_processes(self) -> None:
        """Kill any orphaned Jarvis daemon processes from previous sessions."""
        try:
            current_pid = os.getpid()
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    cmdline = proc.info.get('cmdline', [])
                    if cmdline and 'jarvis.main' in ' '.join(cmdline):
                        # This is a Jarvis daemon process
                        if proc.pid != current_pid:
                            debug_log(f"killing orphaned jarvis process: {proc.pid}", "desktop")
                            proc.terminate()
                            try:
                                proc.wait(timeout=2)
                            except psutil.TimeoutExpired:
                                proc.kill()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception as e:
            debug_log(f"error cleaning up orphaned processes: {e}", "desktop")

    def cleanup_on_exit(self) -> None:
        """Cleanup when app is exiting."""
        debug_log("cleaning up on exit", "desktop")
        if self.is_listening:
            self.stop_daemon()
        # Stop memory viewer server
        if hasattr(self, 'memory_viewer'):
            self.memory_viewer.stop_server()
        # Safety net: if daemon process exists but is_listening was False, still clean up
        # (This shouldn't happen in normal operation, but handles edge cases)
        if self.daemon_process:
            try:
                self.daemon_process.terminate()
                try:
                    # Use longer timeout to allow diary update to complete
                    self.daemon_process.wait(timeout=60)
                except subprocess.TimeoutExpired:
                    self.daemon_process.kill()
                    self.daemon_process.wait()
            except Exception as e:
                debug_log(f"error during exit cleanup: {e}", "desktop")
        _stop_owned_ollama_runtime(self._ollama_runtime_ownership)

    def create_menu(self) -> None:
        """Create the system tray context menu."""
        self.menu = QMenu()

        # View logs action
        self.logs_action = QAction("📝 View Logs")
        self.logs_action.triggered.connect(self.show_log_viewer)
        self.menu.addAction(self.logs_action)

        # Task centre action
        self.tasks_action = QAction("🧭 Task Centre")
        self.tasks_action.triggered.connect(self.show_task_centre)
        self.menu.addAction(self.tasks_action)

        # Memory viewer action
        self.memory_action = QAction("🧠 Memory Viewer")
        self.memory_action.triggered.connect(self.show_memory_viewer)
        self.menu.addAction(self.memory_action)

        # Dictation history action
        self.dictation_history_action = QAction("🎙️ Dictation History")
        self.dictation_history_action.triggered.connect(self.show_dictation_history)
        self.menu.addAction(self.dictation_history_action)

        # Chat window action
        self.chat_action = QAction("💬 Chat")
        self.chat_action.triggered.connect(self.show_chat)
        self.menu.addAction(self.chat_action)

        # Face window action
        self.face_action = QAction("👤 Show Face")
        self.face_action.triggered.connect(self.show_face_window)
        self.menu.addAction(self.face_action)

        # Setup wizard action
        self.setup_wizard_action = QAction("🔧 Setup Wizard")
        self.setup_wizard_action.triggered.connect(self.show_setup_wizard)
        self.menu.addAction(self.setup_wizard_action)

        # Settings action
        self.settings_action = QAction("⚙️ Settings")
        self.settings_action.triggered.connect(self.show_settings)
        self.menu.addAction(self.settings_action)

        # Runtime diagnostics action
        self.runtime_status_action = QAction("🩺 Runtime Status")
        self.runtime_status_action.triggered.connect(self.show_runtime_status)
        self.menu.addAction(self.runtime_status_action)

        # Check for updates action
        self.check_updates_action = QAction("🔄 Check for Updates")
        self.check_updates_action.triggered.connect(lambda: self.check_for_updates(show_no_update_dialog=True))
        self.menu.addAction(self.check_updates_action)

        # Reinstall GPU libraries (Windows + NVIDIA only). Only added when
        # the bundled install script is present and an NVIDIA driver was
        # detected; otherwise the action would be a dead button.
        self._maybe_add_cuda_recovery_action()

        self.menu.addSeparator()

        # Open directories actions
        self.open_config_action = QAction("📁 Open Config Directory")
        self.open_config_action.triggered.connect(self.open_config_directory)
        self.menu.addAction(self.open_config_action)

        self.open_data_action = QAction("💾 Open Data Directory")
        self.open_data_action.triggered.connect(self.open_data_directory)
        self.menu.addAction(self.open_data_action)

        self.menu.addSeparator()

        # Assistant power action
        self.toggle_action = QAction("▶️ Turn On")
        self.toggle_action.triggered.connect(self.toggle_listening)
        self.menu.addAction(self.toggle_action)

        self._initialise_voice_pause_controls()
        self.menu.addAction(self.voice_pause_action)

        # Status action (non-clickable)
        self.status_action = QAction("⚪ Status: Stopped")
        self.status_action.setEnabled(False)
        self.menu.addAction(self.status_action)

        self.menu.addSeparator()

        # Quit action
        self.quit_action = QAction("🚪 Quit")
        self.quit_action.triggered.connect(self.quit_app)
        self.menu.addAction(self.quit_action)

        apply_theme(self.menu)
        self.tray_icon.setContextMenu(self.menu)

    def _maybe_add_cuda_recovery_action(self) -> None:
        """Add the GPU-libraries reinstall action to the tray menu, when applicable."""
        try:
            from desktop_app.cuda_recovery import cuda_recovery_action
        except Exception as e:
            debug_log(f"cuda recovery import failed: {e}", "desktop")
            return

        # In bundled mode the script lives next to the executable; in dev
        # runs it lives at installer/windows/install_cuda.ps1.
        if getattr(sys, "frozen", False):
            install_root = Path(sys.executable).parent
        else:
            install_root = Path(__file__).resolve().parents[2] / "installer" / "windows"

        action_spec = cuda_recovery_action(install_root=install_root)
        if action_spec is None:
            return

        self.cuda_recovery_action = QAction(action_spec.label)
        self.cuda_recovery_action.triggered.connect(
            lambda: self._run_cuda_recovery(action_spec)
        )
        self.menu.addAction(self.cuda_recovery_action)

    def _run_cuda_recovery(self, action_spec: "CudaRecoveryAction") -> None:
        """Confirm with the user, then launch the recovery script with UAC."""
        from desktop_app.cuda_recovery import run_action
        from PyQt6.QtWidgets import QMessageBox

        reply = QMessageBox.question(
            None,
            "Reinstall GPU libraries",
            (
                "This will download cuBLAS and cuDNN (~1.1 GB) and install them "
                "into the Jarvis program folder. You'll see a UAC prompt. "
                "Continue?"
            ),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        ok = run_action(action_spec)
        if not ok:
            QMessageBox.warning(
                None,
                "Reinstall GPU libraries",
                (
                    "Could not launch the installer. If you dismissed the UAC "
                    f"prompt, try again. See the log at\n{action_spec.target_dir / 'install.log'}"
                ),
            )
            return

        QMessageBox.information(
            None,
            "Reinstall GPU libraries",
            (
                "The CUDA installer is running. Once it finishes, restart "
                f"Jarvis to use GPU acceleration. See {action_spec.target_dir / 'install.log'} "
                "for details."
            ),
        )

    def show_setup_wizard(self) -> None:
        """Show the setup wizard window."""
        from desktop_app.setup_wizard import SetupWizard
        from PyQt6.QtWidgets import QWizard

        # Remember if daemon was running before wizard
        was_listening = self.is_listening

        # Stop daemon while setup wizard is open (to allow changes to take effect)
        if was_listening:
            self.stop_daemon()

        # Face should look asleep while wizard is open (daemon isn't running)
        self._set_face_asleep()

        wizard = SetupWizard()
        result = wizard.exec()

        # Restart daemon only when the wizard was completed.
        # Cancelling means the user didn't finalise their setup, so
        # we leave the daemon stopped rather than starting with a
        # potentially incomplete configuration.
        if result == QWizard.DialogCode.Accepted:
            self.start_daemon()

    def show_settings(self) -> None:
        """Show the settings window."""
        from desktop_app.settings_window import SettingsWindow
        from PyQt6.QtWidgets import QMessageBox

        dialog = SettingsWindow()
        result = dialog.exec()

        # If settings were saved and daemon is running, offer to restart
        if result == QDialog.DialogCode.Accepted and self.is_listening:
            reply = QMessageBox.question(
                None, "🔄 Restart?",
                "Settings saved. Restart Jarvis now to apply changes?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes,
            )
            if reply == QMessageBox.StandardButton.Yes:
                self.stop_daemon()
                self.start_daemon()

    def collect_runtime_status(self) -> RuntimeStatusSnapshot:
        """Collect current runtime state for the tray diagnostics dialog."""
        return _collect_runtime_status_snapshot(
            is_listening=self.is_listening,
            is_bundled=self.is_bundled,
            daemon_process=self.daemon_process,
            daemon_thread=self.daemon_thread,
            ollama_runtime_ownership=self._ollama_runtime_ownership,
        )

    def show_runtime_status(self) -> None:
        """Show a compact diagnostic summary of Jarvis' active runtime.

        The snapshot is collected on a worker thread and delivered back
        through a signal, the same marshalling this app already uses for
        chat events. Collecting it inline would run ``check_ollama_server``
        — a blocking request with a five second timeout — on the Qt main
        thread, freezing every menu in the app at precisely the moment the
        user reached for diagnostics because something looked wrong.
        """
        import threading

        def _collect():
            try:
                snapshot = self.collect_runtime_status()
            except Exception as exc:
                debug_log(f"runtime status collection failed: {exc}", "desktop")
                return
            self._runtime_status_signals.ready.emit(snapshot)

        threading.Thread(
            target=_collect, name="runtime-status", daemon=True,
        ).start()

    def _show_runtime_status_dialog(self, snapshot) -> None:
        """Render the collected snapshot. Runs on the Qt main thread."""
        RuntimeStatusDialog(snapshot).exec()

    def check_for_updates(self, show_no_update_dialog: bool = False) -> None:
        """Check for available updates.

        Args:
            show_no_update_dialog: If True, shows a dialog even when no update is available.
        """
        from desktop_app.updater import check_for_updates, is_frozen
        from desktop_app.update_dialog import (
            UpdateAvailableDialog,
            UpdateProgressDialog,
            show_no_update_dialog as show_no_update,
            show_update_error_dialog,
        )

        # Only check for updates if running as bundled app
        if not is_frozen():
            if show_no_update_dialog:
                from PyQt6.QtWidgets import QMessageBox
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Icon.Information)
                msg.setWindowTitle("Updates")
                msg.setText("Auto-update is only available in the bundled desktop app.")
                msg.setInformativeText("You're running from source. Use git pull to update.")
                msg.setStyleSheet(JARVIS_THEME_STYLESHEET)
                msg.exec()
            return

        try:
            status = check_for_updates()

            if status.error:
                debug_log(f"Update check failed: {status.error}", "desktop")
                if show_no_update_dialog:
                    show_update_error_dialog(status.error)
                return

            if status.update_available and status.latest_release:
                # Show update available dialog
                dialog = UpdateAvailableDialog(status)
                if dialog.exec() == QDialog.DialogCode.Accepted:
                    # User chose to update - create callback to save diary before install
                    def save_session_before_update():
                        """Stop daemon and save diary before update installation."""
                        if self.is_listening:
                            debug_log("Saving session before update...", "updater")
                            self.stop_daemon(show_diary_dialog=True)

                    progress_dialog = UpdateProgressDialog(
                        status.latest_release,
                        pre_install_callback=save_session_before_update,
                    )
                    progress_dialog.show()
                    progress_dialog.start_download()

                    result = progress_dialog.exec()
                    if result == QDialog.DialogCode.Accepted:
                        # Update successful, exit app (diary already saved via pre_install_callback)
                        self.quit_app(skip_diary=True)
            elif show_no_update_dialog:
                show_no_update(status.current_version)

        except Exception as e:
            debug_log(f"Update check error: {e}", "desktop")
            if show_no_update_dialog:
                show_update_error_dialog(str(e))

    def show_launch_windows(self) -> None:
        """Open the log viewer and face window once at app launch.

        Starting or stopping the assistant never changes window visibility
        (start_daemon/stop_daemon leave it untouched), so the
        launch windows are opened here explicitly instead of inside
        start_daemon.
        """
        self.log_viewer.show()
        self.log_viewer.raise_()
        self.log_viewer.activateWindow()
        self.face_window.show()
        self.face_window.raise_()

    def show_log_viewer(self) -> None:
        """Show the log viewer window and bring it to front."""
        self.log_viewer.show()
        self.log_viewer.raise_()
        self.log_viewer.activateWindow()

    def show_task_centre(self) -> None:
        """Show the interactive task centre."""
        self.task_centre.show()
        self.task_centre.raise_()
        self.task_centre.activateWindow()

    def submit_task(self, prompt: str, *, request_id: str):
        """Submit a prompt to the in-process or subprocess daemon."""
        if self.is_bundled:
            from jarvis.daemon import submit_task
            return submit_task(prompt)
        if self.daemon_process is None or self.daemon_process.stdin is None:
            raise RuntimeError("Start Jarvis before submitting a task")
        import json
        self.daemon_process.stdin.write(
            f"TASK:{json.dumps({'action': 'submit', 'prompt': prompt, 'request_id': request_id}, ensure_ascii=False)}\n"
        )
        self.daemon_process.stdin.flush()
        return None

    def cancel_task(self, task_id: str):
        """Cancel a prompt in the in-process or subprocess daemon."""
        if self.is_bundled:
            from jarvis.daemon import cancel_task
            return cancel_task(task_id)
        if self.daemon_process is None or self.daemon_process.stdin is None:
            raise RuntimeError("Start Jarvis before cancelling a task")
        import json
        self.daemon_process.stdin.write(
            f"TASK:{json.dumps({'action': 'cancel', 'id': task_id})}\n"
        )
        self.daemon_process.stdin.flush()
        return True

    def show_memory_viewer(self) -> None:
        """Open memory in the embedded viewer or system browser."""
        self.memory_viewer.open_viewer()

    def show_dictation_history(self) -> None:
        """Show the dictation history window and bring it to front."""
        self.dictation_history_window.show()
        self.dictation_history_window.raise_()
        self.dictation_history_window.activateWindow()

    def show_chat(self) -> None:
        """Show the text chat window (created lazily on first open)."""
        if self.chat_window is None:
            from desktop_app.chat_window import ChatWindow
            self.chat_window = ChatWindow(
                submit_fn=self._chat_submit_fn,
                daemon_available=self.is_listening,
                cancel_fn=getattr(self, "_chat_cancel_fn", None),
                control_fn=getattr(self, "_chat_control_fn", None),
            )
        else:
            self.chat_window._submit_fn = self._chat_submit_fn
            self.chat_window._cancel_fn = getattr(self, "_chat_cancel_fn", None)
            self.chat_window._control_fn = getattr(self, "_chat_control_fn", None)
            self.chat_window.set_daemon_status(
                "running" if self.is_listening else "stopped"
            )
        self.chat_window.show()
        self.chat_window.raise_()
        self.chat_window.activateWindow()

    def _set_chat_daemon_available(self, available: bool) -> None:
        """Update an existing chat window when the daemon starts or stops."""
        self._set_chat_daemon_status("running" if available else "stopped")

    def _set_chat_daemon_status(self, status: str) -> None:
        """Update an existing chat window with daemon lifecycle state."""
        if self.chat_window is None:
            return
        self.chat_window._submit_fn = self._chat_submit_fn
        self.chat_window._control_fn = getattr(self, "_chat_control_fn", None)
        self.chat_window.set_daemon_status(status)

    def _connect_dictation_history(self, retries_left: int = 3) -> None:
        """Wire dictation engine's result callback to the history window signal.

        Called once after daemon startup so live entries appear immediately.
        Retries up to *retries_left* times (5 s apart) if the engine isn't ready.
        """
        try:
            from jarvis.daemon import get_dictation_engine
            engine = get_dictation_engine()
            if engine is None:
                if retries_left > 0:
                    QTimer.singleShot(
                        5000,
                        lambda: self._connect_dictation_history(retries_left - 1),
                    )
                else:
                    debug_log("dictation engine never became available", "desktop")
                return
            # Share the same DictationHistory instance
            engine.history = self._dictation_history
            # Route new-entry notifications through the Qt signal
            engine.set_on_dictation_result(
                lambda entry: self.dictation_history_window.signals.new_entry.emit(entry)
            )
            debug_log("dictation history connected to UI", "desktop")
        except Exception as e:
            debug_log(f"failed to connect dictation history: {e}", "desktop")

    def show_face_window(self) -> None:
        """Show the face window and bring it to front."""
        self.face_window.show()
        self.face_window.raise_()

    def open_directory(self, directory_path: Path, directory_name: str) -> None:
        """Open a directory in the system file manager."""
        try:
            # Ensure directory exists
            directory_path.mkdir(parents=True, exist_ok=True)

            # Open directory based on platform
            if sys.platform == "darwin":  # macOS
                subprocess.Popen(["open", str(directory_path)])
            elif sys.platform == "win32":  # Windows
                os.startfile(str(directory_path))
            else:  # Linux and other Unix-like systems
                subprocess.Popen(["xdg-open", str(directory_path)])

            debug_log(f"opened {directory_name} directory: {directory_path}", "desktop")
            self.log_signals.new_log.emit(f"📂 Opened {directory_name} directory\n")
        except Exception as e:
            debug_log(f"failed to open {directory_name} directory: {e}", "desktop")
            self.log_signals.new_log.emit(f"❌ Failed to open {directory_name} directory: {str(e)}\n")
            self.tray_icon.showMessage(
                f"Error Opening {directory_name} Directory",
                f"Failed to open directory: {str(e)}",
                QSystemTrayIcon.MessageIcon.Warning,
                3000
            )

    def open_config_directory(self) -> None:
        """Open the configuration directory in the system file manager."""
        config_path = get_config_path()
        config_dir = config_path.parent
        self.open_directory(config_dir, "Config")

    def open_data_directory(self) -> None:
        """Open the data directory (where database is stored) in the system file manager."""
        db_path = Path(_default_db_path())
        data_dir = db_path.parent
        self.open_directory(data_dir, "Data")

    def get_icon_path(self, icon_name: str) -> Path:
        """Get the path to an icon file."""
        # Try to find icons in the package directory
        package_dir = Path(__file__).parent
        icons_dir = package_dir / "desktop_assets"
        icon_path = icons_dir / icon_name

        if icon_path.exists():
            return icon_path

        # Fallback: return a simple colored icon
        return icon_path

    def update_icon(self) -> None:
        """Update the tray icon based on current state."""
        if self.is_listening:
            icon_name = "icon_listening.png"
        else:
            icon_name = "icon_idle.png"

        icon_path = self.get_icon_path(icon_name)

        # If icon file doesn't exist, use a default from system
        if icon_path.exists():
            icon = QIcon(str(icon_path))
        else:
            # Use a simple text-based icon as fallback
            from PyQt6.QtGui import QPixmap, QPainter, QColor, QFont
            pixmap = QPixmap(64, 64)
            pixmap.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pixmap)

            # Draw a circle
            color = QColor("#4CAF50" if self.is_listening else "#9E9E9E")
            painter.setBrush(color)
            painter.setPen(color)
            painter.drawEllipse(4, 4, 56, 56)

            # Draw letter J
            painter.setPen(Qt.GlobalColor.white)
            font = QFont("Arial", 32, QFont.Weight.Bold)
            painter.setFont(font)
            painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "J")

            painter.end()
            icon = QIcon(pixmap)

        self.tray_icon.setIcon(icon)

    def _set_face_asleep(self) -> None:
        """Reset the face to asleep so it doesn't look ready while the daemon is down."""
        try:
            from jarvis.activity import JarvisState, get_jarvis_state
            get_jarvis_state().set_state(JarvisState.ASLEEP)
        except Exception:
            pass

    def _initialise_voice_pause_controls(self) -> None:
        self._voice_pause_state = False
        self._voice_pause_request_id = None
        self._voice_pause_owner = None
        self._voice_pause_timer = QTimer()
        self._voice_pause_timer.setSingleShot(True)
        self._voice_pause_timer.setInterval(10000)
        self._voice_pause_timer.timeout.connect(self._voice_pause_timed_out)
        self.voice_pause_action = QAction("⏸️ Pause Voice Listening")
        self.voice_pause_action.setToolTip("Keep text chat and dictation available while voice listening is paused")
        self.voice_pause_action.setEnabled(False)
        self.voice_pause_action.triggered.connect(self.toggle_voice_pause)

    def _sync_voice_pause_controls(self) -> None:
        owner = self.daemon_thread if self.is_bundled else self.daemon_process
        active = self.is_listening and not self._daemon_stop_expected and owner is not None
        if not active or owner is not self._voice_pause_owner:
            self._voice_pause_timer.stop()
            self._voice_pause_request_id = None
            self._voice_pause_state = False
            self._voice_pause_owner = owner if active else None
            self.voice_pause_action.setText("⏸️ Pause Voice Listening")
            if active:
                self.status_action.setText("🟢 Status: Listening")
            elif not self.is_listening:
                self.status_action.setText("⚪ Status: Stopped")
        self.voice_pause_action.setEnabled(active and self._voice_pause_request_id is None)

    def toggle_voice_pause(self) -> None:
        import json
        import uuid
        from jarvis.daemon import VOICE_PAUSE_IPC_PREFIX, set_voice_listening_paused
        self._sync_voice_pause_controls()
        if not self.voice_pause_action.isEnabled():
            return
        paused = not self._voice_pause_state
        request_id = str(uuid.uuid4())
        self._voice_pause_request_id = request_id
        self.voice_pause_action.setEnabled(False)
        self.voice_pause_action.setText("⏳ Pausing Voice Listening…" if paused else "⏳ Resuming Voice Listening…")
        self._voice_pause_timer.start()
        debug_log(f"requesting voice pause: {paused}", "desktop")
        try:
            if self.is_bundled:
                result = set_voice_listening_paused(paused)
                self._apply_voice_pause_status({
                    'request_id': request_id, 'available': result is not None, 'paused': result,
                })
            else:
                self.daemon_process.stdin.write(VOICE_PAUSE_IPC_PREFIX + json.dumps({
                    'paused': paused, 'request_id': request_id,
                }) + '\n')
                self.daemon_process.stdin.flush()
        except Exception as exc:
            debug_log(f"voice pause control failed ({type(exc).__name__})", "desktop")
            self._voice_pause_unknown("Voice listening could not confirm the change. Try again or restart Jarvis.")

    def _on_voice_pause_status(self, owner, line: str) -> None:
        import json
        from jarvis.daemon import VOICE_STATUS_IPC_PREFIX
        if (self.is_bundled or owner is not self.daemon_process
                or not self.is_listening or self._daemon_stop_expected):
            return
        try:
            if not line.startswith(VOICE_STATUS_IPC_PREFIX):
                return
            payload = json.loads(line[len(VOICE_STATUS_IPC_PREFIX):])
            if not isinstance(payload, dict) or payload.get('type') != 'status':
                return
            self._apply_voice_pause_status(payload.get('data'))
        except (ValueError, TypeError):
            debug_log("invalid voice pause acknowledgement", "desktop")

    def _apply_voice_pause_status(self, status) -> None:
        if (not isinstance(status, dict) or self._voice_pause_request_id is None
                or status.get('request_id') != self._voice_pause_request_id
                or not isinstance(status.get('available'), bool)):
            return
        if not status['available']:
            self._voice_pause_unknown("Voice listening is unavailable. Try again after startup or restart Jarvis.")
            return
        if not isinstance(status.get('paused'), bool):
            return
        self._voice_pause_timer.stop()
        self._voice_pause_request_id = None
        self._voice_pause_state = status['paused']
        self.voice_pause_action.setText("▶️ Resume Voice Listening" if status['paused'] else "⏸️ Pause Voice Listening")
        self.voice_pause_action.setEnabled(True)
        self.status_action.setText("🟠 Status: Voice paused (chat available)" if status['paused'] else "🟢 Status: Listening")
        self.tray_icon.setToolTip("Jarvis: voice paused" if status['paused'] else "Jarvis: listening")
        self.log_signals.new_log.emit("⏸️ Voice listening paused. Text chat and dictation remain available.\n"
                                      if status['paused'] else "🎤 Voice listening resumed.\n")
        debug_log(f"voice pause confirmed: {status['paused']}", "desktop")

    def _voice_pause_unknown(self, message: str) -> None:
        self._voice_pause_timer.stop()
        self._voice_pause_request_id = None
        self._voice_pause_state = None
        self.voice_pause_action.setText("⏸️ Pause Voice Listening")
        self.voice_pause_action.setEnabled(self.is_listening and not self._daemon_stop_expected)
        self.status_action.setText("⚠️ Status: Voice state unknown")
        self.tray_icon.setToolTip("Jarvis: voice state unknown")
        self.log_signals.new_log.emit(f"⚠️ {message}\n")

    def _voice_pause_timed_out(self) -> None:
        if self._voice_pause_request_id is not None:
            self._voice_pause_unknown("Voice listening did not confirm the change. Try again or restart Jarvis.")

    def toggle_listening(self) -> None:
        """Toggle the Jarvis daemon on/off."""
        if self.is_listening:
            self.stop_daemon()
        else:
            self.start_daemon()

    def _daemon_alive(self) -> bool:
        """True while a daemon this app started is still running (or stuck stopping)."""
        if self._daemon_stop_expected:
            return True
        thread = getattr(self, "daemon_thread", None)
        if thread is not None and not thread.isFinished():
            return True
        process = getattr(self, "daemon_process", None)
        return process is not None and process.poll() is None

    def start_daemon(self) -> None:
        """Start the Jarvis daemon."""
        # A retained owner or active shutdown blocks replacement.
        if self._daemon_alive():
            if getattr(self, "_daemon_stuck", False):
                self.log_signals.new_log.emit(
                    "⚠️ The previous daemon is still shutting down. Wait for it to finish before starting again.\n"
                )
            else:
                self.log_signals.new_log.emit("ℹ️ Jarvis is already running.\n")
            debug_log("start_daemon ignored: a daemon is still alive", "desktop")
            return
        self._daemon_stuck = False
        self._daemon_stop_expected = False
        self._set_chat_daemon_status("starting")
        try:
            if self.is_bundled:
                # When bundled, run daemon in a QThread since Qt components may be used
                self.daemon_thread = DaemonThread(self.log_signals)
                # Reset UI state on completion. QueuedConnection guarantees the
                # slot runs on the main thread (the finished signal is emitted
                # from the worker's OS thread) and the KeepAliveWorker registry
                # keeps the object alive until that thread has fully exited.
                worker = self.daemon_thread
                self.daemon_thread.finished.connect(
                    lambda: self._on_daemon_finished(worker),
                    Qt.ConnectionType.QueuedConnection,
                )
                self.daemon_thread.start()

                # Connect dictation engine to history window once daemon is ready
                QTimer.singleShot(3000, self._connect_dictation_history)
            else:
                # When not bundled, use subprocess as before
                python_exe = sys.executable

                # Set up environment with PYTHONPATH for source runs
                env = os.environ.copy()
                src_path = Path(__file__).parent.parent  # Go up to src/
                if "PYTHONPATH" in env:
                    env["PYTHONPATH"] = f"{src_path}{os.pathsep}{env['PYTHONPATH']}"
                else:
                    env["PYTHONPATH"] = str(src_path)
                env["JARVIS_TASK_IPC"] = "1"
                # Signal the daemon that we own its stdin (chat query-in IPC)
                # so it starts the stdin monitor. Without this the daemon would
                # treat a non-TTY stdin as "no monitor" on non-Windows, and a
                # stray /dev/null wouldn't kill it.
                env["JARVIS_STDIN_IPC"] = "1"

                # Use creationflags to prevent console window popup on Windows
                # CREATE_NEW_PROCESS_GROUP is needed for CTRL_BREAK_EVENT to work
                creationflags = 0
                if sys.platform == 'win32':
                    creationflags = subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP

                self.daemon_process = subprocess.Popen(
                    [python_exe, "-m", "jarvis.main"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    stdin=subprocess.PIPE,
                    text=True,
                    encoding='utf-8',
                    errors='replace',
                    bufsize=1,
                    env=env,
                    creationflags=creationflags,
                )

                # In subprocess mode the chat window can't call the daemon
                # directly, so it writes a __CHAT_QUERY__: line to stdin.
                # The reply comes back as __CHAT__: events on stdout, parsed
                # in _read_daemon_logs and routed to the chat window's signals.
                from jarvis.daemon import CHAT_CANCEL_IPC_PREFIX, CHAT_QUERY_IPC_PREFIX
                _proc = self.daemon_process

                def _submit_chat_subprocess(text: str) -> None:
                    import json as _json
                    try:
                        _proc.stdin.write(f"{CHAT_QUERY_IPC_PREFIX}{_json.dumps({'text': text})}\n")
                        _proc.stdin.flush()
                    except Exception as exc:
                        # stdin closed / pipe broken (daemon died or is
                        # restarting). Surface a terminal event so the chat
                        # window resets instead of hanging in the thinking
                        # state forever waiting for a reply that won't come.
                        debug_log(f"chat stdin submit failed: {exc}", "desktop")
                        if self.chat_window is not None:
                            self.chat_window.set_daemon_status("crashed")
                            self.chat_window.signals.completed.emit(None)

                def _cancel_chat_subprocess() -> None:
                    """Ask the daemon to drop the query it is running.

                    Same pipe as submission, for the same reason: the
                    query lives in the daemon process, so the flag has to
                    be set there. A broken pipe here is not worth
                    surfacing — the window has already refused the reply
                    locally, and a dead daemon has no query to cancel.
                    """
                    try:
                        _proc.stdin.write(f"{CHAT_CANCEL_IPC_PREFIX}\n")
                        _proc.stdin.flush()
                    except Exception as exc:
                        debug_log(f"chat stdin cancel failed: {exc}", "desktop")

                def _control_chat_subprocess(kind: str, payload: Optional[dict] = None) -> None:
                    """Route a rewind command to the daemon's stdin.

                    ``kind`` is ``rewind``; the matching IPC line carries the
                    payload as prefix+JSON. A broken pipe is not worth
                    surfacing: the window has already updated its own
                    transcript, and a dead daemon has no memory to rewind.
                    """
                    import json as _json
                    from jarvis.daemon import CHAT_REWIND_IPC_PREFIX
                    if kind != "rewind":
                        debug_log(f"unknown chat control command: {kind}", "desktop")
                        return
                    try:
                        _proc.stdin.write(
                            f"{CHAT_REWIND_IPC_PREFIX}{_json.dumps(payload)}\n"
                        )
                        _proc.stdin.flush()
                    except Exception as exc:
                        debug_log(f"chat stdin control failed: {exc}", "desktop")

                self._chat_submit_fn = _submit_chat_subprocess
                self._chat_cancel_fn = _cancel_chat_subprocess
                self._chat_control_fn = _control_chat_subprocess
                # If the chat window already exists (daemon restarted while
                # the window was open), refresh its submit fn so it doesn't
                # keep writing to the old (dead) subprocess stdin.
                if self.chat_window is not None:
                    self.chat_window._submit_fn = self._chat_submit_fn
                    self.chat_window._cancel_fn = self._chat_cancel_fn
                    self.chat_window.set_daemon_status("running")

                # Start log reader thread
                log_thread = threading.Thread(
                    target=self._read_daemon_logs,
                    daemon=True
                )
                log_thread.start()
                self.log_reader_threads.append(log_thread)
                self.log_signals.new_log.emit("🚀 Jarvis daemon started\n")

            self.is_listening = True
            self.toggle_action.setText("⏻ Turn Off")
            self.status_action.setText("🟢 Status: Listening")
            self.update_icon()
            self._set_chat_daemon_status("running")

            self.tray_icon.showMessage(
                "Jarvis Started",
                "Voice assistant is now listening",
                QSystemTrayIcon.MessageIcon.Information,
                2000
            )

            debug_log("daemon started from desktop app", "desktop")

        except Exception as e:
            debug_log(f"failed to start daemon: {e}", "desktop")
            self._chat_submit_fn = None
            self._set_chat_daemon_status("crashed")
            self.log_signals.new_log.emit(f"❌ Failed to start: {str(e)}\n{traceback.format_exc()}\n")
            self.tray_icon.showMessage(
                "Error Starting Jarvis",
                f"Failed to start: {str(e)}",
                QSystemTrayIcon.MessageIcon.Critical,
                3000
            )

    def _on_daemon_finished(self, worker: DaemonThread) -> None:
        """Retire the owning worker without disturbing a replacement runtime."""
        if worker is not self.daemon_thread or not worker.isFinished():
            return
        self.daemon_thread = None
        self._daemon_stuck = False
        # stop_daemon owns the UI transition while it processes Qt events.
        if self._daemon_stop_expected:
            return
        if self.is_listening:
            self.is_listening = False
            self._chat_submit_fn = None
            self.toggle_action.setText("▶️ Turn On")
            self.status_action.setText("⚪ Status: Stopped")
            self.update_icon()
            self._set_chat_daemon_status("crashed")
            self._set_face_asleep()

    def _read_daemon_logs(self) -> None:
        """Read logs from daemon subprocess in a background thread."""
        if not self.daemon_process or not self.daemon_process.stdout:
            return

        from jarvis.daemon import CHAT_IPC_PREFIX, VOICE_STATUS_IPC_PREFIX
        from jarvis.tasks import TASK_EVENT_PREFIX
        process = self.daemon_process

        try:
            while True:
                line = process.stdout.readline()
                if not line:
                    # EOF - process has ended
                    debug_log("log reader: EOF reached, daemon stdout closed", "desktop")
                    break
                # Debug: log IPC events specifically
                if "__DIARY__:" in line:
                    debug_log(f"log reader: IPC event read: {line[:80]}...", "desktop")
                # Route chat events to the main thread via the IPC signal
                # bridge. The line is parsed and the chat window is created
                # on the Qt main thread, never here on the log reader thread
                # (Qt widgets must be created on the GUI thread).
                if line.startswith(CHAT_IPC_PREFIX):
                    self._chat_ipc_signals.line_received.emit(line)
                elif line.startswith(VOICE_STATUS_IPC_PREFIX):
                    self.log_signals.voice_status.emit(process, line)
                elif line.startswith(TASK_EVENT_PREFIX):
                    self.log_signals.task_event.emit(line)
                if _should_emit_as_log(line):
                    self.log_signals.new_log.emit(line)
        except Exception as e:
            debug_log(f"log reader error: {e}", "desktop")
            self.log_signals.new_log.emit(f"⚠️ Log reader error: {e}\n")

    def _on_chat_ipc_line(self, line: str) -> None:
        """Handle a ``__CHAT__:`` event line on the Qt main thread.

        Creates the chat window lazily (safe on the GUI thread) and forwards
        the line to ``ChatWindow.process_ipc_line`` for parsing + signal emit.
        """
        if self.chat_window is None:
            from desktop_app.chat_window import ChatWindow
            self.chat_window = ChatWindow(
                submit_fn=self._chat_submit_fn,
                daemon_available=self.is_listening,
                cancel_fn=getattr(self, "_chat_cancel_fn", None),
            )
        self.chat_window.process_ipc_line(line)

    def stop_daemon(
        self,
        show_diary_dialog: bool = True,
    ) -> None:
        """Stop the Jarvis daemon.

        Args:
            show_diary_dialog: If True (and bundled), shows a dialog with live diary update progress.
        """
        if self._daemon_stop_expected:
            return
        worker = self.daemon_thread

        # Timeout must be longer than SHUTDOWN_DIARY_TIMEOUT_SEC (45s) in daemon.py
        # to allow the diary update LLM call to complete before force-killing
        shutdown_wait_timeout_sec = 60
        diary_dialog = None

        debug_log(
            f"stop_daemon called: is_bundled={self.is_bundled}, "
            f"daemon_thread={self.daemon_thread}, "
            f"show_diary_dialog={show_diary_dialog}",
            "desktop",
        )

        try:
            self._daemon_stop_expected = True
            self._set_chat_daemon_status("stopping")
            if self.is_bundled and worker:
                # When running in a QThread, use the stop flag for graceful shutdown
                # This ensures the daemon's finally block runs (for diary update)
                self.log_signals.new_log.emit("⏸️ Stopping Jarvis daemon...\n")

                # Show diary update dialog for bundled app
                if show_diary_dialog:
                    diary_dialog = DiaryUpdateDialog()

                    # Set up thread-safe callbacks that emit Qt signals
                    # These callbacks run in the daemon thread, so we use signals
                    def on_token(token: str):
                        diary_dialog.signals.token_received.emit(token)

                    def on_status(status: str):
                        diary_dialog.signals.status_changed.emit(status)

                    def on_chunks(chunks: list):
                        # Use signal for thread-safe cross-thread communication
                        diary_dialog.signals.chunks_received.emit(chunks)

                    def on_complete(success: bool):
                        diary_dialog.signals.completed.emit(success)

                    # Set callbacks in daemon before requesting stop
                    from jarvis.daemon import set_diary_update_callbacks, request_stop
                    set_diary_update_callbacks(
                        on_token=on_token,
                        on_status=on_status,
                        on_chunks=on_chunks,
                        on_complete=on_complete,
                    )

                    # Show dialog (non-modal so we can process events)
                    diary_dialog.show()
                    diary_dialog.raise_()
                    diary_dialog.activateWindow()
                    self.app.processEvents()

                    # Request graceful stop
                    request_stop()

                    # Process events while waiting for thread to finish
                    # Note: We avoid QThread.terminate() as it can corrupt state
                    # If the daemon doesn't stop gracefully, it will be killed on process exit
                    start_time = time.time()
                    warned = False
                    while not worker.isFinished():
                        self.app.processEvents()
                        elapsed = time.time() - start_time
                        if elapsed > shutdown_wait_timeout_sec and not warned:
                            self.log_signals.new_log.emit("⚠️ Daemon taking longer than expected...\n")
                            debug_log("daemon thread not responding to stop request", "desktop")
                            warned = True
                        # Keep waiting up to 3x the timeout before giving up
                        if elapsed > shutdown_wait_timeout_sec * 3:
                            self.log_signals.new_log.emit("⚠️ Giving up waiting for daemon\n")
                            break
                        time.sleep(0.05)

                    # Brief delay to show completion state
                    self.app.processEvents()
                    time.sleep(0.5)

                    # Close dialog
                    diary_dialog.close()

                    # Clear callbacks
                    set_diary_update_callbacks()
                else:
                    # No dialog - simple wait
                    # Note: We avoid QThread.terminate() as it can corrupt state
                    from jarvis.daemon import request_stop
                    request_stop()

                    if not worker.wait(shutdown_wait_timeout_sec * 1000):
                        self.log_signals.new_log.emit("⚠️ Daemon taking longer than expected...\n")
                        debug_log("daemon thread not responding to stop request", "desktop")
                        # Wait up to 3x timeout total before giving up
                        worker.wait(shutdown_wait_timeout_sec * 2000)

                if worker.isFinished():
                    self.daemon_thread = None
                else:
                    # Retain the owner until its OS thread has finished.
                    self._daemon_stuck = True
                    self.log_signals.new_log.emit(
                        "⚠️ The daemon is still shutting down. Starting is blocked until it finishes.\n"
                    )
                    debug_log("daemon thread still alive after give-up; marked stuck", "desktop")
            elif self.daemon_process:
                # For subprocess mode, show diary dialog with IPC-based updates
                # The existing log reader thread emits signals; we use a queue to collect lines
                # and process them in the main loop to avoid cross-thread Qt signal issues
                from desktop_app.diary_dialog import DIARY_IPC_PREFIX
                import queue

                log_queue = queue.Queue()
                ipc_received = False

                # Connect to log signals and put lines into queue for main loop processing
                def queue_log_line(line: str):
                    log_queue.put(line)

                log_connection = self.log_signals.new_log.connect(queue_log_line)

                if show_diary_dialog:
                    diary_dialog = DiaryUpdateDialog()
                    diary_dialog.set_status("Shutting down...")
                    diary_dialog.show()
                    diary_dialog.raise_()
                    diary_dialog.activateWindow()
                    self.app.processEvents()

                # Send signal for graceful shutdown. The daemon runs its
                # final diary update in its shutdown block regardless.
                if sys.platform == "win32":
                    # On Windows, signals don't work reliably with CREATE_NO_WINDOW
                    # Close stdin to trigger graceful shutdown in daemon
                    try:
                        if self.daemon_process.stdin:
                            self.daemon_process.stdin.close()
                    except Exception:
                        pass
                    # Also try signal as backup
                    try:
                        self.daemon_process.send_signal(signal.CTRL_BREAK_EVENT)
                    except Exception:
                        pass
                else:
                    self.daemon_process.send_signal(signal.SIGINT)

                # Wait for process to terminate while processing queued log lines
                start_time = time.time()
                last_status_update = 0

                while True:
                    # Process Qt events to receive signals from log reader thread
                    self.app.processEvents()
                    elapsed = time.time() - start_time

                    # Process all available log lines from queue
                    lines_processed = 0
                    while True:
                        try:
                            line = log_queue.get_nowait()
                            lines_processed += 1
                            # Process IPC events for diary dialog
                            if diary_dialog and DIARY_IPC_PREFIX in line:
                                debug_log(f"IPC event found: {line[:80]}", "desktop")
                                if diary_dialog.process_log_line(line):
                                    ipc_received = True
                        except queue.Empty:
                            break

                    # Check if process has exited
                    if self.daemon_process.poll() is not None:
                        # Process exited - drain remaining queue items
                        self.app.processEvents()
                        time.sleep(0.1)  # Brief wait for any final signals
                        self.app.processEvents()
                        while True:
                            try:
                                line = log_queue.get_nowait()
                                if diary_dialog and DIARY_IPC_PREFIX in line:
                                    if diary_dialog.process_log_line(line):
                                        ipc_received = True
                            except queue.Empty:
                                break
                        break

                    # Update status periodically if no IPC events received
                    if diary_dialog and not ipc_received and int(elapsed) > last_status_update:
                        last_status_update = int(elapsed)
                        if elapsed < 10:
                            diary_dialog.set_status("Saving diary...")
                        elif elapsed < 30:
                            diary_dialog.set_status("Still saving... (AI is thinking)")
                        else:
                            diary_dialog.set_status(f"Taking longer than expected ({int(elapsed)}s)...")

                    # Check timeout
                    if elapsed > shutdown_wait_timeout_sec:
                        debug_log("subprocess shutdown timeout - killing process", "desktop")
                        self.daemon_process.kill()
                        self.daemon_process.wait()
                        break

                    time.sleep(0.02)

                # Disconnect queue handler
                try:
                    self.log_signals.new_log.disconnect(queue_log_line)
                except Exception:
                    pass

                # Close diary dialog
                if diary_dialog:
                    # If no IPC events received (older daemon?), mark complete manually
                    if not ipc_received:
                        diary_dialog.mark_completed(True)
                    self.app.processEvents()
                    time.sleep(0.5)
                    diary_dialog.close()

                self.daemon_process = None
                self._chat_submit_fn = None

            self._daemon_stop_expected = False
            self.is_listening = False
            self.toggle_action.setText("▶️ Turn On")
            self.status_action.setText("⚪ Status: Stopped")
            self.update_icon()
            self._set_chat_daemon_status("stopped")
            # Reset face to asleep so it doesn't look ready while daemon is down
            self._set_face_asleep()

            self.tray_icon.showMessage(
                "Jarvis Stopped",
                "Voice assistant is no longer listening",
                QSystemTrayIcon.MessageIcon.Information,
                2000
            )

            self.log_signals.new_log.emit("⏸️ Jarvis daemon stopped\n")
            debug_log("daemon stopped from desktop app", "desktop")

        except Exception as e:
            self._daemon_stop_expected = False
            debug_log(f"failed to stop daemon: {e}", "desktop")
            self.log_signals.new_log.emit(f"❌ Failed to stop: {str(e)}\n")
        finally:
            self._daemon_stop_expected = False
            # Ensure dialog is closed
            if diary_dialog:
                diary_dialog.close()

    def check_daemon_status(self) -> None:
        """Check if the daemon process/thread is still running."""
        if self.is_bundled and self.daemon_thread:
            worker = self.daemon_thread
            if worker.isFinished():
                unexpected = self.is_listening and not self._daemon_stop_expected
                self._on_daemon_finished(worker)
                if unexpected:
                    self.tray_icon.showMessage(
                        "Jarvis Stopped",
                        "Voice assistant process ended unexpectedly",
                        QSystemTrayIcon.MessageIcon.Warning,
                        3000
                    )
                    debug_log("daemon thread ended unexpectedly", "desktop")
        elif self.daemon_process:
            # Check if process is still alive
            poll = self.daemon_process.poll()
            if poll is not None:
                # Process has terminated
                self.daemon_process = None
                self._chat_submit_fn = None
                if self.is_listening:
                    self.is_listening = False
                    self.toggle_action.setText("▶️ Turn On")
                    self.status_action.setText("⚪ Status: Stopped")
                    self.update_icon()
                    self._set_chat_daemon_status("crashed")
                    # Reset face to asleep so it doesn't look ready while daemon is down
                    self._set_face_asleep()

                    self.tray_icon.showMessage(
                        "Jarvis Stopped",
                        "Voice assistant process ended unexpectedly",
                        QSystemTrayIcon.MessageIcon.Warning,
                        3000
                    )

                    debug_log("daemon process ended unexpectedly", "desktop")

        self._sync_voice_pause_controls()

    def quit_app(self, skip_diary: bool = False) -> None:
        """Quit the desktop app.

        Args:
            skip_diary: If True, skips the diary dialog during shutdown.
                       Used when quitting for an update to allow faster exit.
        """
        # Stop daemon if running
        if self.is_listening:
            self.stop_daemon(show_diary_dialog=not skip_diary)

        debug_log("desktop app shutting down", "desktop")
        self.tray_icon.hide()
        self.app.quit()

    def run(self) -> int:
        """Run the application event loop."""
        return self.app.exec()


def _ollama_runtime_flags(cfg) -> tuple[bool, bool]:
    """Decide how much of the Ollama startup flow applies given the active
    providers.

    Returns ``(ollama_needed, chat_on_ollama)``:
    - ``ollama_needed`` — the local Ollama server must be up because chat
      and/or embeddings run on it. False only for a pure OpenAI-compatible
      setup (both chat and embeddings remote), where there is nothing local
      to start or verify.
    - ``chat_on_ollama`` — the chat model is an Ollama model, so the
      chat-model verification / unsupported-model checks apply. False when
      chat runs on an OpenAI-compatible server (its model name is not in the
      Ollama catalogue and would be wrongly flagged as unsupported).
    """
    llm_provider = getattr(cfg, "llm_provider", "ollama") or "ollama"
    embed_provider = getattr(cfg, "embedding_provider", "") or llm_provider
    ollama_needed = not (
        llm_provider == "openai_compatible" and embed_provider == "openai_compatible"
    )
    chat_on_ollama = llm_provider != "openai_compatible"
    return ollama_needed, chat_on_ollama


def _check_openai_compat_reachable(cfg, timeout_sec: float = 4.0) -> bool:
    """True when the configured OpenAI-compatible server answers its model
    listing. Used at startup to warn the user early if their local server
    isn't running, since (unlike Ollama) Jarvis cannot start it for them."""
    try:
        from jarvis.llm import get_llm_backend
        return bool(get_llm_backend(cfg).list_models(timeout_sec=timeout_sec))
    except Exception:
        return False


def _build_unreachable_message(cfg) -> str:
    """Build the message text for the unreachable server dialog,
    without Qt dependencies so tests can verify it directly."""
    base = (getattr(cfg, "llm_base_url", "") or "").strip() or "your configured server"
    return (
        f"⚠️ Jarvis couldn't reach a ready LLM server at {base}.\n\n"
        "Make sure your local server (for example LM Studio, Ollama, llama.cpp, "
        "vLLM) is running with a model loaded, and Jarvis will connect "
        "automatically.\n\n"
        "You can open the Setup Wizard to change your server, or close and "
        "adjust Settings later via the tray menu \u2192 LLM Provider."
    )


def _show_openai_unreachable_dialog(cfg, splash: QWidget) -> None:
    """Suspend the startup splash while the warning or setup wizard is open."""
    from PyQt6.QtWidgets import QMessageBox

    dialog = QMessageBox()
    dialog.setWindowTitle("Jarvis")
    dialog.setText(_build_unreachable_message(cfg))
    dialog.setIcon(QMessageBox.Icon.Warning)
    open_wizard_btn = dialog.addButton("🔧 Open Setup Wizard", QMessageBox.ButtonRole.ActionRole)
    dialog.addButton("Close", QMessageBox.ButtonRole.RejectRole)
    splash_was_visible = splash.isVisible()
    splash.hide()
    QApplication.processEvents()
    debug_log("startup splash hidden for server recovery dialog", "startup")
    try:
        dialog.exec()
        if dialog.clickedButton() == open_wizard_btn:
            _run_setup_wizard()
    finally:
        splash.setVisible(splash_was_visible)


def _run_setup_wizard() -> bool:
    """Create and show the SetupWizard modally. Returns True if accepted."""
    try:
        from desktop_app.setup_wizard import SetupWizard
        wizard = SetupWizard()
        wizard.show()
        wizard.raise_()
        wizard.activateWindow()
        return wizard.exec() == wizard.DialogCode.Accepted
    except Exception as e:
        print(f"  ❌ Failed to create setup wizard: {e}", flush=True)
        return False


def _smoke_test_main() -> int:
    """Smoke-test entry point for CI: verify Qt + daemon initialise without crashing.

    Creates a minimal QApplication, runs the daemon init, and exits.
    Returns 0 on success, 1 on failure.
    """
    import multiprocessing
    multiprocessing.freeze_support()

    # Ensure stdout/stderr use UTF-8.  PyInstaller GUI-subsystem executables
    # (console=False) can attach an ANSI-code-page stdout (Windows) or even
    # None when there is no console at all; the daemon prints emoji
    # (✅, ✓, 🧠…), so a non-UTF-8 stream raises UnicodeEncodeError (or
    # AttributeError when stdout is None) and the smoke test exits 1 before
    # ever reaching the daemon.  Wrap in UTF-8 when a binary buffer is
    # available and fall back to a sink so prints can never crash the test.
    # Only wrap the real console streams: pytest swaps in its own capture
    # objects that must not be re-wrapped (wrapping them detaches and
    # closes their buffers, corrupting output capture for the process).
    try:
        import io
        for _stream_name in ("stdout", "stderr"):
            _stream = getattr(sys, _stream_name)
            _real = getattr(sys, "__" + _stream_name, None)
            if _stream is None:
                setattr(sys, _stream_name, io.StringIO())
            elif (getattr(sys, "frozen", False) or sys.platform == "win32") \
                    and (getattr(sys, "frozen", False) or _stream is _real) \
                    and hasattr(_stream, "buffer") and hasattr(_stream.buffer, "write"):
                setattr(sys, _stream_name, io.TextIOWrapper(
                    _stream.buffer, encoding="utf-8", errors="replace"))
    except Exception:
        pass

    # The smoke test never renders UI, so force Qt's offscreen platform on
    # Linux regardless of whether xvfb supplies a $DISPLAY.  This keeps the
    # CI gate focused on "does the bundle start / do imports resolve" instead
    # of depending on the xcb platform plugin and its X11 system libraries.
    if sys.platform == 'linux':
        os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

    try:
        from PyQt6.QtWidgets import QApplication

        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
        app.setQuitOnLastWindowClosed(False)
    except Exception as exc:
        print(f"❌ Qt initialisation failed: {exc}", flush=True)
        traceback.print_exc()
        return 1

    print("✅ Qt initialised successfully", flush=True)

    try:
        # Import inside the try so a missing/broken bundled dependency
        # (e.g. a faster_whisper / ctranslate2 native lib) surfaces as a
        # clean "Daemon initialisation failed" instead of an uncaught
        # traceback with a mysterious exit code 1.
        from jarvis.daemon import main as daemon_main
        daemon_main(smoke_test=True)
    except Exception as exc:
        print(f"❌ Daemon initialisation failed: {exc}", flush=True)
        traceback.print_exc()
        return 1

    print("SMOKE_TEST_PASSED", flush=True)
    return 0


class SetupCheckWorker(KeepAliveWorker):
    """Worker thread to check setup status without blocking the UI.

    Inherits ``KeepAliveWorker`` so dropping the local reference after the
    check completes can never destroy a running QThread ("Fatal Python
    error: Aborted" — #584/#575/#576). The completion signal is named
    ``check_done`` so it does not shadow QThread's built-in ``finished``.
    """

    check_done = pyqtSignal(bool)  # Emits True if setup wizard needed

    def run(self):
        try:
            # Lazy import: app.py keeps setup_wizard loading deferred past
            # crash-logging setup, so resolve it from the worker thread.
            from desktop_app.setup_wizard import should_show_setup_wizard
            result = should_show_setup_wizard()
            self.check_done.emit(result)
        except Exception as e:
            print(f"  ❌ Setup check failed: {e}", flush=True)
            # On error, show wizard to let user fix issues
            self.check_done.emit(True)


class _LLMReachWorker(KeepAliveWorker):
    """Worker thread that probes the configured OpenAI-compatible server.

    Emits via ``check_done`` — never by shadowing QThread's built-in
    ``finished`` (the keep-alive registry relies on ``finished`` to know
    when releasing the worker is safe).
    """

    check_done = pyqtSignal(bool)

    def __init__(self, provider_cfg):
        super().__init__()
        self.provider_cfg = provider_cfg

    def run(self):
        self.check_done.emit(_check_openai_compat_reachable(self.provider_cfg))


class ServerCheckWorker(KeepAliveWorker):
    """Worker thread to check Ollama server status without blocking the UI."""

    # Named check_done so it does not shadow QThread's built-in finished.
    check_done = pyqtSignal(bool, object)  # Emits (is_running, version)

    def run(self):
        try:
            # Lazy import: resolves the Ollama helpers from the worker thread.
            from desktop_app.setup_wizard import check_ollama_server
            running, ver = check_ollama_server()
            self.check_done.emit(running, ver)
        except Exception as e:
            print(f"  ❌ Server check failed: {e}", flush=True)
            self.check_done.emit(False, None)


def main() -> int:
    """Main entry point for the desktop app."""
    # Smoke-test fast path: runs before any UI, crash logging, or setup checks.
    if "--smoke-test" in set(sys.argv[1:]):
        return _smoke_test_main()

    # Fix Windows console encoding for Unicode/emoji characters
    # Only for non-frozen apps - frozen apps redirect stdout to crash log
    # Only wrap the real console streams (sys.__stdout__/sys.__stderr__):
    # test harnesses replace sys.stdout with capture objects whose buffers
    # must not be detached.
    if sys.platform == 'win32' and not getattr(sys, 'frozen', False):
        try:
            import io
            if (sys.stdout is sys.__stdout__ and hasattr(sys.stdout, 'buffer')
                    and hasattr(sys.stdout.buffer, 'write')):
                sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
            if (sys.stderr is sys.__stderr__ and hasattr(sys.stderr, 'buffer')
                    and hasattr(sys.stderr.buffer, 'write')):
                sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        except Exception:
            pass

    # Required for PyInstaller: must be called before any multiprocessing
    # Without this, bundled apps can spawn infinite copies of themselves
    import multiprocessing
    multiprocessing.freeze_support()

    # Single-instance check
    # This prevents multiple tray icons and log windows from spawning
    if not acquire_single_instance_lock():
        print("⚠️ Another instance of Jarvis Desktop is already running.", flush=True)

        # Create a minimal QApplication for the dialog
        from PyQt6.QtWidgets import QApplication
        temp_app = QApplication(sys.argv)

        if show_instance_conflict_dialog():
            # User wants to kill the existing instance
            existing_pid = get_existing_instance_pid()
            if existing_pid:
                print(f"🔄 Closing existing instance (PID {existing_pid})...", flush=True)
                if kill_existing_instance(existing_pid):
                    # Wait a moment for the lock file to be released
                    import time
                    time.sleep(0.5)

                    # Try to acquire the lock again
                    if acquire_single_instance_lock():
                        print("✅ Lock acquired, starting new instance...", flush=True)
                        # Clean up temp app - we'll create the real one below
                        temp_app.quit()
                        del temp_app
                    else:
                        print("❌ Failed to acquire lock after killing existing instance.", flush=True)
                        return 1
                else:
                    print("❌ Failed to close existing instance.", flush=True)
                    return 1
            else:
                print("❌ Could not find existing instance PID.", flush=True)
                return 1
        else:
            # User chose to exit
            print("👋 Exiting.", flush=True)
            return 0

    # Check for previous crash BEFORE setting up new crash logging
    # This way we can read the old crash log before it's overwritten
    previous_crash = check_previous_crash()

    # Set up crash logging for bundled apps
    crash_log_file = setup_crash_logging()

    # Mark that this session has started (for crash detection on next launch)
    mark_session_started()

    # Register clean exit handler
    atexit.register(mark_session_clean_exit)

    print("Starting Jarvis Desktop App...", flush=True)
    print(f"Python executable: {sys.executable}", flush=True)
    print(f"Working directory: {os.getcwd()}", flush=True)
    print(f"__file__: {__file__}", flush=True)
    print(flush=True)

    # Set up signal handlers for clean shutdown
    import signal
    tray_instance = None

    def signal_handler(signum, frame):
        """Handle termination signals."""
        print(f"Received signal {signum}, shutting down...", flush=True)
        if tray_instance:
            tray_instance.cleanup_on_exit()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    try:
        print("Creating QApplication...", flush=True)
        from PyQt6.QtWidgets import QApplication
        from PyQt6.QtCore import QTimer
        print("QApplication imported successfully", flush=True)

        # Create QApplication first (needed for wizard and splash)
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
        app.setQuitOnLastWindowClosed(False)

        # Show crash report dialog if previous session crashed
        if previous_crash:
            print("⚠️ Previous session crashed, showing crash report dialog...", flush=True)
            show_crash_report_dialog(previous_crash)

        # Show splash screen during startup
        from desktop_app.splash_screen import SplashScreen
        splash = SplashScreen()
        splash.show()
        splash.set_status("Initializing...")
        app.processEvents()

        # Check if setup wizard is needed
        splash.set_status("Checking setup status...")
        print("Checking Ollama setup status...", flush=True)
        print("  Loading setup wizard module...", flush=True)
        try:
            from desktop_app.setup_wizard import (
                check_ollama_server, check_ollama_cli,
                get_required_models, check_installed_models,
                resolve_ollama_path,
            )
            print("  Setup wizard module loaded successfully", flush=True)
        except Exception as e:
            print(f"  ❌ Failed to load setup wizard: {e}", flush=True)
            traceback.print_exc()
            raise

        # Run setup check in background thread to keep splash animation alive
        from PyQt6.QtCore import QEventLoop

        setup_check_result = [None]  # Use list to allow modification in closure

        def on_setup_check_done(needs_wizard: bool):
            setup_check_result[0] = needs_wizard

        worker = SetupCheckWorker()
        worker.check_done.connect(on_setup_check_done)
        worker.start()

        # Use QEventLoop to wait while keeping UI fully responsive
        # This allows the splash animation to run smoothly
        loop = QEventLoop()
        worker.check_done.connect(loop.quit)
        loop.exec()

        if setup_check_result[0]:
            splash.hide()
            app.processEvents()
            print("🔧 Setup required - launching setup wizard...", flush=True)
            if not _run_setup_wizard():
                print("Setup wizard cancelled - exiting", flush=True)
                return 0
            print("✅ Setup wizard completed successfully", flush=True)
            splash.show()
            splash.set_status("Setup complete!")
            app.processEvents()
        else:
            print("✅ Ollama setup looks good", flush=True)

        # Local-runtime readiness. A pure OpenAI-compatible setup needs no
        # local Ollama server to start or models to pull, so skip the whole
        # block. When chat runs on Ollama we verify the chat model; when only
        # embeddings run on Ollama we just make sure the server is up.
        try:
            from jarvis.config import load_settings as _load_provider_settings
            _provider_cfg = _load_provider_settings()
            _ollama_needed, _chat_on_ollama = _ollama_runtime_flags(_provider_cfg)
        except Exception:
            _provider_cfg = None
            _ollama_needed, _chat_on_ollama = True, True

        if not _ollama_needed:
            print("🔌 OpenAI-compatible provider configured: skipping Ollama startup checks", flush=True)

            # We can't start a third-party server the way we start Ollama, so
            # check it is reachable and warn early if it isn't — otherwise the
            # user only finds out when their first request silently fails.
            splash.set_status("Checking your LLM server...")
            app.processEvents()

            _reach = [True]
            _reach_worker = _LLMReachWorker(_provider_cfg)
            _reach_worker.check_done.connect(lambda ok: _reach.__setitem__(0, ok))
            _reach_loop = QEventLoop()
            _reach_worker.check_done.connect(_reach_loop.quit)
            _reach_worker.start()
            _reach_loop.exec()

            if not _reach[0]:
                print("⚠️ LLM server not reachable at startup", flush=True)
                _show_openai_unreachable_dialog(_provider_cfg, splash)

        # Default ownership: not started by us. Re-assigned below if Jarvis
        # launches its own Ollama server process.
        ollama_runtime_ownership = OllamaRuntimeOwnership()

        if _ollama_needed:
            # Even if setup was completed before, verify Ollama server is actually running
            # This handles the case where user reinstalls or Ollama service isn't auto-started
            splash.set_status("Checking Ollama server...")
            app.processEvents()

            # Run server check in background thread to keep splash animation alive
            server_check_result = [None, None]  # [is_running, version]

            def on_server_check_done(running: bool, ver):
                server_check_result[0] = running
                server_check_result[1] = ver

            server_worker = ServerCheckWorker()
            server_worker.check_done.connect(on_server_check_done)
            server_worker.start()

            # Use QEventLoop to wait while keeping UI fully responsive
            server_loop = QEventLoop()
            server_worker.check_done.connect(server_loop.quit)
            server_loop.exec()

            is_running, version = server_check_result

            if not is_running:
                print("⚠️ Ollama server not running, attempting to start...", flush=True)
                splash.set_status("Starting Ollama server...")
                app.processEvents()

                # Get ollama path
                cli_installed, ollama_path = check_ollama_cli()
                if not cli_installed:
                    ollama_path = "ollama"
                    print(f"  ⚠️ Ollama CLI not found in standard paths, trying '{ollama_path}' from PATH", flush=True)
                else:
                    print(f"  📍 Found Ollama at: {ollama_path}", flush=True)

                # Try to start Ollama server
                ollama_process = None
                ollama_launch_method = ""
                try:
                    if sys.platform == "darwin":
                        # On macOS, try to open the Ollama app first
                        try:
                            print("  🍎 Trying to open Ollama.app...", flush=True)
                            ollama_process = subprocess.Popen(
                                ["open", "-a", "Ollama"],
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL
                            )
                            ollama_launch_method = "macos_app"
                        except Exception as e:
                            # Fall back to running serve command
                            print(f"  ⚠️ Ollama.app not found ({e}), trying serve command...", flush=True)
                            ollama_process = subprocess.Popen(
                                [ollama_path, "serve"],
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL,
                                start_new_session=True
                            )
                            ollama_launch_method = "serve"
                    elif sys.platform == "win32":
                        # On Windows, hide the console window
                        print(f"  🪟 Starting Ollama server: {ollama_path} serve", flush=True)
                        ollama_process = subprocess.Popen(
                            [ollama_path, "serve"],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                            creationflags=subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS,
                        )
                        ollama_launch_method = "serve"
                    else:
                        # On Linux and other platforms
                        print(f"  🐧 Starting Ollama server: {ollama_path} serve", flush=True)
                        ollama_process = subprocess.Popen(
                            [ollama_path, "serve"],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                            start_new_session=True
                        )
                        ollama_launch_method = "serve"

                    ollama_runtime_ownership = OllamaRuntimeOwnership(
                        started_by_jarvis=True,
                        launch_method=ollama_launch_method,
                        process=ollama_process,
                    )
                    debug_log(
                        f"Ollama runtime launched by desktop app via {ollama_launch_method}",
                        "desktop",
                    )

                    # Verify the process started
                    if (
                        ollama_process
                        and ollama_launch_method != "macos_app"
                        and ollama_process.poll() is not None
                    ):
                        print(f"  ❌ Ollama process exited immediately with code {ollama_process.returncode}", flush=True)
                    elif ollama_launch_method == "macos_app":
                        print("  ✅ Ollama.app launch requested", flush=True)
                    else:
                        print(f"  ✅ Ollama process started (PID: {ollama_process.pid if ollama_process else 'unknown'})", flush=True)

                    # Wait for Ollama to start (up to 15 seconds)
                    splash.set_status("Waiting for Ollama to start...")
                    app.processEvents()

                    import time
                    max_wait = 15
                    wait_interval = 0.5
                    waited = 0
                    while waited < max_wait:
                        # Use shorter sleeps with more frequent UI updates for smooth animation
                        for _ in range(5):  # 5 x 100ms = 500ms total
                            time.sleep(0.1)
                            app.processEvents()
                        waited += wait_interval

                        is_running, version = check_ollama_server()
                        if is_running:
                            print(f"✅ Ollama server started (version {version})", flush=True)
                            break

                        # Update splash with progress
                        splash.set_status(f"Waiting for Ollama to start... ({int(waited)}s)")
                        app.processEvents()

                    if not is_running:
                        # One final check — the server may have started between
                        # the last poll and the timeout decision.
                        is_running, version = check_ollama_server()
                        if not is_running:
                            print("⚠️ Ollama server failed to start within timeout", flush=True)
                            splash.hide()
                            app.processEvents()
                            if not _run_setup_wizard():
                                print("Setup wizard cancelled - exiting", flush=True)
                                return 0
                            # Re-check after the wizard in case the user fixed
                            # the issue (e.g. started Ollama manually).
                            is_running, version = check_ollama_server()
                            if not is_running:
                                print("⚠️ Server still unreachable after setup wizard", flush=True)
                                return 0
                            print(f"✅ Ollama server is running (version {version})", flush=True)
                            splash.show()
                            splash.set_status("Ollama configured!")
                            app.processEvents()
                except Exception as e:
                    print(f"⚠️ Failed to start Ollama: {e}", flush=True)
                    # Continue anyway - user may start Ollama manually
            else:
                print(f"✅ Ollama server is running (version {version})", flush=True)

        if _ollama_needed:
            # Verify the required Ollama models are present. get_required_models()
            # is provider-aware: it lists only models that actually run on Ollama
            # (chat + judge when chat is local; the embed model when embeddings
            # are local), so this covers the chat-on-Ollama path and the advanced
            # "remote chat + local embeddings" split alike.
            splash.set_status("Verifying required models...")
            app.processEvents()

            required_models = get_required_models()
            installed_models = check_installed_models(resolve_ollama_path())

            missing_models = missing_ollama_models(required_models, installed_models)

            if missing_models and _chat_on_ollama:
                splash.hide()
                app.processEvents()
                print(f"⚠️ Missing required models: {missing_models}", flush=True)
                print("🔧 Opening setup wizard to install missing models...", flush=True)
                if not _run_setup_wizard():
                    print("Setup wizard cancelled - exiting", flush=True)
                    return 0
                print("✅ Model installation complete", flush=True)
                splash.show()
                splash.set_status("Models installed!")
                app.processEvents()
            elif missing_models:
                # Only embeddings run on Ollama (chat is remote), so the
                # chat-model wizard does not apply. The embedding model is a
                # fixed name; surface a clear, non-blocking instruction rather
                # than silently degrading — memory search falls back to keyword
                # matching until the model is pulled.
                pull_cmd = "; ".join(f"ollama pull {m}" for m in missing_models)
                print(
                    f"⚠️ Ollama embedding model(s) not installed: {missing_models}. "
                    f"Memory search will use keyword matching until you run: {pull_cmd}",
                    flush=True,
                )
            else:
                print("✅ All required models are installed", flush=True)

        # VRAM check: warn if the configured chat model exceeds available GPU memory.
        # Runs on Windows (DXGI) and any platform with nvidia-smi.
        if _chat_on_ollama:
            try:
                from jarvis.utils.vram import detect_total_vram_mb, format_vram_warning
                _vram_mb = detect_total_vram_mb()
                if _vram_mb is not None:
                    _chat_model = getattr(_provider_cfg, "llm_chat_model", "") if _provider_cfg else ""
                    if not _chat_model:
                        _chat_model = getattr(cfg, "ollama_chat_model", "gemma4:e2b")
                    _warn = format_vram_warning(_vram_mb, _chat_model)
                    if _warn:
                        print(f"  {_warn}", flush=True)
                        splash.set_status("⚠️ Low VRAM detected — consider a smaller model")
                        app.processEvents()
            except Exception as exc:
                debug_log(f"Startup VRAM check failed: {exc}", "vram")

        try:
            _provider_cfg = _load_provider_settings()
        except Exception as exc:
            _provider_cfg = None
            debug_log(f"Model recommendation settings unavailable: {exc}", "desktop")

        if _provider_cfg is not None:
            splash.set_status("Checking model recommendations...")
            unlisted_models = check_model_support(_provider_cfg)
            if unlisted_models:
                splash.hide()
                roles = ", ".join(unlisted_models)
                print(f"⚠️ Models outside the recommended list: {roles}", flush=True)
                debug_log(f"Model recommendation advice shown for {roles}", "desktop")
                if show_unsupported_model_dialog(unlisted_models, _provider_cfg):
                    print("🔧 Opening setup wizard to change models...", flush=True)
                    if not _run_setup_wizard():
                        print("⚠️ Setup wizard cancelled, exiting", flush=True)
                        return 0
                splash.show()
                splash.set_status("Model check complete!")
                app.processEvents()

        splash.set_status("Loading Jarvis...")
        print("Initializing JarvisSystemTray...", flush=True)
        tray_instance = JarvisSystemTray(
            ollama_runtime_ownership=ollama_runtime_ownership,
        )
        print("JarvisSystemTray initialized successfully", flush=True)

        # Always auto-start listening
        splash.set_status("Starting voice assistant...")
        print("🚀 Auto-starting Jarvis listener...", flush=True)
        tray_instance.start_daemon()

        # Close splash screen
        splash.close_splash()

        # Open the log and face windows once at launch. start_daemon and
        # stop_daemon never change window visibility (the tray menu's
        # View Logs / Show Face actions are the only controls after this),
        # so the launch windows are opened here explicitly.
        tray_instance.show_launch_windows()

        if crash_log_file:
            # Show notification with log file location
            from PyQt6.QtWidgets import QSystemTrayIcon
            tray_instance.tray_icon.showMessage(
                "Jarvis Started",
                f"Crash logs available at:\n{crash_log_file}",
                QSystemTrayIcon.MessageIcon.Information,
                3000
            )

        print("Starting event loop...", flush=True)
        return tray_instance.run()
    except Exception as e:
        error_msg = f"desktop app fatal error: {e}\n{traceback.format_exc()}"
        print(error_msg, flush=True)
        debug_log(error_msg, "desktop")

        # Try to show an error dialog if possible
        try:
            from PyQt6.QtWidgets import QApplication, QMessageBox
            if not QApplication.instance():
                app = QApplication(sys.argv)

            msg = QMessageBox()
            msg.setIcon(QMessageBox.Icon.Critical)
            msg.setWindowTitle("Jarvis Desktop App Error")
            msg.setText("Failed to start Jarvis Desktop App")
            msg.setDetailedText(str(e) + "\n\n" + traceback.format_exc())
            if crash_log_file:
                msg.setInformativeText(f"Check log file at:\n{crash_log_file}")
            msg.exec()
        except Exception:
            # Can't show dialog, error is already logged
            pass

        return 1


if __name__ == "__main__":
    # Required for PyInstaller to handle multiprocessing correctly
    # Without this, bundled apps spawn infinite copies of themselves
    import multiprocessing
    multiprocessing.freeze_support()
    sys.exit(main())
